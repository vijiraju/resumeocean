from flask import Flask, request, jsonify
import openai

app = Flask(__name__)

import logging
from pathlib import Path

# Configure the logger
logging.basicConfig(
    # filename='extract_data.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

class CoverLetter:
    def evaluate_coverletter(self, jd, resume):
        prompt = f"""Write a cover letter for a particular {jd} job description provided, 
        the content of the resume {resume} details provided.
        
        """
        return prompt
    
    def openaigpt(self,api_key, prompt_input):
        openai.api_key = api_key
        model_name = "gpt-3.5-turbo-16k-0613"
        role = """You are an AI Chatbot tasked with generating a cover letter for a job application. 
                Incorporate relevant information from the provided job description and resume.
                Ensure the cover letter is well-written and effectively communicates the candidate's qualifications.
                """

        messages = [
            {"role": "system", "content": role},
            {"role": "user", "content": prompt_input},
        ]
        response = openai.ChatCompletion.create(
            model=model_name,
            messages=messages,
            max_tokens=2048,
            temperature=1,
            stop=None,
            n=1
        )
        return response["choices"][0]["message"]["content"]
    
@app.route('/process_coverletter', methods=['POST'])
def process_coverletter():
    # Extract data from request
    data = request.get_json()
    api_key = data.get('api_key')
    resume = data.get('resume')
    jd = data.get('jd')
    
    clclass = CoverLetter()
    prompt = clclass.evaluate_coverletter(jd, resume)
    logging.info(f"{prompt}")
    cletter = clclass.openaigpt(api_key, prompt)
    logging.info(f"{cletter}")
    
    return jsonify({
        'result': cletter
    })    
    
if __name__ == '__main__':
    app.run(debug=True)
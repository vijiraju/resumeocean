python -m venv ./venv
./venv/Scripts/activate
python -m pip install --upgrade pip
pip install jupyterlab
pip install dataclasses
pip install pandas
pip install Flask

# for open ai
pip install openai==0.28
pip install requests

import openai
import json
import requests


import logging
from pathlib import Path

# Configure the logger
logging.basicConfig(
    filename='extract_data.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

# version 3
def lambda_handler(event, context):
    # Extract HTTP method and path from the event
    http_method = event.get('requestContext', {}).get('http', {}).get('method') or event.get('httpMethod')
    path = event.get('path')
    
    if not http_method:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'HTTP method not found in event'})
        }
    
    # Handle GET request at root path
    if http_method == 'GET' and path == '/':
        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Hello, Flask on AWS Lambda!'})
        }
        
##################################################################################################################
        
    # Handle POST request for '/process_coverletter'
    elif http_method == 'POST' and path == '/process_coverletter':
        try:
            body = json.loads(event['body'])
        except json.JSONDecodeError:
            return {'statusCode': 400, 'body': json.dumps({'error': 'Invalid JSON format in request body'})}

        api_key = body.get('api_key')
        resume = body.get('resume')
        jd = body.get('jd')
        

        if not resume or not jd or not api_key:
            return {'statusCode': 400, 'body': json.dumps({'error': 'Missing jd or API key or resume missing'})}
        
        # improvements and score
        clclass = CoverLetter()
        prompt = clclass.evaluate_coverletter(jd, resume)
        logging.info(f"{prompt}")
        cletter = clclass.openaigpt(api_key, prompt)
        logging.info(f"{cletter}")
        

        # Assuming extract_data_from_text is a function you have defined elsewhere
        data = json.dumps(cletter)
        logging.info(f"{data}")

        if data:
            data = data.strip('"')

            return {
                'statusCode': 200,
                'body': f'{data}',
                "headers": {
                    "Access-Control-Allow-Origin": "*", 
                    "Access-Control-Allow-Headers": "Content-Type, Authorization",
                    "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
                }
            }
        else:
            return {'statusCode': 500, 'body': json.dumps({'error': 'Failed to process jd text'})}  
        
class CoverLetter:
    
    def evaluate_coverletter(self, jd, resume):
        prompt = f"""Write a cover letter for a particular {jd} job description provided, 
        the content of the resume {resume} details provided.
        
        """
        return prompt
    
    def openaigpt(self,api_key, prompt_input):
        openai.api_key = api_key
        model_name = "gpt-3.5-turbo-16k-0613"
        role = """You are an AI Chatbot tasked with generating a cover letter for a job application. 
                Incorporate relevant information from the provided job description and resume.
                Ensure the cover letter is well-written and effectively communicates the candidate's qualifications.
                """

        messages = [
            {"role": "system", "content": role},
            {"role": "user", "content": prompt_input},
        ]
        response = openai.ChatCompletion.create(
            model=model_name,
            messages=messages,
            max_tokens=2048,
            temperature=1,
            stop=None,
            n=1
        )
        return response["choices"][0]["message"]["content"]
import requests
import PyPDF2
from pathlib import Path
from chatgptapikey import apikey


# Define the URL of the Flask app
flask_url = "http://localhost:5000/process_resume"

chatgptapikey = apikey()


# Sample PDF resume text
def extract_text_from_pdf(pdf_path):
    """Extracts text from a PDF file."""
    text = ""
    with open(pdf_path, 'rb') as file:
        pdf_reader = PyPDF2.PdfReader(file)
        for page in pdf_reader.pages:
            text += page.extract_text() + "\n"  # Concatenate text from each page
    return text

# Your OpenAI API key
pdf_path = Path(r"E:\Internship\StuValley\Dataset\Akshat Jain Resume Updated.pdf")
pdftext = extract_text_from_pdf(pdf_path)

# Sample Job Description text
jd_text = """
    About the job
    Greetings from TCS!

    TCS is hiring for Data Scientist

    Desired Experience Range: 4 to 8 Years

    Job Location: Chennai, Hyderabad, Bangalore
    Required Skill Set: R, Python, and database query languages like SQL, Hive, Pig is desirable. Familiarity with Scala, Java, or C++, Machine learning , Data Wrangling
    Must-Have: Python, Machine learning, data Wrangline
    Good-to-Have: Hadoop, Spark

    Expectations from the Role:

    1. Programming Skills – knowledge of statistical programming languages like R, Python, and database query languages like SQL, Hive, Pig is desirable. Familiarity with Scala, Java, or C++ is an added advantage.
    2. Statistics – Good applied statistical skills, including knowledge of statistical tests, distributions, regression, maximum likelihood estimators, etc. Proficiency in statistics is essential for data-driven companies.
    3. Machine Learning – good knowledge of machine learning methods like k-Nearest Neighbors, Naive Bayes, SVM, Decision Forests.
    4. Hands-on experience with data science tools
    5. Knowledge in Spark is added advantage
    6. Knowledge in Hadoop is added advantage
    7. Proven Experience as Data Analyst or Data Scientist
    8. Experience in large scale enterprise application implementation
    9. Creative Individual with a track record of working on and implementing innovative tech based solutions
    10. Exceptional intelligence and problem solving skills
"""

# Prepare the data payload
data = {
    "resume_text": pdftext,
    "api_key": chatgptapikey,
    "jd_text": jd_text
}

# Send a POST request to the Flask app
response = requests.post(flask_url, json=data)

# Check if the request was successful
if response.status_code == 200:
    # The API call was successful, you can process the response data
    print("Success!")
    print(response.json())  # This prints the structured data extracted from the resume text
else:
    # The API call failed, handle errors here
    print("Failed to process resume.")
    print(response.text)

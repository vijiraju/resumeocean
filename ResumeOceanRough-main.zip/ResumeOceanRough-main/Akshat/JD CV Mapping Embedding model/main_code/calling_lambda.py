import json
from app3_lambda_function import lambda_handler  # Import your Lambda function
from pathlib import Path
import PyPDF2
import os
from chatgptapikey import apikey

def extract_text_from_pdf(pdf_path):
    """Extracts text from a PDF file."""
    text = ""
    with open(pdf_path, 'rb') as file:
        pdf_reader = PyPDF2.PdfReader(file)
        for page in pdf_reader.pages:
            text += page.extract_text() + "\n"  # Concatenate text from each page
    return text

# Access API key
chatgptapikey = apikey()

# Use Path to handle the file path
pdf_path = Path(r"E:\Internship\StuValley\Dataset\Akshat Jain Resume Updated.pdf")
pdftext = extract_text_from_pdf(pdf_path)

# Example event and context
event = {
    "requestContext": {
        "http": {
            "method": "POST"
        }
    },
    "path": "/resume_match",
    "body": json.dumps({
        "resume_text": pdftext,
        "jd_text": '''About the job
                        Must Have
                        7 to 10 years of experience
                        3-5 years of experience with classic time series analysis tools (e.g. ARIMA, State Space Models, VAR, Error Correction Models etc.)
                        3-5 years of experience with machine learning models including Decision Tree, Regression, Gradient Boosting, and Deep Learning
                        3-5 years of experience with Python coding
                        3-5 years of experience with SQL coding 
                        Experience building and deploying production time series forecast models
                        Experience managing code repositories. 
                        ''',
         "api_key": chatgptapikey
    })
}
context = {}

# Call the Lambda function directly
response = lambda_handler(event, context)

# Print the response
print(response)

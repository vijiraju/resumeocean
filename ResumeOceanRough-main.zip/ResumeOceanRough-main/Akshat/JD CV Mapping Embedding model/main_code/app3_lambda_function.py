from transformers import AutoTokenizer, AutoModel
import torch
import numpy as np
import pandas as pd
import os
import openai
import requests
import numpy as np
from scipy.spatial.distance import cosine, euclidean, cityblock
from Levenshtein import distance as levenshtein_distance
import textdistance
import logging
import json
from chatgptapikey import apikey

# Access API key
chatgptapikey = apikey()

# Configure logging
logging.basicConfig(filename='extract_data.log', level=logging.INFO)

# version 3
def lambda_handler(event, context):
    # Extract HTTP method and path from the event
    http_method = event.get('requestContext', {}).get('http', {}).get('method') or event.get('httpMethod')
    path = event.get('path')
    
    if not http_method:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'HTTP method not found in event'})
        }
    
    # Handle GET request at root path
    if http_method == 'GET' and path == '/':
        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Hello, Flask on AWS Lambda!'})
        }
        
    # Handle POST request for '/resume_match'
    elif http_method == 'POST' and path == '/resume_match':
        try:
            body = json.loads(event['body'])
        except json.JSONDecodeError:
            return {'statusCode': 400, 'body': json.dumps({'error': 'Invalid JSON format in request body'})}

        resume_text = body.get('resume_text')
        #api_key = body.get('api_key')
        jd_text = body.get('jd_text')

        #if not resume_text or not api_key or not jd_text:
        if not resume_text or not jd_text:
            return {'statusCode': 400, 'body': json.dumps({'error': 'Missing resume text, JD text, or API key'})}

        # Assuming extract_data_from_text is a function you have defined elsewhere
        resume_matching = ResumeMatchingSystem()  
        data = resume_matching.resume_match(jd_text, resume_text)

        if data:
            return {
                'statusCode': 200,
                'body': json.dumps(data),
                "headers": {
                    "Access-Control-Allow-Origin": "*", 
                    "Access-Control-Allow-Headers": "Content-Type, Authorization",
                    "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
                }
            }
        else:
            return {'statusCode': 500, 'body': json.dumps({'error': 'Failed to process resume text'})}
    else:
        return {'statusCode': 405, 'body': json.dumps({'error': 'Method Not Allowed'})}


class ResumeMatchingSystem:
    def __init__(self):
        self.init_logging()

    def init_logging(self):
        logging.basicConfig(filename='extract_data.log', level=logging.INFO)

    # Initialize tokenizer and model from Hugging Face
        self.tokenizer = AutoTokenizer.from_pretrained('sentence-transformers/all-mpnet-base-v2')
        self.model = AutoModel.from_pretrained('sentence-transformers/all-mpnet-base-v2')

    def generate_embedding(self, text):
        inputs = self.tokenizer(text, padding=True, truncation=True, return_tensors="pt")
        with torch.no_grad():
            outputs = self.model(**inputs)
        embeddings = outputs.last_hidden_state.mean(dim=1).squeeze().numpy()
        return embeddings

    def calculate_cosine_similarity(self, embedding1, embedding2):
        return cosine(embedding1, embedding2)

    def calculate_jaccard_similarity(self, text1, text2):
        return textdistance.jaccard.normalized_similarity(text1, text2)

    def calculate_levenshtein_distance(self, text1, text2):
        return levenshtein_distance(text1, text2)

    def calculate_manhattan_distance(self, embedding1, embedding2):
        return cityblock(embedding1, embedding2)

    def calculate_euclidean_distance(self, embedding1, embedding2):
        return euclidean(embedding1, embedding2)

    def get_embeddings(self, texts):
        embeddings = []
        for text in texts:
            embedding = self.generate_embedding(text)
            embeddings.append(embedding)
        return embeddings

    def calculate_distances_and_similarities(self, embeddings, texts, labels):
        similarities = []
        distances = []

        for i in range(len(embeddings)):
            for j in range(i+1, len(embeddings)):
                if (i == 0 and j == 1) or (i == 1 and j > 1) or (i == 0 and j > 1):
                    cosine_similarity = self.calculate_cosine_similarity(embeddings[i], embeddings[j])
                    jaccard_similarity = self.calculate_jaccard_similarity(texts[i], texts[j])
                    levenshtein_dist = self.calculate_levenshtein_distance(texts[i], texts[j])
                    manhattan_dist = self.calculate_manhattan_distance(embeddings[i], embeddings[j])
                    euclidean_dist = self.calculate_euclidean_distance(embeddings[i], embeddings[j])

                    similarities.append((cosine_similarity, jaccard_similarity, labels[i], labels[j]))
                    distances.append((manhattan_dist, euclidean_dist, levenshtein_dist, labels[i], labels[j]))

        return similarities, distances

    def get_designation_suggestions(self, api_key, jd_text):
        openai.api_key = api_key
        model_name = "gpt-3.5-turbo-16k-0613"
        role = f"Extract all the best designations extracted from the job description '{jd_text}' based on the LLama Language Model (LLM), with the most appropriate designation listed first and separated by comma. If no designations found, directly write only 'No information available' as output."

        messages = [
            {"role": "system", "content": role},
            {"role": "user", "content": jd_text},
        ]
        response = openai.ChatCompletion.create(
            model=model_name,
            messages=messages,
            max_tokens=2048,
            temperature=0.6,
            stop=None,
            n=1
        )

        suggestions_str = response["choices"][0]["message"]["content"]
        suggestions_list = [s.strip() for s in suggestions_str.split(',')]
        return suggestions_list

    def resume_match(self, jd_text, resume_text):
        designation_suggestion = self.get_designation_suggestions(chatgptapikey, jd_text)
        
        texts = {'JD': jd_text, 'Resume': resume_text}
        texts.update({f"Designation {i+1}": suggestion for i, suggestion in enumerate(designation_suggestion)})
        labels = list(texts.keys())
        embeddings = self.get_embeddings(texts.values())

        similarities, distances = self.calculate_distances_and_similarities(embeddings, list(texts.values()), labels)

        # Convert similarities and distances into JSON serializable format
        serialized_similarities = [(float(similarity[0]), float(similarity[1]), similarity[2], similarity[3]) for similarity in similarities]
        serialized_distances = [(float(distance[0]), float(distance[1]), float(distance[2]), distance[3], distance[4]) for distance in distances]

        serialized_data = {
            'designation_suggestion': designation_suggestion,
            'similarities': serialized_similarities,
            'distances': serialized_distances
        }

        return serialized_data
       

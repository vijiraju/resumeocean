import os
import openai
import logging
from flask import Flask, request, jsonify
from transformers import AutoTokenizer, AutoModel
import torch
from pymongo import MongoClient
from scipy.spatial.distance import cosine, euclidean, cityblock
from Levenshtein import distance as levenshtein_distance
import textdistance

app = Flask(__name__)

class ResumeMatchingSystem:
    def __init__(self):
        # Initialize logging
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)

        # Initialize tokenizer and model from Hugging Face
        self.tokenizer = AutoTokenizer.from_pretrained('sentence-transformers/all-mpnet-base-v2')
        self.model = AutoModel.from_pretrained('sentence-transformers/all-mpnet-base-v2')

        # MongoDB connection
        self.client = MongoClient(os.getenv("mongodb://localhost:27017/?directConnection=true"))
        self.db = self.client["resume_db"]
        self.collection = self.db["res_coll"]

    def generate_embedding(self, text):
        inputs = self.tokenizer(text, padding=True, truncation=True, return_tensors="pt")
        with torch.no_grad():
            outputs = self.model(**inputs)
        embeddings = outputs.last_hidden_state.mean(dim=1).squeeze().numpy()
        return embeddings

    def calculate_cosine_similarity(self, embedding1, embedding2):
        return cosine(embedding1, embedding2)

    def calculate_jaccard_similarity(self, text1, text2):
        return textdistance.jaccard.normalized_similarity(text1, text2)

    def calculate_levenshtein_distance(self, text1, text2):
        return levenshtein_distance(text1, text2)

    def calculate_manhattan_distance(self, embedding1, embedding2):
        return cityblock(embedding1, embedding2)

    def calculate_euclidean_distance(self, embedding1, embedding2):
        return euclidean(embedding1, embedding2)

    def get_embeddings(self, texts):
        embeddings = []
        for text in texts:
            embedding = self.generate_embedding(text)
            embeddings.append(embedding)
        return embeddings

    def insert_documents(self, documents):
        if documents:
            self.collection.insert_many(documents)
            self.logger.info("Inserted %s documents into MongoDB.", len(documents))
        else:
            self.logger.warning("No documents to insert.")

    def calculate_distances_and_similarities(self, embeddings, texts, labels):
        similarities = []
        distances = []

        for i in range(len(embeddings)):
            for j in range(i+1, len(embeddings)):
                if (i == 0 and j == 1) or (i == 1 and j > 1) or (i == 0 and j > 1):
                    cosine_similarity = self.calculate_cosine_similarity(embeddings[i], embeddings[j])
                    jaccard_similarity = self.calculate_jaccard_similarity(texts[i], texts[j])
                    levenshtein_dist = self.calculate_levenshtein_distance(texts[i], texts[j])
                    manhattan_dist = self.calculate_manhattan_distance(embeddings[i], embeddings[j])
                    euclidean_dist = self.calculate_euclidean_distance(embeddings[i], embeddings[j])

                    similarities.append((cosine_similarity, jaccard_similarity, labels[i], labels[j]))
                    distances.append((manhattan_dist, euclidean_dist, levenshtein_dist, labels[i], labels[j]))

        return similarities, distances

    def get_designation_suggestions(self, api_key, jd_text):
        openai.api_key = api_key
        model_name = "gpt-3.5-turbo-16k-0613"
        role = f"Extract all the best designations extracted from the job description '{jd_text}' based on the LLama Language Model (LLM), with the most appropriate designation listed first and separated by comma. If no designations found, directly write only 'No information available' as output."

        messages = [
            {"role": "system", "content": role},
            {"role": "user", "content": jd_text},
        ]
        response = openai.ChatCompletion.create(
            model=model_name,
            messages=messages,
            max_tokens=2048,
            temperature=0.6,
            stop=None,
            n=1
        )

        suggestions_str = response["choices"][0]["message"]["content"]
        suggestions_list = [s.strip() for s in suggestions_str.split(',')]
        return suggestions_list[:5]

    def process_resume(self, api_key, jd_text, resume_text):
        designation_suggestion = self.get_designation_suggestions(api_key, jd_text)

        texts = {'JD': jd_text, 'Resume': resume_text}
        texts.update({f"Designation {i+1}": suggestion for i, suggestion in enumerate(designation_suggestion)})
        labels = list(texts.keys())
        embeddings = self.get_embeddings(texts.values())

        similarities, distances = self.calculate_distances_and_similarities(embeddings, list(texts.values()), labels)

        documents = []
        for text, embedding, label in zip(texts, embeddings, labels):
            metadata = {
                "source": "flask",
                "text_type": label
            }
            document = {
                "text": text,
                "embedding": embedding.tolist(),
                "metadata": metadata
            }
            documents.append(document)

        self.insert_documents(documents)

        results = zip(similarities, distances)

        return designation_suggestion, results

@app.route('/')
def index():
    return "Flask app is running"

@app.route('/process_resume', methods=['POST'])
def process_resume_route():
    if not request.json or 'jd_text' not in request.json or 'resume_text' not in request.json or 'api_key' not in request.json:
        return jsonify({"error": "Missing required data (JD text, resume text, or API key)"}), 400

    jd_text = request.json['jd_text']
    resume_text = request.json['resume_text']
    api_key = request.json['api_key']

    extractor = ResumeMatchingSystem()
    designation_suggestion, results = extractor.process_resume(api_key, jd_text, resume_text)

    formatted_results = []
    for similarity, distance in results:
        similarity_dict = {
            "cosine_similarity": float(similarity[0]),
            "jaccard_similarity": float(similarity[1]),
            "label1": similarity[2],
            "label2": similarity[3]
        }
        distance_dict = {
            "manhattan_distance": float(distance[0]),
            "euclidean_distance": float(distance[1]),
            "levenshtein_distance": float(distance[2]),
            "label1": distance[3],
            "label2": distance[4]
        }
        formatted_results.append({"similarity": similarity_dict, "distance": distance_dict})

    return jsonify({"designation_suggestion": designation_suggestion, "results": formatted_results})


if __name__ == "__main__":
    app.run(debug=True)

import streamlit as st
import openai
import base64
import os
import io
import PyPDF2 as pdf
from dotenv import load_dotenv
from pymongo import MongoClient
import json

load_dotenv() ## load all our environment variables

openai.api_key = "API_KEY"

# MongoDB setup
MONGODB_URI = os.getenv("mongodb://localhost:27017/?directConnection=true")  # Make sure to set this in your environment variables
client = MongoClient(MONGODB_URI)
db = client["resume_db"]  # Replace with your actual database name
collection = db["res_coll"]

def get_openai_response(designation, resume_text, jd):
    model_name = "gpt-3.5-turbo-16k-0613"
    role = f"You are provided with a dictionary, extract information based on the question and provide answers   from it. If unable to extract info, (REMEMBER) DIRECTLY WRITE 'No information available' as output. Act as an expert data analyst, with full knowledge of data extraction from the RESUME"
    messages = [
            {"role": "system", "content": role},
            {"role": "user", "content":f"{input_prompt} {designation}"},
    ]
    response = openai.ChatCompletion.create(
        model=model_name,
        messages=messages,
        max_tokens=2048,
        temperature=0.6,
        stop=None,
        n=1
    )
    return response["choices"][0]["message"]["content"]

    
def input_pdf_text(uploaded_file):
    reader=pdf.PdfReader(uploaded_file)
    text=""
    for page in range(len(reader.pages)):
        page=reader.pages[page]
        text+=str(page.extract_text())
    return text

# Prompt Template
input_prompt = """
You are an experienced Technical Human Resource Manager,your task is to review the provided resume against the job description and designation. 
Please share your professional evaluation on whether the candidate's profile aligns with the role. 
Highlight the strengths and weaknesses of the applicant in relation to the specified job requirements.
Your task is to evaluate the resume based on the given job description.
You must consider the job market is very competitive and you should provide 
best assistance for improving the resumes. Assign the percentage Matching based 
on JD and the missing keywords with high accuracy.
resume:{text}
Job Description:{jd}
designation:{designation}

I want the response in one single string having the structure
{{"Percentage Match": "%", "Strengths": [], "Weaknesses": [], "Missing Skills": [], "Points to Add": ""}}
"""

# Streamlit app
st.title("Smart ATS")
st.text("Improve Your Resume ATS")
designation = st.text_input("Designation", "")
jd = st.text_area("Paste the Job Description")
uploaded_file = st.file_uploader("Upload Your Resume", type="pdf", help="Please upload the pdf")
submit = st.button("Submit")

if submit:
    if uploaded_file is not None:
        # Store resume in MongoDB
        text = input_pdf_text(uploaded_file)
        resume_data = {"text": text}
        resume_id = collection.insert_one(resume_data).inserted_id

        # Get the resume from MongoDB for processing
        resume_text = collection.find_one({"_id": resume_id})["text"]

        try:
            # Call OpenAI API with resume, job description, and designation
            response = get_openai_response(designation, resume_text, jd)

            # Process the OpenAI response and extract relevant information
            result = json.loads(response)
            percentage_match = result.get("Percentage Match", "0%")
            strengths = result.get("Strengths", [])
            weaknesses = result.get("Weaknesses", [])
            missing_skills = result.get("MissingSkills", [])
            points_to_add = result.get("PointsToAdd", "")

            # Display the output
            st.subheader(f"Percentage Match: {percentage_match}")
            st.subheader("Strengths:")
            st.write(strengths)
            st.subheader("Weaknesses:")
            st.write(weaknesses)
            st.subheader("Missing Skills:")
            st.write(missing_skills)
            st.subheader("Points to Add:")
            st.write(points_to_add)

        except json.JSONDecodeError:
            st.error("Error decoding OpenAI response. Please try again.")


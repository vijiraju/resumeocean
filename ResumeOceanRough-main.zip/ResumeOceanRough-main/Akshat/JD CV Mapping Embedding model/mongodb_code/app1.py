import streamlit as st
from transformers import AutoTokenizer, AutoModel
import torch
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from pymongo import MongoClient
import os
import openai
import PyPDF2 as pdf
#from dotenv import load_dotenv
import json
import time
import pdfplumber
import requests

#load_dotenv()

# Initialize tokenizer and model from Hugging Face
tokenizer = AutoTokenizer.from_pretrained('sentence-transformers/all-mpnet-base-v2')
model = AutoModel.from_pretrained('sentence-transformers/all-mpnet-base-v2')

# API URL for generating embeddings
API_URL = "https://api-inference.huggingface.co/models/sentence-transformers/all-mpnet-base-v2"
HEADERS = {"Authorization": "Bearer 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"}

# Threshold length for when to use the API
#threshold_length = 1000  # Adjust as needed

# MongoDB connection
MONGODB_URI = os.getenv("mongodb://localhost:27017/?directConnection=true")
client = MongoClient(MONGODB_URI)
db = client["resume_db"]
collection = db["res_coll"]

# Function to calculate mean pooling
def mean_pooling(model_output, attention_mask):
    token_embeddings = model_output[0] #First element of model_output contains all token embeddings
    input_mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
    return torch.sum(token_embeddings * input_mask_expanded, 1) / torch.clamp(input_mask_expanded.sum(1), min=1e-9)

def generate_embedding(text, tokenizer, model, API_URL, headers):
    inputs = tokenizer(text, padding=True, truncation=True, return_tensors="pt")
    with torch.no_grad():
        outputs = model(**inputs)
    embeddings = outputs.last_hidden_state.mean(dim=1).squeeze().numpy()
    return embeddings

def get_embeddings(texts, tokenizer, model, API_URL, headers):
    embeddings = []
    for text in texts:
        print("Processing text:", text)
        embedding = generate_embedding(text, tokenizer, model, API_URL, headers)
        print("Embedding shape:", embedding.shape)  # Check the shape of the embedding
        print("Embedding:", embedding)  # Print the embedding itself
        embeddings.append(embedding)
    return embeddings


def insert_documents(documents):
    """
    Insert multiple documents into the MongoDB collection.
    
    Parameters:
        documents (list of dict): List of documents to insert. Each document should be a dictionary
            with keys 'text', 'embedding', and 'metadata'.
    """
    if documents:
        collection.insert_many(documents)
        print("Inserted", len(documents), "documents into MongoDB.")
    else:
        print("No documents to insert.")

def jaccard_similarity(text1, text2):
    set1 = set(text1.lower().split())
    set2 = set(text2.lower().split())
    intersection = len(set1.intersection(set2))
    union = len(set1.union(set2))
    return intersection / union if union != 0 else 0

def levenshtein_distance(s1, s2):
    if len(s1) < len(s2):
        return levenshtein_distance(s2, s1)

    if len(s2) == 0:
        return len(s1)

    previous_row = range(len(s2) + 1)
    for i, c1 in enumerate(s1):
        current_row = [i + 1]
        for j, c2 in enumerate(s2):
            insertions = previous_row[j + 1] + 1
            deletions = current_row[j] + 1
            substitutions = previous_row[j] + (c1 != c2)
            current_row.append(min(insertions, deletions, substitutions))
        previous_row = current_row

    return previous_row[-1]

def jaro_distance(s1, s2):
    # If both strings are equal, Jaro distance is 1
    if s1 == s2:
        return 1.0
    
    # Calculate the matching range
    match_distance = (max(len(s1), len(s2)) // 2) - 1
    
    # Initialize variables for matches, transpositions, and common characters
    matches = 0
    transpositions = 0
    common_chars = []
    
    # Iterate through each character in the first string
    for i, ch in enumerate(s1):
        # Search for the character in the second string within the matching range
        start = max(0, i - match_distance)
        end = min(i + match_distance + 1, len(s2))
        if ch in s2[start:end]:
            matches += 1
            common_chars.append(ch)
            s2 = s2[:s2.index(ch)] + '*' + s2[s2.index(ch) + 1:]
    
    # Check if there are no matches
    if matches == 0:
        return 0.0
    
    # Count transpositions
    for ch1, ch2 in zip(s1, s2):
        if ch1 != ch2:
            transpositions += 1
    
    # Calculate Jaro distance
    jaro = ((matches / len(s1)) + (matches / len(s2)) + ((matches - (transpositions / 2)) / matches)) / 3.0
    
    # Adjust for common prefix up to a maximum of 4 characters
    prefix_length = 0
    for ch1, ch2 in zip(s1, s2):
        if ch1 == ch2:
            prefix_length += 1
        else:
            break
        if prefix_length == 4:
            break
    
    jaro_winkler = jaro + (prefix_length * 0.1 * (1 - jaro))
    
    return jaro_winkler
# Streamlit UI
st.title("Resume Matching System")

designation = st.text_input("Designation", "")
jd = st.text_area("Job Description")
uploaded_file = st.file_uploader("Upload Your Resume", type="pdf", help="Please upload the pdf")

if st.button("Submit"):
    if uploaded_file is not None:
        resume_text = ""  
        pdf_file = pdfplumber.open(uploaded_file)
        for page in pdf_file.pages:
            resume_text += page.extract_text()
        pdf_file.close()

        print(resume_text)

        texts = [jd, resume_text, designation]
        #inputs = ["Job Description", "Resume Text", "Designation"]
        embeddings = get_embeddings(texts, tokenizer, model, API_URL, HEADERS)
        # Prepare a list of documents to insert
        documents = []
        for text, embedding in zip(texts, embeddings):
            #st.write(f"{text} Embedding:")
            st.write(embedding)
            metadata = {
                "source": "streamlit",
                "text_type": "Job Description" if text == jd else "Resume Text" if text == resume_text else "Designation"
            }

            document = {
                "text": text,
                "embedding": embedding.tolist(),  # Convert numpy array to list
                "metadata": metadata
            }
            documents.append(document)

         # Insert documents into MongoDB
        insert_documents(documents)

        
        # Calculate cosine similarity
        jd_embedding, resume_embedding, designation_embedding = embeddings

        # Calculate cosine similarity between job description and resume
        jd_resume_similarity = cosine_similarity([jd_embedding], [resume_embedding])[0][0]

        # Calculate cosine similarity between job description and designation
        jd_designation_similarity = cosine_similarity([jd_embedding], [designation_embedding])[0][0]

        # Calculate cosine similarity between resume and designation
        resume_designation_similarity = cosine_similarity([resume_embedding], [designation_embedding])[0][0]

        # Display similarity scores
        st.write("Cosine Similarity between Job Description and Resume:", jd_resume_similarity)
        st.write("Cosine Similarity between Job Description and Designation:", jd_designation_similarity)
        st.write("Cosine Similarity between Resume and Designation:", resume_designation_similarity)

        # Calculate Jaccard similarity
        jd_resume_jaccard_similarity = jaccard_similarity(jd, resume_text)
        jd_designation_jaccard_similarity = jaccard_similarity(jd, designation)
        resume_designation_jaccard_similarity = jaccard_similarity(resume_text, designation)

        # Display Jaccard similarity scores
        st.write("Jaccard Similarity between Job Description and Resume:", jd_resume_jaccard_similarity)
        st.write("Jaccard Similarity between Job Description and Designation:", jd_designation_jaccard_similarity)
        st.write("Jaccard Similarity between Resume and Designation:", resume_designation_jaccard_similarity)

        # Calculate Levenshtein distance
        jd_resume_levenshtein_distance = levenshtein_distance(jd, resume_text)
        jd_designation_levenshtein_distance = levenshtein_distance(jd, designation)
        resume_designation_levenshtein_distance = levenshtein_distance(resume_text, designation)

        # Display Levenshtein distance
        st.write("Levenshtein Distance between Job Description and Resume:", jd_resume_levenshtein_distance)
        st.write("Levenshtein Distance between Job Description and Designation:", jd_designation_levenshtein_distance)
        st.write("Levenshtein Distance between Resume and Designation:", resume_designation_levenshtein_distance)

        # Calculate Jaro-Winkler distance
        jd_resume_jw_distance = jaro_distance(jd, resume_text)
        jd_designation_jw_distance = jaro_distance(jd, designation)
        resume_designation_jw_distance = jaro_distance(resume_text, designation)

        # Display Jaro-Winkler distance
        st.write("Jaro-Winkler Distance between Job Description and Resume:", jd_resume_jw_distance)
        st.write("Jaro-Winkler Distance between Job Description and Designation:", jd_designation_jw_distance)
        st.write("Jaro-Winkler Distance between Resume and Designation:", resume_designation_jw_distance)
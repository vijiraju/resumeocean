import streamlit as st
from transformers import AutoTokenizer, AutoModel
import torch
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from pymongo import MongoClient
import os
import openai
import PyPDF2 as pdf
from dotenv import load_dotenv
import json
import pdfplumber
import requests


# Initialize tokenizer and model from Hugging Face
tokenizer = AutoTokenizer.from_pretrained('sentence-transformers/all-MiniLM-L12-v2')
model = AutoModel.from_pretrained('sentence-transformers/all-MiniLM-L12-v2')

# API URL for generating embeddings
API_URL = "https://api-inference.huggingface.co/models/sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
HEADERS = {"Authorization": "Bearer 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"}

# Threshold length for when to use the API
THRESHOLD_LENGTH = 1000  # Adjust as needed

# MongoDB connection
MONGODB_URI = os.getenv("mongodb://localhost:27017/?directConnection=true")
client = MongoClient(MONGODB_URI)
db = client["resume_db"]
collection = db["res_coll"]

# Function to calculate mean pooling
def mean_pooling(model_output, attention_mask):
    token_embeddings = model_output[0]  # First element of model_output contains all token embeddings
    input_mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
    return torch.sum(token_embeddings * input_mask_expanded, 1) / torch.clamp(input_mask_expanded.sum(1), min=1e-9)

# Function to generate embeddings for a single text
def generate_embedding(text, tokenizer, model, threshold_length, API_URL, headers):
    sentence_embedding = None
    if len(text) > threshold_length:
        response = requests.post(API_URL, headers=headers, json={"inputs": {"source_sentence": text, "sentences": [text]}})
        output = response.json()
        print(output)  # Print the output for debugging purposes
        if isinstance(output, list) and len(output) > 0:
            # Extracting the first item from the list and checking if it's a dictionary
            output_dict = output[0]
            if isinstance(output_dict, dict):
                # Extract sentence_embedding if available
                sentence_embedding = output_dict.get("sentence_embedding")
    else:
        encoded_input = tokenizer(text, padding=True, truncation=True, return_tensors='pt')
        with torch.no_grad():
            model_output = model(**encoded_input)
        sentence_embedding = mean_pooling(model_output, encoded_input['attention_mask'])
        sentence_embedding = sentence_embedding.cpu().numpy().reshape(1, -1)
    return sentence_embedding

# Function to generate embeddings for text chunks
def generate_embeddings_for_chunks(text_chunks, tokenizer, model, threshold_length, API_URL, headers):
    embeddings = np.vstack([generate_embedding(chunk, tokenizer, model, threshold_length, API_URL, headers) for chunk in text_chunks])
    return embeddings

def store_data_to_mongodb(data):
    try:
        # Check if the document already exists in the collection
        existing_document = collection.find_one({"designation": data["designation"]})
        if existing_document:
            # Update existing document if needed
            # Here, you might want to decide whether to update existing data or not
            pass
        else:
            # Insert new document if it doesn't exist
            collection.insert_one(data)
        st.success("Data stored successfully in MongoDB.")

    except DuplicateKeyError:
        # Handle duplicate key error if needed (e.g., log error, provide feedback to user)
        st.error("Error: Duplicate key encountered while storing data.")

# Streamlit UI
st.title("Resume Matching System")

designation = st.text_input("Designation", "")
jd = st.text_area("Job Description")
uploaded_file = st.file_uploader("Upload Your Resume", type="pdf", help="Please upload the pdf")

if st.button("Submit"):
    if uploaded_file is not None:
        resume_text = ""  
        pdf_file = pdfplumber.open(uploaded_file)
        for page in pdf_file.pages:
            resume_text += page.extract_text()
        pdf_file.close()

        # Generate embeddings for job description, resume, and designation
        jd_embedding = generate_embedding(jd, tokenizer, model, THRESHOLD_LENGTH, API_URL, HEADERS)
        resume_embedding = generate_embedding(resume_text, tokenizer, model, THRESHOLD_LENGTH, API_URL, HEADERS)
        designation_embedding = generate_embedding(designation, tokenizer, model, THRESHOLD_LENGTH, API_URL, HEADERS)

        # Calculate cosine similarity
        if jd_embedding is not None and resume_embedding is not None:
            jd_resume_similarity = cosine_similarity(jd_embedding, resume_embedding)
            st.write("Cosine Similarity between Job Description and Resume:", jd_resume_similarity[0][0])

        # Calculate cosine similarity between designation and resume/job description if available
        if resume_embedding is not None and designation_embedding is not None:
            designation_resume_similarity = cosine_similarity(designation_embedding, resume_embedding)
            designation_jd_similarity = cosine_similarity(designation_embedding, jd_embedding)
            st.write("Cosine Similarity between Designation and Resume:", designation_resume_similarity[0][0])
            st.write("Cosine Similarity between Designation and Job Description:", designation_jd_similarity[0][0])

        # Display embeddings and cosine similarity values
        st.write("Job Description Embedding:")
        st.write(jd_embedding)
        st.write("Resume Embedding:")
        st.write(resume_embedding)
        st.write("Designation Embedding:")
        st.write(designation_embedding)
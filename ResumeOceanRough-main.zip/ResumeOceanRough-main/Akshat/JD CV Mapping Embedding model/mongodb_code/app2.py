import streamlit as st
from transformers import AutoTokenizer, AutoModel
import torch
import numpy as np
import pandas as pd
#from sklearn.metrics.pairwise import cosine_similarity
from pymongo import MongoClient
import os
import openai
import pdfplumber
import requests
import numpy as np
from scipy.spatial.distance import cosine, euclidean, cityblock
from Levenshtein import distance as levenshtein_distance
import textdistance

# Initialize tokenizer and model from Hugging Face
tokenizer = AutoTokenizer.from_pretrained('sentence-transformers/all-mpnet-base-v2')
model = AutoModel.from_pretrained('sentence-transformers/all-mpnet-base-v2')

# API URL for generating embeddings
API_URL = "https://api-inference.huggingface.co/models/sentence-transformers/all-mpnet-base-v2"
HEADERS = {"Authorization": "Bearer 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"}

# OpenAI API key
OPENAI_API_KEY = "API_KEY"
#openai.api_key = OPENAI_API_KEY

# MongoDB connection
MONGODB_URI = os.getenv("mongodb://localhost:27017/?directConnection=true")
client = MongoClient(MONGODB_URI)
db = client["resume_db"]
collection = db["res_coll"]

# Function to calculate mean pooling
def mean_pooling(model_output, attention_mask):
    token_embeddings = model_output[0] # First element of model_output contains all token embeddings
    input_mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
    return torch.sum(token_embeddings * input_mask_expanded, 1) / torch.clamp(input_mask_expanded.sum(1), min=1e-9)

def generate_embedding(text, tokenizer, model, API_URL, headers):
    inputs = tokenizer(text, padding=True, truncation=True, return_tensors="pt")
    with torch.no_grad():
        outputs = model(**inputs)
    embeddings = outputs.last_hidden_state.mean(dim=1).squeeze().numpy()
    return embeddings

def get_embeddings(texts, tokenizer, model, API_URL, headers):
    embeddings = []
    for text in texts:
        embedding = generate_embedding(text, tokenizer, model, API_URL, headers)
        embeddings.append(embedding)
    return embeddings

def insert_documents(documents):
    if documents:
        collection.insert_many(documents)
        print("Inserted", len(documents), "documents into MongoDB.")
    else:
        print("No documents to insert.")

def calculate_cosine_similarity(embedding1, embedding2):
    return cosine(embedding1, embedding2)

def calculate_jaccard_similarity(text1, text2):
    return textdistance.jaccard.normalized_similarity(text1, text2)

def calculate_levenshtein_distance(text1, text2):
    return levenshtein_distance(text1, text2)

def calculate_jaro_winkler_distance(s1, s2):
    return textdistance.jaro_winkler.normalized_similarity(s1, s2)

def calculate_manhattan_distance(embedding1, embedding2):
    return cityblock(embedding1, embedding2)

def calculate_euclidean_distance(embedding1, embedding2):
    return euclidean(embedding1, embedding2)

def calculate_distances_and_similarities(embeddings, texts, labels):
    similarities = []
    distances = []
    
    for i in range(len(embeddings)):
        for j in range(i+1, len(embeddings)):
            if (i == 0 and j == 1) or (i == 1 and j > 1) or (i == 0 and j > 1):  # JD vs. resume, resume vs. top 5 suggested designations, JD vs. top 5 suggested designations
                cosine_similarity = calculate_cosine_similarity(embeddings[i], embeddings[j])
                jaccard_similarity = calculate_jaccard_similarity(texts[i], texts[j])
                levenshtein_dist = calculate_levenshtein_distance(texts[i], texts[j])
                jw_distance = calculate_jaro_winkler_distance(texts[i], texts[j])
                manhattan_dist = calculate_manhattan_distance(embeddings[i], embeddings[j])
                euclidean_dist = calculate_euclidean_distance(embeddings[i], embeddings[j])
                
                similarities.append((cosine_similarity, jaccard_similarity, jw_distance, labels[i], labels[j]))
                distances.append((manhattan_dist, euclidean_dist, levenshtein_dist, labels[i], labels[j]))
            
    return similarities, distances


def get_designation_suggestions(jd_text, openai_api_key):
    openai.api_key = openai_api_key
    # Specify the model and role
    model_name = "gpt-3.5-turbo-16k-0613"
    role = f"Extract all the best designations extracted from the job description '{jd_text}' based on the LLama Language Model (LLM), with the most appropriate designation listed first and separated by comma. If no designations found, directly write only 'No information available' as output."

    messages = [
        {"role": "system", "content": role},
        {"role": "user", "content": jd_text},
    ]
    # Create the ChatGPT completion
    response = openai.ChatCompletion.create(
        model=model_name,
        messages=messages,
        max_tokens=2048,
        temperature=0.6,
        stop=None,
        n=1
    )
    # Extract content from the top choices
    # suggestions = [choice["message"]["content"] for choice in response["choices"]]
    # return suggestions
    suggestions_str = response["choices"][0]["message"]["content"]
    suggestions_list = [s.strip() for s in suggestions_str.split(',')]
    return suggestions_list[:5]  

# Streamlit UI
st.title("Resume Matching System")

jd = st.text_area("Job Description")
uploaded_file = st.file_uploader("Upload Your Resume", type="pdf", help="Please upload the pdf")

if st.button("Submit"):
    if uploaded_file is not None:
        resume_text = ""  
        pdf_file = pdfplumber.open(uploaded_file)
        for page in pdf_file.pages:
            resume_text += page.extract_text()
        pdf_file.close()

        # Get designation suggestions
        designation_suggestion = get_designation_suggestions(jd, OPENAI_API_KEY)
        #unique_designation_suggestions = list(set(designation_suggestion)) 

        st.write("Top 5 suggested designations based on provided JD:")
        for i, suggestion in enumerate(designation_suggestion, start=1):
            st.write(f"{i}. {suggestion}")
            print(f"{i}. {suggestion}\n")

        # Create embeddings for JD, resume, and suggested designations
        texts = {'JD': jd, 'Resume': resume_text}
        texts.update({f"Designation {i+1}": suggestion for i, suggestion in enumerate(designation_suggestion)})
        labels = list(texts.keys())
        embeddings = get_embeddings(texts.values(), tokenizer, model, API_URL, HEADERS)

        print(texts)

        #Calculate similarities and distances
        st.write("Similarity and Distance Metrics:")
        similarities, distances = calculate_distances_and_similarities(embeddings, list(texts.values()), labels)

        # Create a table to display similarity scores
        # Create a table to display similarity scores
        similarity_data = {
            "Matches Considered": [],
            "Cosine Similarity": [],
            "Jaccard Similarity": [],
            "Levenshtein Distance": [],
            "Jaro-Winkler Distance": [],
            "Euclidean Distance": [],
            "Manhattan Distance": []
        }

        for i, ((cosine_similarity, jaccard_similarity, jw_distance, label1, label2), 
                (manhattan_dist, euclidean_dist, levenshtein_dist, _, _)) in enumerate(zip(similarities, distances)):
            similarity_data["Matches Considered"].append(f"{label1} - {label2}")
            similarity_data["Cosine Similarity"].append(cosine_similarity)
            similarity_data["Jaccard Similarity"].append(jaccard_similarity)
            similarity_data["Levenshtein Distance"].append(levenshtein_dist)
            similarity_data["Jaro-Winkler Distance"].append(jw_distance)
            similarity_data["Euclidean Distance"].append(euclidean_dist)
            similarity_data["Manhattan Distance"].append(manhattan_dist)

        similarity_table = pd.DataFrame(similarity_data)
        st.table(similarity_table)

        # Insert documents into MongoDB
        documents = []
        for text, embedding, label in zip(texts, embeddings, labels):
            metadata = {
                "source": "streamlit",
                "text_type": label
            }
            document = {
                "text": text,
                "embedding": embedding.tolist(),  # Convert numpy array to list
                "metadata": metadata
            }
            documents.append(document)

        insert_documents(documents)

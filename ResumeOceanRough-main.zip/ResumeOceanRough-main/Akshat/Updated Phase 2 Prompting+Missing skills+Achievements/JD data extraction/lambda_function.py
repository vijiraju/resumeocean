import openai
import json
import requests


import logging
from pathlib import Path

# Configure the logger
logging.basicConfig(
    filename='extract_data.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

# version 3
def lambda_handler(event, context):
    # Extract HTTP method and path from the event
    http_method = event.get('requestContext', {}).get('http', {}).get('method') or event.get('httpMethod')
    path = event.get('path')
    
    if not http_method:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'HTTP method not found in event'})
        }
    
    # Handle GET request at root path
    if http_method == 'GET' and path == '/':
        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Hello, Flask on AWS Lambda!'})
        }
        
##################################################################################################################
        
    # Handle POST request for '/process_designation'
    elif http_method == 'POST' and path == '/process_designation':
        try:
            body = json.loads(event['body'])
        except json.JSONDecodeError:
            return {'statusCode': 400, 'body': json.dumps({'error': 'Invalid JSON format in request body'})}

        jd_text = body.get('jd_text')
        api_key = body.get('api_key')
        resumejobdesig = body.get('resumejobdesig')
        

        if not resumejobdesig or not jd_text or not api_key:
            return {'statusCode': 400, 'body': json.dumps({'error': 'Missing jd text or API key or resumejobdesig missing'})}
        
        # improvements and score
        jdclass = JDprocessor()
    
        jd_desig = jdclass.jddesig(api_key,jd_text)
        logging.info(f"{jd_desig}")
        jaroscore = jdclass.jaro(jd_desig,resumejobdesig)
        logging.info(f"{jaroscore}")
        promptforimp = jdclass.evaluate_designation(jd_desig, resumejobdesig, jaroscore)
        logging.info(f"{promptforimp}")
        improvements = jdclass.openaigpt(api_key, promptforimp)
        logging.info(f"{improvements}")
        # suggestions = jdclass.parse_suggestions(improvements)
        # logging.info(f"{suggestions}")
        # result = jdclass.create_json_body(jd_desig, resumejobdesig, jaroscore, suggestions)
        result = jdclass.create_json_body_designation(jd_desig, resumejobdesig, jaroscore, improvements)
        logging.info(f"{result}")
        

        # Assuming extract_data_from_text is a function you have defined elsewhere
        data = json.dumps(result)
        logging.info(f"{data}")

        if data:
            return {
                'statusCode': 200,
                'body': data,
                "headers": {
                    "Access-Control-Allow-Origin": "*", 
                    "Access-Control-Allow-Headers": "Content-Type, Authorization",
                    "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
                }
            }
        else:
            return {'statusCode': 500, 'body': json.dumps({'error': 'Failed to process jd text'})}
        
########################################################      
  
    # Handle POST request for '/process_location'
    elif http_method == 'POST' and path == '/process_location':
        try:
            body = json.loads(event['body'])
        except json.JSONDecodeError:
            return {'statusCode': 400, 'body': json.dumps({'error': 'Invalid JSON format in request body'})}

        jd_text = body.get('jd_text')
        api_key = body.get('api_key')
        resumelocation = body.get('resumelocation')
        

        if not resumelocation or not jd_text or not api_key:
            return {'statusCode': 400, 'body': json.dumps({'error': 'Missing jd text or API key or resumelocation missing'})}
        
        # improvements and score
        jdclass = JDprocessor()
    
        jd_location = jdclass.jdlocation(api_key,jd_text)
        logging.info(f"{jd_location}")
        levenshtein_score = jdclass.levenshtein(jd_location,resumelocation)
        logging.info(f"{levenshtein_score}")
        # jaccard_score = jdclass.jaccard(jd_location,resumelocation)
        # logging.info(f"{jaccard_score}")
        # promptforimp = jdclass.evaluate_location(jd_location, resumelocation, levenshtein_score, jaccard_score)
        promptforimp = jdclass.evaluate_location(jd_location, resumelocation, levenshtein_score)
        logging.info(f"{promptforimp}")
        improvements = jdclass.openaigpt(api_key, promptforimp)
        logging.info(f"{improvements}")
        # suggestions = jdclass.parse_suggestions(improvements)
        # logging.info(f"{suggestions}")    
        # scores_list = [jaccard_score, levenshtein_score]
        # result = jdclass.create_json_body(jd_location, resumelocation, scores_list, improvements)
        result = jdclass.create_json_body_location(jd_location, resumelocation, levenshtein_score, improvements)

        logging.info(f"{result}")
        

        # Assuming extract_data_from_text is a function you have defined elsewhere
        data = json.dumps(result)
        logging.info(f"{data}")

        if data:
            return {
                'statusCode': 200,
                'body': data,
                "headers": {
                    "Access-Control-Allow-Origin": "*", 
                    "Access-Control-Allow-Headers": "Content-Type, Authorization",
                    "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
                }
            }
        else:
            return {'statusCode': 500, 'body': json.dumps({'error': 'Failed to process jd text'})}
        
###########################################################################################################
  
    # Handle POST request for '/process_skills'
    elif http_method == 'POST' and path == '/process_skills':
        try:
            body = json.loads(event['body'])
        except json.JSONDecodeError:
            return {'statusCode': 400, 'body': json.dumps({'error': 'Invalid JSON format in request body'})}

        jd_text = body.get('jd_text')
        api_key = body.get('api_key')
        resumeskills = body.get('resumeskills')
        

        if not resumeskills or not jd_text or not api_key:
            return {'statusCode': 400, 'body': json.dumps({'error': 'Missing jd text or API key or resumeskills missing'})}
        
        # improvements and score
        jdclass = JDprocessor()
        
        jd_skills = jdclass.jdskills(api_key,jd_text)
        logging.info(f"{jd_skills}")
        jaccard_score = jdclass.jaccard(jd_skills,resumeskills)
        logging.info(f"{jaccard_score}")
        cosine_score = jdclass.cosine(jd_skills,resumeskills)
        logging.info(f"{cosine_score}")
        promptforimp = jdclass.evaluate_skills(jd_skills, resumeskills, cosine_score, jaccard_score)
        logging.info(f"{promptforimp}")
        improvements = jdclass.openaigpt(api_key, promptforimp)
        logging.info(f"{improvements}")
        # suggestions = jdclass.parse_suggestions(improvements)
        # logging.info(f"{suggestions}")    
        scores_list = [cosine_score, jaccard_score]
        result = jdclass.create_json_body_skills(jd_skills, resumeskills, scores_list, improvements)
        logging.info(f"{result}")
        

        # Assuming extract_data_from_text is a function you have defined elsewhere
        data = json.dumps(result)
        logging.info(f"{data}")

        if data:
            return {
                'statusCode': 200,
                'body': data,
                "headers": {
                    "Access-Control-Allow-Origin": "*", 
                    "Access-Control-Allow-Headers": "Content-Type, Authorization",
                    "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
                }
            }
        else:
            return {'statusCode': 500, 'body': json.dumps({'error': 'Failed to process jd text'})}
        
###########################################################################################################

    # Handle POST request for '/process_experience'
    elif http_method == 'POST' and path == '/process_experience':
        try:
            body = json.loads(event['body'])
        except json.JSONDecodeError:
            return {'statusCode': 400, 'body': json.dumps({'error': 'Invalid JSON format in request body'})}

        jd_text = body.get('jd_text')
        api_key = body.get('api_key')
        resumeexperience = body.get('resumeexperience')
        

        if not resumeexperience or not jd_text or not api_key:
            return {'statusCode': 400, 'body': json.dumps({'error': 'Missing jd text or API key or resumeexperience missing'})}
        
        # improvements and score
        jdclass = JDprocessor()
        
        jd_experience = jdclass.jdexperience(api_key,jd_text)
        logging.info(f"{jd_experience}")
        manhattan_score = jdclass.manhattan(jd_experience,resumeexperience)
        logging.info(f"{manhattan_score}")
        euclidean_score = jdclass.euclidean(jd_experience,resumeexperience)
        logging.info(f"{euclidean_score}")
        promptforimp = jdclass.evaluate_experience(jd_experience, resumeexperience, euclidean_score, manhattan_score)
        logging.info(f"{promptforimp}")
        improvements = jdclass.openaigpt(api_key, promptforimp)
        logging.info(f"{improvements}")
        # suggestions = jdclass.parse_suggestions(improvements)
        # logging.info(f"{suggestions}")
        scores_list = [euclidean_score, manhattan_score]
        result = jdclass.create_json_body_experience(jd_experience, resumeexperience, scores_list, improvements)
        logging.info(f"{result}")
        

        # Assuming extract_data_from_text is a function you have defined elsewhere
        data = json.dumps(result)
        logging.info(f"{data}")

        if data:
            return {
                'statusCode': 200,
                'body': data,
                "headers": {
                    "Access-Control-Allow-Origin": "*", 
                    "Access-Control-Allow-Headers": "Content-Type, Authorization",
                    "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
                }
            }
        else:
            return {'statusCode': 500, 'body': json.dumps({'error': 'Failed to process jd text'})}
        
###########################################################################################################

    # Handle POST request for '/process_responsibilities'
    elif http_method == 'POST' and path == '/process_responsibilities':
        try:
            body = json.loads(event['body'])
        except json.JSONDecodeError:
            return {'statusCode': 400, 'body': json.dumps({'error': 'Invalid JSON format in request body'})}

        jd_text = body.get('jd_text')
        api_key = body.get('api_key')
        resumeresponsibilities = body.get('resumeresponsibilities')
        

        if not resumeresponsibilities or not jd_text or not api_key:
            return {'statusCode': 400, 'body': json.dumps({'error': 'Missing jd text or API key or resumeresponsibilities missing'})}
        
        # improvements and score
        jdclass = JDprocessor()
        
        jd_responsibilities = jdclass.jdresponsibilities(api_key,jd_text)
        logging.info(f"{jd_responsibilities}")
        jaccard_score = jdclass.jaccard(jd_responsibilities,resumeresponsibilities)
        logging.info(f"{jaccard_score}")
        cosine_score = jdclass.cosine(jd_responsibilities,resumeresponsibilities)
        logging.info(f"{cosine_score}")
        promptforimp = jdclass.evaluate_responsibilities(jd_responsibilities, resumeresponsibilities, cosine_score, jaccard_score)
        logging.info(f"{promptforimp}")
        improvements = jdclass.openaigpt(api_key, promptforimp)
        logging.info(f"{improvements}")
        # suggestions = jdclass.parse_suggestions(improvements)
        # logging.info(f"{suggestions}")    
        scores_list = [cosine_score, jaccard_score]
        result = jdclass.create_json_body_responsibilities(jd_responsibilities, resumeresponsibilities, scores_list, improvements)
        logging.info(f"{result}")
        

        # Assuming extract_data_from_text is a function you have defined elsewhere
        data = json.dumps(result)
        logging.info(f"{data}")

        if data:
            return {
                'statusCode': 200,
                'body': data,
                "headers": {
                    "Access-Control-Allow-Origin": "*", 
                    "Access-Control-Allow-Headers": "Content-Type, Authorization",
                    "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
                }
            }
        else:
            return {'statusCode': 500, 'body': json.dumps({'error': 'Failed to process jd text'})}
        
###########################################################################################################

    # Handle POST request for '/process_achievements'
    elif http_method == 'POST' and path == '/process_achievements':
        try:
            body = json.loads(event['body'])
        except json.JSONDecodeError:
            return {'statusCode': 400, 'body': json.dumps({'error': 'Invalid JSON format in request body'})}

        jd_text = body.get('jd_text')
        api_key = body.get('api_key')
        resume_text = body.get('resume_text')
        

        if not resume_text or not jd_text or not api_key:
            return {'statusCode': 400, 'body': json.dumps({'error': 'Missing jd text or API key or resume_text missing'})}
        
        # improvements and score
        jdclass = JDprocessor()
        
        promptingachievements = jdclass.evaluate_achievements(jd_text, resume_text)
        logging.info(f"{promptingachievements}")
        result = jdclass.openaigpt_for_achievements(api_key, promptingachievements)
        logging.info(f"{result}")
        
        # Assuming extract_data_from_text is a function you have defined elsewhere
        data = json.dumps(result)
        logging.info(f"{data}")

        if data:
            return {
                'statusCode': 200,
                'body': data,
                "headers": {
                    "Access-Control-Allow-Origin": "*", 
                    "Access-Control-Allow-Headers": "Content-Type, Authorization",
                    "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
                }
            }
        else:
            return {'statusCode': 500, 'body': json.dumps({'error': 'Failed to process jd text'})}

###########################################################################################################

        
    else:
        return {'statusCode': 405, 'body': json.dumps({'error': 'Method Not Allowed'})}



class JDprocessor:
    
    def jddesig(self, apikey,jd):
        url = "https://t3goia9n2d.execute-api.ap-south-1.amazonaws.com/dev/process_designation"
        headers = {"Content-Type": "application/json"}
        payload = {
            "api_key": apikey,
            "jd_text": jd
        }
        response = requests.post(url, json=payload, headers=headers)

        if response.status_code == 200:
            print("API Call Successful")
            print("Response:", response.json())
        else:
            print("API Call Failed")
            print("Status Code:", response.status_code)
            print("Response:", response.text)
        jddesig = json.loads(response.json())['postDesignation']
        # print(jddesig)
        return jddesig
    
    def jdlocation(self, apikey, jd):
        url = "https://t3goia9n2d.execute-api.ap-south-1.amazonaws.com/dev/process_location"
        headers = {"Content-Type": "application/json"}

        payload = {
            "api_key": apikey,
            "jd_text": jd
        }

        response = requests.post(url, json=payload, headers=headers)

        if response.status_code == 200:
            print("API Call Successful")
            print("Response:", response.json())
        else:
            print("API Call Failed")
            print("Status Code:", response.status_code)
            print("Response:", response.text)
        response1_data = json.loads(response.json())
        Location = response1_data.get("address")

        # jddlocation = response.json()['address']
        # print(response.json())
        return Location
    
    
    def jdskills(self, apikey, jd):
        url = "https://t3goia9n2d.execute-api.ap-south-1.amazonaws.com/dev/process_skills"
        headers = {"Content-Type": "application/json"}

        payload = {
            "api_key": apikey,
            "jd_text": jd
        }

        response = requests.post(url, json=payload, headers=headers)

        if response.status_code == 200:
            print("API Call Successful")
            print("Response:", response.json())
        else:
            print("API Call Failed")
            print("Status Code:", response.status_code)
            print("Response:", response.text)
        # jdskills = json.loads(response.json())['skills']
        response1_data = json.loads(response.json())
        Skills = response1_data.get("skills")
        return Skills
    
    def jdexperience(self, apikey,jd):
        url = "https://t3goia9n2d.execute-api.ap-south-1.amazonaws.com/dev/process_experience"
        headers = {"Content-Type": "application/json"}
        payload = {
            "api_key": apikey,
            "jd_text": jd
        }
        response = requests.post(url, json=payload, headers=headers)

        if response.status_code == 200:
            print("API Call Successful")
            print("Response:", response.json())
        else:
            print("API Call Failed")
            print("Status Code:", response.status_code)
            print("Response:", response.text)
        jddexperience = json.loads(response.json())['totalIndustryExperience']
        return jddexperience
    
    def jdresponsibilities(self, apikey,jd):
        url = "https://t3goia9n2d.execute-api.ap-south-1.amazonaws.com/dev/process_responsibilities"
        headers = {"Content-Type": "application/json"}
        payload = {
            "api_key": apikey,
            "jd_text": jd
        }
        response = requests.post(url, json=payload, headers=headers)

        if response.status_code == 200:
            print("API Call Successful")
            print("Response:", response.json())
        else:
            print("API Call Failed")
            print("Status Code:", response.status_code)
            print("Response:", response.text)
        response1_data = json.loads(response.json())
        Responsibilities = response1_data.get("responsibilities")
        return Responsibilities
    
    
    def jaro(self,jddesig,resumejobdesig):
        url = "https://hxheizds29.execute-api.us-east-1.amazonaws.com/dev/calculate_jaro_winkler_distance_score"
        headers = {"Content-Type": "application/json"}

        payload = {
            'processed_jd_text': jddesig,
            'processed_resume_text': resumejobdesig
        }

        response = requests.post(url, json=payload, headers=headers)

        if response.status_code == 200:
            print("API Call Successful")
            print("Response:", response.json())
        else:
            print("API Call Failed")
            print("Status Code:", response.status_code)
            print("Response:", response.text)
        jarowinkler_score = response.json()['jaro_winkler_distance_score']
        return jarowinkler_score
    
    def cosine(self, jdskills, resumeskills):
        url = "https://l6xdvung18.execute-api.us-east-1.amazonaws.com/dev/calculate_cosine_similarity_score"
        headers = {"Content-Type": "application/json"}

        payload = {
            'processed_jd_text': jdskills,
            'processed_resume_text': resumeskills
        }

        response = requests.post(url, json=payload, headers=headers)

        if response.status_code == 200:
            print("API Call Successful")
            print("Response:", response.json())
        else:
            print("API Call Failed")
            print("Status Code:", response.status_code)
            print("Response:", response.text)
        cosine_score = response.json()['cosine_similarity']
        return cosine_score
    
    def jaccard(self, jdskills, resumeskills):
        url = "https://l6xdvung18.execute-api.us-east-1.amazonaws.com/dev/calculate_jaccard_similarity_score"
        headers = {"Content-Type": "application/json"}

        payload = {
            'processed_jd_text': jdskills,
            'processed_resume_text': resumeskills
        }

        response = requests.post(url, json=payload, headers=headers)

        if response.status_code == 200:
            print("API Call Successful")
            print("Response:", response.json())
        else:
            print("API Call Failed")
            print("Status Code:", response.status_code)
            print("Response:", response.text)
        jaccard_score = response.json()['jaccard_similarity']
        # print("asdfghj", response.json())
        # response1_data = json.loads(response.json())
        # jaccard_score = response1_data.get("jaccard_similarity")
        
        return jaccard_score
    
    def levenshtein(self, jdlocation, resumelocation):
        url = "https://hxheizds29.execute-api.us-east-1.amazonaws.com/dev/calculate_levenshtein_distance_score"
        headers = {"Content-Type": "application/json"}

        payload = {
            'processed_jd_text': jdlocation,
            'processed_resume_text': resumelocation
        }

        response = requests.post(url, json=payload, headers=headers)

        if response.status_code == 200:
            print("API Call Successful")
            print("Response:", response.json())
        else:
            print("API Call Failed")
            print("Status Code:", response.status_code)
            print("Response:", response.text)
        
        levenshtein_score = response.json()['levenshtein_distance_score']
        # response1_data = json.loads(response.json())
        # levenshtein_score = response1_data.get("levenshtein_distance_score")
        return levenshtein_score
    
    def manhattan(self, jdexperience, resumeexperience):
        url = "https://hxheizds29.execute-api.us-east-1.amazonaws.com/dev/calculate_manhattan_distance_score"
        headers = {"Content-Type": "application/json"}

        payload = {
            'processed_jd_text': jdexperience,
            'processed_resume_text': resumeexperience
        }
        
        try:
            response = requests.post(url, json=payload, headers=headers)

            if response.status_code == 200:
                print("API Call Successful")
                print("Response:", response.json())
                manhattan_score = response.json().get('manhattan_distance_score')
                return manhattan_score
            else:
                # Check if 'No information available' is provided and handle it
                if payload['processed_jd_text'] == 'No information available':
                    payload['processed_jd_text'] = '0 years'
                    response = requests.post(url, json=payload, headers=headers)
                    if response.status_code == 200:
                        print("API Call Successful")
                        print("Response:", response.json())
                        manhattan_score = response.json().get('manhattan_distance_score')
                        return manhattan_score
                    else:
                        print("API Call Failed")
                        print("Status Code:", response.status_code)
                        return response.text
        except Exception as e:
            print("An error occurred:", e)
    
    def euclidean(self, jdexperience, resumeexperience):
        
        url = "https://hxheizds29.execute-api.us-east-1.amazonaws.com/dev/calculate_euclidean_distance_score"
        headers = {"Content-Type": "application/json"}

        payload = {
            'processed_jd_text': jdexperience,
            'processed_resume_text': resumeexperience
        }

        try:
            response = requests.post(url, json=payload, headers=headers)

            if response.status_code == 200:
                print("API Call Successful")
                print("Response:", response.json())
                euclidean_score = response.json().get('euclidean_distance_score')
                return euclidean_score
            else:
                # Check if 'No information available' is provided and handle it
                if payload['processed_jd_text'] == 'No information available':
                    payload['processed_jd_text'] = '0 years'
                    response = requests.post(url, json=payload, headers=headers)
                    if response.status_code == 200:
                        print("API Call Successful")
                        print("Response:", response.json())
                        euclidean_score = response.json().get('euclidean_distance_score')
                        return euclidean_score
                    else:
                        print("API Call Failed")
                        print("Status Code:", response.status_code)
                        return response.text
        except Exception as e:
            print("An error occurred:", e)
    
    
    def evaluate_designation(self,jd, resume, jaro_winkler):
         
        prompt = f'''
        Compare the specified designation in the job description with the designation stated in the resume and offer three suggestions for alignment. Format the suggestions as three bullet points.
        dont add the words improvements are: just provide the bullet points which should be crisp and clear 
        format :
        1.
        2.
        3.
        '''
        return prompt
    
    
    def evaluate_location(self, jd, resume, levenshtein):
        
        prompt = f'''
        Compare the specified location in the job description with the location stated in the resume and offer three suggestions for alignment. Format the suggestions as three bullet points.
        dont add the words improvements are: just provide the bullet points which should be crisp and clear 
        format :
        1.
        2.
        3.
        '''
        return prompt
    
    
    def evaluate_skills(self, jd, resume, cosine, jaccard):
              
        prompt = f'''if this was the original requirement in the jd {jd} skills and this is the resume {resume} skills which scored like 

         Cosine Similarity {cosine}: It would be useful for comparing the skills mentioned in the JD with those listed in resumes. By analyzing the similarity of the skill sets, it can help match candidates with the required skills.
        Jaccard Similarity {jaccard}: This metric can also be employed to assess the overlap between the sets of skills mentioned in the JD and resumes, providing a measure of how well they match.

        then analyze the score and the text and suggest 3 improvements which can be made in the resume 
        to match the job description (JD). All 3 improvements should end with full stops. 
        The first bullet point should contain the names of skills/keywords (Soft Skills + Technical Skills + Management Skills + Customer Service Skills) 
        that are present in the JD and not in the resume. The rest of the two points should provide 
        suggestions on how to improve the resume without mentioning the names of skills.

        Format:
        1. Missing skills in resume (Soft Skills + Technical Skills) - 
        2. 
        3.
        '''
        return prompt
    
    def evaluate_experience(self, jd, resume, eucleidean, manhattan):
        
        prompt = f'''
        Compare the specified ({jd}) experience in the job description  with the ({resume}) experience stated in the resume and offer three suggestions for alignment. Format the suggestions as three bullet points.
        dont add the words improvements are: just provide the bullet points which should be crisp and clear 
        format :
        1.
        2.
        3.
        '''
        
        return prompt
    
    def evaluate_responsibilities(self, jd, resume, cosine, jaccard):
        
        prompt = f'''if this was the original requirement in the jd ({jd}) responsibilities and this is the resume ({resume}) responsibilities which scored like 

        Cosine Similarity ({cosine}): It could be applied to compare the descriptions of responsibilities in the JD with the descriptions of past responsibilities in resumes. This would help identify candidates whose past experiences align closely with the job requirements.
        Jaccard Similarity ({jaccard}): Similarly, this metric can be used to assess the overlap in responsibilities mentioned in the JD and resumes, indicating how closely they match.

        then  analyze the score and the text and suggest 3 improvements which can be made in the resume to match the jd where all 3 improvements are 
        end with full stops, please add details on responsibilities , dont add the words improvements are: Present the suggestions as three bullet points, Format your text as a string in below format

        Format:
        1.
        2.
        3.
        '''
        return prompt
    
    # def evaluate_achievements(self, jd, resume):
    #     prompt = f""" 
    #     Provide the achievements observed from work experience or reflected in any form if any, that you find in the {resume}, Consider only the achievements which are relate to {jd}
    #     If the result is "No information available, then display "--" in this way or the format provided below
    #     Format:
    #     Achievements: --
    #     """
    #     return prompt
    
    # def evaluate_achievements(self, jd, resume):
    #     prompt = f"""Consider only the achievements which are relate to {jd}, provide the achievements which are matching with {jd} from the {resume}
    #     If the result is "No information available", then display "--" in this way or the format provided below
    #     Format:
    #     Achievements: --
    #     """
    #     return prompt
    
    def evaluate_achievements(self, jd, resume):
        prompt = f"""List achievements from the {resume} that relate to {jd}.
        If no matching information is found, display "--" in the format:
        format will be 
        Achievements: --
        """
        return prompt

        
    
    def openaigpt(self,api_key, prompt_input):
        openai.api_key = api_key
        model_name = "gpt-3.5-turbo-16k-0613"
        role = f"""You are the AI Chatbot Assistant to a Hiring Human resource executive having a conversation with the Hiring Human resource executive provided with a Resume, extract information based on the question and provide answers from it.
                    Just directly print one word answer, if you obtain something related to it, but thorougly check and provide optimal results please don't imitate by yourself only if the information present in the resume than print 
                    Provide 'No information available' when that particular value is not present in resume
                    Print all the results in different lines
                    """
        messages = [
            {"role": "system", "content": role},
            {"role": "user", "content": prompt_input},
        ]
        response = openai.ChatCompletion.create(
            model=model_name,
            messages=messages,
            max_tokens=2048,
            temperature=1,
            stop=None,
            n=1
        )
        return response["choices"][0]["message"]["content"]
    
    def openaigpt_for_achievements(self,api_key, prompt_input):
        openai.api_key = api_key
        model_name = "gpt-3.5-turbo-16k-0613"
        role = f"""You are the AI Chatbot Assistant to a Hiring Human resource executive having a conversation with the Hiring Human resource executive provided with a Resume, extract information based on the question and provide answers from it.
                    Just directly print one word answer, if you obtain something related to it, but thorougly check and provide optimal results please don't imitate by yourself only if the information present in the resume than print 
                    Provide '--' when that particular value is not present in resume
                    Print all the results in different lines
                    """
        messages = [
            {"role": "system", "content": role},
            {"role": "user", "content": prompt_input},
        ]
        response = openai.ChatCompletion.create(
            model=model_name,
            messages=messages,
            max_tokens=2048,
            temperature=0.5,
            stop=None,
            n=1
        )
        return response["choices"][0]["message"]["content"]
    
    # def parse_suggestions(self, suggestions):
    #     improvements = []
    #     for suggestion in suggestions:
    #         # Using regex to extract text after the numbered list
    #         match = re.search(r'"improvements": "([^"]+)"', suggestion)
            
    #         if match:
    #             improvements.append(match.group(1).strip())
    #     return improvements
    
    def create_json_body_designation(self, jd, resume, scores, improvements):
    # Convert scores to a list if it's not already
        if not isinstance(scores, list):
            scores = [scores]

        score_serializable = [float(x) if isinstance(x, (int, float)) else None for x in scores]
        
        json_body = {
            "jd": jd,
            "resume": resume,
            "score_details" : ["String Similarity"],
            "score": score_serializable,
            "improvements": improvements
        }
        
        return json.dumps(json_body, indent=4)
    
    def create_json_body_location(self, jd, resume, scores, improvements):
    # Convert scores to a list if it's not already
        if not isinstance(scores, list):
            scores = [scores]

        score_serializable = [float(x) if isinstance(x, (int, float)) else None for x in scores]
        
        json_body = {
            "jd": jd,
            "resume": resume,
            "score_details" : ["Dissimilarity"],
            "score": score_serializable,
            "improvements": improvements
        }
        
        return json.dumps(json_body, indent=4)
    
    def create_json_body_skills(self, jd, resume, scores, improvements):
    # Convert scores to a list if it's not already
        if not isinstance(scores, list):
            scores = [scores]

        score_serializable = [float(x) if isinstance(x, (int, float)) else None for x in scores]
        
        json_body = {
            "jd": jd,
            "resume": resume,
            "score_details" : ["Synonymic similarity", "Keyword Similarity"],
            "score": score_serializable,
            "improvements": improvements
        }
        
        return json.dumps(json_body, indent=4)
    
    def create_json_body_experience(self, jd, resume, scores, improvements):
    # Convert scores to a list if it's not already
        if not isinstance(scores, list):
            scores = [scores]

        score_serializable = [float(x) if isinstance(x, (int, float)) else None for x in scores]
        
        json_body = {
            "jd": jd,
            "resume": resume,
            "score_details" : ["Experience Discrepancy", "Experience Delta"],
            "score": score_serializable,
            "improvements": improvements
        }
        
        return json.dumps(json_body, indent=4)
    
    def create_json_body_responsibilities(self, jd, resume, scores, improvements):
    # Convert scores to a list if it's not already
        if not isinstance(scores, list):
            scores = [scores]

        score_serializable = [float(x) if isinstance(x, (int, float)) else None for x in scores]
        
        json_body = {
            "jd": jd,
            "resume": resume,
            "score_details" : ["Synonymic similarity", "Keyword Similarity"],
            "score": score_serializable,
            "improvements": improvements
        }
        
        return json.dumps(json_body, indent=4)
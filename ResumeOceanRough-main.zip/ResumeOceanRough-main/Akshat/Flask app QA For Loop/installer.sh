#!/bin/bash

# Update package lists
sudo apt-get update

# Install Python 3
sudo apt-get install python3 -y

# Install pip for Python 3
sudo apt-get install python3-pip -y

# Install virtualenv using pip for Python 3
pip3 install --user virtualenv

# Create the virtual environment
sudo apt install python3.10-venv
python3 -m venv venv

# Activate the virtual environment
source venv/bin/activate

# Install Flask within the virtual environment
pip install openai==0.28
pip install flask
pip install requests
pip install PyPDF2
pip install docx
pip install exception
pip freeze >> requirements.txt

source venv/bin/activate

def prompt_input(key):
    prompt = {
        "id": "I want to create ID as primary key for my dataset, provide a unique value for this resume?   [Only provide single integer]",
        "fname": "What is the first name present in the resume?  [Only provide single string]",
        "lastName": "What is the last name present in the resume? [Only provide single string]",
        "dob": "What is the date of birth present in the resume? [Only provide single string]",
        "age": "What is the age (Current year - Date of Birth year) present in the resume? [Only provide single integer]",
        "email": "What is the email present in the resume? [Only provide single string]",
        "address": "What is the address present in the resume? [Only provide string]",
        "mobile": "What is the mobile number present in the resume? [Only provide single long integer]",
        "LinkedIn": "What is the LinkedIn profile present in the resume? [Only provide single link]",
        "orcidId": "What is the ORCID ID for the research papers present in the resume? [Only provide single id]",
        "totalIndustryExperience": "What is the total industry years of experience present in the resume. [Sum of all the years of experience and provide integer value+ 'years'] ",
        "summaryDetails": "What is the summary present in the resume? [Only provide 2 lines string]",
        "education_id": "Create education ID as primary key for my dataset, provide a unique value for this resume?  [Only provide single integer]",
        "degree": "What are the degrees(10th Degree, 12th Degree, Undergrad Degree, Postgrad Degree) present in the resume? Answer in points and keep it precise. [Only provide Degree names]" ,
        "course": "What are the courses taken in the degrees present in the resume? Answer in points and keep it precise. [Only provide string separated by ',']",
        "marks": "What are the CGPA (Undergrad Degree, Postgrad Degree) present in the resume? Answer in points and keep it precise. [Only provide integer]",
        "yearOfPass": "What are the years of passing (for 10th Degree, 12th Degree, Undergrad Degree, Postgrad Degree) present in the resume? Answer in points and keep it precise. [Only provide integer]",
        "boardsName": "What are the board's names (10th Degree, 12th Degree) present in the resume? Answer in points and keep it precise. [Only provide string]",
        "percentage": "What are the percentages (10th Degree, 12th Degree) present in the resume? Answer in points  [provide integer value + '% in 10th and % in 12th'] ",
        "Work Experience": "What is/are the work experience present in resume?  Answer in points and keep it precise. [Only provide single 2 lines string]",
        "employement_id": "Create an employment ID as primary key for my dataset, provide a unique value for this resume? [Only provide single integer]",
        'nameOfEmployer': "What are the names of the employers present in the resume for the particular job positions?  Answer in points and keep it precise. [Only provide string]",
        'department': "What are the departments he/she work with for the particular job positions that are present in the resume? Answer in points [Only provide string]",
        'postDesignation': "What are the post designations for the particular job positions present in the resume? Answer in points and keep it precise. [Only provide string]" ,
        'periodOfEmploymentFrom': "What are the starting tenure of work employment for the particular job positions in the resume? Answer in points and keep it precise. [Only provide integer]",
        'periodOfEmploymentTo': "What are the ending tenure of work employment for the particular job positions in the resume? Answer in points and keep it precise [Only provide single integer]",
        'grossSalary': "What is the gross salary for the particular job positions in the resume? [Answer in 'Rs/$' + integer value]",
        'responsibilities': "What are the job responsibilities for the particular job positions in the resume? Answer in points and keep it precise [Only provide string]",
        'Skills_id.': "Create an skills ID as primary key for my dataset, provide a unique value for this resume? [Only provide integer]",
        'skills': "What are the skills+frameworks+soft skills present in the resume? Answer in points [Only provide string separated by ',']",
        'selfRating': "How does the person is doing self rating, and extract from where it is present in the resume? [Only provide 2 line string]",
        'whyRate': "Why does the person is doing self rating, and extract from where it is present in the resume? [Only provide 2 line string]",
        'AwardsData_id': "Create an skills ID as primary key for my dataset, provide a unique value for this resume? [Only provide single integer]",
        'nameOfAawardsAchievements': "What are the name of awards/achievements+certificates+academic achievements  present in the resume? Answer in points and keep it precise [Only provide string]",
        'institutionsOrganization': "What are the institution/organization that provided the awards/ certificates to the person present in the resume? Answer in points and keep it precise [Only provide string]",
        'institutionsOrganizationName': "What are the institution/organization names that provided the awards/ certificates to the person present in the resume? Answer in points and keep it precise [Only provide string]",
        'detailsofAwards/Cerifications': "What are the details of awards/certifications present in the resume? [Only provide string in 2 lines]",
        'dateOfAwards': "What are the date of awards obtained present in the resume? Answer in points and keep it precise [Only provide integer]",
        'awardsTitle': "What are the awards title obtained present in the resume? Answer in points and keep it precise [Only provide string separated by ',']",
        'urlAwards': "What are the URL of awards present in the resume?  Answer in points and keep it precise [Only provide link]",
        'typesOfAchievment': "What are the types of awards/achievement (Under which category they belong ex- Techical, Marketting etc.) present in the resume? Answer in points and keep it precise [Only provide string]"
        
        
        "Just directly print one word answer, if you obtain something related to it, but thorougly check and provide optimal results"
        "Provide 'No information available' when that particular value is not present in resume" 
        "Print all the results in different lines"
    }
    return prompt.get(key)
import requests
from chatgptapikey import apikey
import PyPDF2
from docx import Document
from pathlib import Path

# URL for the Flask API endpoint
url = 'http://127.0.0.1:5000/process_resume'

# Replace this with the actual resume text you want to process

chatgptapikey = apikey()

def extract_text_from_pdf(pdf_path):
    """Extracts text from a PDF file."""
    text = ""
    with open(pdf_path, 'rb') as file:
        pdf_reader = PyPDF2.PdfReader(file)
        for page in pdf_reader.pages:
            text += page.extract_text() + "\n"  # Concatenate text from each page
    return text

def extract_data_from_docx(file_path):
    document = Document(file_path)
    data = []
    for paragraph in document.paragraphs:
        data.append(paragraph.text)
    return data


# Use Path to handle the file path
pdf_path = Path(r"uploads//DIKESH RAY.pdf")
# file_path = Path(r"E://Internship//StuValley//Dataset//Kushal Pratap Singh.docx")
pdftext = extract_text_from_pdf(pdf_path)
# docstext = extract_data_from_docx(file_path)

# The data to be sent in the POST request
data = {'pdf_resume_text': pdftext, 'api_key': chatgptapikey}

# Sending the POST request with JSON data
response = requests.post(url, json=data)

# Check if the request was successfull
if response.status_code == 200:
    # The API call was successful, you can process the response data
    print("Success!")
    print(response.json())  # This prints the structured data extracted from the resume text
else:
    # The API call failed, handle errors here
    print("Failed to process resume.")
    print(response.text)


# import requests
# from chatgptapikey import apikey
# import PyPDF2
# from pathlib import Path

# # URL for the Flask API endpoint
# url = 'http://127.0.0.1:5000/process_resume'

# # Replace this with the actual resume text you want to process
# chatgptapikey = apikey()

# def extract_text_from_pdf(pdf_path):
#     """Extracts text from a PDF file."""
#     text = ""
#     with open(pdf_path, 'rb') as file:
#         pdf_reader = PyPDF2.PdfReader(file)
#         for page in pdf_reader.pages:
#             text += page.extract_text() + "\n"  # Concatenate text from each page
#     return text

# # Use Path to handle the file path
# pdf_path = Path(r'uploads\Akshat Jain Resume Updated.pdf')
# pdftext = extract_text_from_pdf(pdf_path)

# # The data to be sent in the POST request
# data = {'resume_text': pdftext, 'api_key': chatgptapikey}

# try:
#     # Sending the POST request with JSON data
#     response = requests.post(url, json=data)

#     # Check if the request was successful
#     response.raise_for_status()

#     # The API call was successful, you can process the response data
#     print("Success!")
#     output = response.json()  # This prints the structured data extracted from the resume text
#     print(output) 
#     # Adjust the code to access the elements correctly based on the structure of output
#     # For example:
#     # sentence_embedding = output["sentence_embedding"]
#     # Perform further processing based on the extracted data

# except requests.exceptions.RequestException as e:
#     # The API call failed, handle errors here
#     print("Failed to process resume.")
#     print(e)

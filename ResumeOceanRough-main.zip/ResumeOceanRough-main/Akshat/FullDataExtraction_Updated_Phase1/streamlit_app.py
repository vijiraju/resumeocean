import streamlit as st
import datetime
import json
from app_certify import *

def main():
    # Define constants
    uploaded_file_path = r"E:\Internship\StuValley\Dataset\HIMANSHU TARIF.pdf"
    LLM_provider1 = "OpenAI" 
    cohere_api_key = 'cohere_api_key'

    # Retrieve API keys from environment variables
    openai_api_key, google_api_key, cohere_api_key = get_api_keys_from_local_env()
    
    # Run resume analyzer
    SCANNED_RESUME = resume_analyzer_main(
        llm=instantiate_LLM_main(temperature=0.0, top_p=0.95),
        documents=documents
    )

    # Display analyzed resume
    st.title("Extracted Data Phase 1:")
    st.write(SCANNED_RESUME)

if __name__ == "__main__":
    main()

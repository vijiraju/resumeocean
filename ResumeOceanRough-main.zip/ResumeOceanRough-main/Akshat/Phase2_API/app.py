from flask import Flask, request, jsonify
import nltk
from pathlib import Path
import string
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from sklearn.metrics.pairwise import cosine_similarity
import textdistance
from sklearn.feature_extraction.text import CountVectorizer

app = Flask(__name__)


nltk_data_dir = Path.cwd() / 'nltk_data'
if not nltk_data_dir.exists():
    nltk_data_dir.mkdir()

nltk.data.path.append(nltk_data_dir)

def download_nltk_resources():
    required_resources = ['punkt', 'stopwords', 'wordnet']
    for resource in required_resources:
        try:
            nltk.data.find(str(nltk_data_dir), resource)
        except LookupError:
            nltk.download(resource, download_dir= str(nltk_data_dir))

download_nltk_resources()

# Preprocessing functions
def convert_to_lowercase(text):
    return text.lower()

def remove_punctuation(text):
    table = str.maketrans('', '', string.punctuation)
    return text.translate(table)

def tokenizewords(text):
    return ' '.join(word_tokenize(text))

stop_words = set(stopwords.words('english'))
def remove_stopwords(tokens):
    return ' '.join([word for word in tokens.split(' ') if word not in stop_words])

lemmatizer = WordNetLemmatizer()
def lemmatize_text(tokens):
    return ' '.join([lemmatizer.lemmatize(word) for word in tokens.split()])

def preprocess_text(text):
    text = convert_to_lowercase(text)
    text = remove_punctuation(text)
    text = tokenizewords(text)
    text = remove_stopwords(text)
    text = lemmatize_text(text)
    return text

def calculate_cosine_similarity(str1, str2):
    vectorizer = CountVectorizer().fit_transform([str1, str2])
    vectors = vectorizer.toarray()
    return cosine_similarity([vectors[0]], [vectors[1]])[0][0]

def calculate_jaccard_similarity_score(str1, str2):
    return textdistance.jaccard.normalized_similarity(str1, str2)

def calculate_levenshtein_distance_score(str1, str2):
    return 1 - textdistance.levenshtein.normalized_distance(str1, str2)

def calculate_jaro_winkler_distance_score(str1, str2):
    return textdistance.jaro_winkler.normalized_similarity(str1, str2)

def calculate_manhattan_distance_score(str1, str2):
    distance = 0
    # Assuming both strings are of equal length
    for i in range(len(str1)):
        distance += abs(ord(str1[i]) - ord(str2[i]))
    return distance

def calculate_euclidean_distance_score(str1, str2):
    distance = 0
    # Assuming both strings are of equal length
    for i in range(len(str1)):
        distance += (ord(str1[i]) - ord(str2[i])) ** 2
    return distance ** 0.5

@app.route('/')
def index():
    return "Flask app is running"

@app.route('/process_text', methods=['POST'])
def process_text():
    data = request.json
    jd_text = data.get('jd_text')
    resume_text = data.get('resume_text')

    processed_jd_text = preprocess_text(jd_text)
    processed_resume_text = preprocess_text(resume_text)

    return jsonify({
        'processed_jd_text': processed_jd_text,
        'processed_text': processed_resume_text
    })

# Endpoint for calculating cosine similarity
@app.route('/calculate_cos_similarity', methods=['POST'])
def calculate_cos_similarity():
    data = request.json
    
    jd_text = data.get('processed_jd_text')
    resume_text = data.get('processed_text')
    
    # Calculate cosine similarity between JD and resume
    similarity_score = calculate_cosine_similarity(jd_text, resume_text)

    return jsonify({
        'cosine_similarity': similarity_score
    })
    
# Endpoint for calculating Jaccard similarity
@app.route('/calculate_jaccard_similarity', methods=['POST'])
def calculate_jaccard_similarity():
    data = request.json
    
    jd_text = data.get('processed_jd_text')
    resume_text = data.get('processed_text')
    
    # Calculate Jaccard similarity between JD and resume
    similarity_score = calculate_jaccard_similarity_score(jd_text, resume_text)

    return jsonify({
        'jaccard_similarity': similarity_score
    })

# Endpoint for calculating Levenshtein distance
@app.route('/calculate_levenshtein_distance', methods=['POST'])
def calculate_levenshtein_distance():
    data = request.json
    
    jd_text = data.get('processed_jd_text')
    resume_text = data.get('processed_text')
    
    # Calculate Levenshtein distance between JD and resume
    distance = calculate_levenshtein_distance_score(jd_text, resume_text)

    return jsonify({
        'levenshtein_distance': distance
    })

# Endpoint for calculating Jaro-Winkler distance
@app.route('/calculate_jaro_winkler_distance', methods=['POST'])
def calculate_jaro_winkler_distance():
    data = request.json
    
    jd_text = data.get('processed_jd_text')
    resume_text = data.get('processed_text')
    
    # Calculate Jaro-Winkler distance between JD and resume
    distance = calculate_jaro_winkler_distance_score(jd_text, resume_text)

    return jsonify({
        'jaro_winkler_distance': distance
    })

# Endpoint for calculating Manhattan distance
@app.route('/calculate_manhattan_distance', methods=['POST'])
def calculate_manhattan_distance():
    data = request.json
    
    jd_text = data.get('processed_jd_text')
    resume_text = data.get('processed_text')
    
    # Calculate Manhattan distance between JD and resume
    distance = calculate_manhattan_distance_score(jd_text, resume_text)

    return jsonify({
        'manhattan_distance': distance
    })

# Endpoint for calculating Euclidean distance
@app.route('/calculate_euclidean_distance', methods=['POST'])
def calculate_euclidean_distance():
    data = request.json
    
    jd_text = data.get('processed_jd_text')
    resume_text = data.get('processed_text')
    
    # Calculate Euclidean distance between JD and resume
    distance = calculate_euclidean_distance_score(jd_text, resume_text)

    return jsonify({
        'euclidean_distance': distance
    })
if __name__ == '__main__':
    app.run(debug=True)

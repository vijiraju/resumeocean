jd = '''
About the job
Greetings from TCS!


TCS is hiring for Data Scientist



Desired Experience Range: 4 to 8 Years

Job Location: Chennai, Hyderabad, Bangalore



Required Skill Set: R, Python, and database query languages like SQL, Hive, Pig is desirable. Familiarity with Scala, Java, or C++, Machine learning , Data Wrangling



Must-Have: Python, Machine learning, data Wrangline
Good-to-Have: Hadoop, Spark


Expectations from the Role:

1. Programming Skills – knowledge of statistical programming languages like R, Python, and database query languages like SQL, Hive, Pig is desirable. Familiarity with Scala, Java, or C++ is an added advantage.
2. Statistics – Good applied statistical skills, including knowledge of statistical tests, distributions, regression, maximum likelihood estimators, etc. Proficiency in statistics is essential for data-driven companies.
3. Machine Learning – good knowledge of machine learning methods like k-Nearest Neighbors, Naive Bayes, SVM, Decision Forests.
4. Hands-on experience with data science tools
5. Knowledge in Spark is added advantage
6. Knowledge in Hadoop is added advantage
7. Proven Experience as Data Analyst or Data Scientist
8. Experience in large scale enterprise application implementation
9. Creative Individual with a track record of working on and implementing innovative tech based solutions
10. Exceptional intelligence and problem solving skills
'''

resume = '''
AKSHAT JAIN
	
98, Kaveri Vihar Phase 2, Agra, India
+91 7983033401
jain.akshat7983@gmail.com
github.com/AkshatJain20092002
linkedin.com/in/akshat-jain-489775219/ 


EXPERIENCE
StuValley Technology, Remote — AI/ML with Backend Dev
January 2024 – Present
•	Creating a NER-based model to extract relevant features from resumes and predict the results based on job descriptions.
•	Implementing Hugging Face API models to fasten the performance.
LanguifyAI, Remote — Project Intern
July 2023 – August 2023
•	Developed a Vision Transformer (ViT) model for image classification on the CIFAR-10 dataset, delivering an impressive accuracy rate exceeding 90%.
•	Earned a perfect 10/10 performance rating and received recognition for outstanding accomplishments.
EDUCATION
Bennett University, Gr. Noida — B-Tech CSE
September 2021 - May 2025
CGPA: 9.71 / 10
Coursework: Data Structures, Design and Analysis of Algorithms, Automata, Operating Systems, Soft Computing, Information Management Systems, Software Engineering, Engineering Calculus, Linear Algebra & Ordinary Differential Equations.
PROJECTS
Skin Disease Classification                                                      December 2023
Python | TensorFlow | Keras | Convolutional Neural Networks (CNNs) | VGG16 Transfer Learning

•	Developed a Convolution Neural Network Model that achieved 80% accuracy in classifying skin diseases, including chickenpox, measles, monkeypox, and normal cases, using a dataset of 1000+ images.
•	Boosted model performance by implementing VGG16, resulting in a 15% accuracy improvement.
Replace Songwriters                                                                        September 2023
Pandas | NumPy | Matplotlib | Music21 Library | Keras | TensorFlow | Flask | HTML | CSS | JavaScript
•	Generated songs with AI using an LSTM model, merging 21 CSV songs into a dataset of 6,000+ samples. Achieved 75%+ accuracy.
•	Applied NLP preprocessing techniques for improved lyrics and tunes in Generative AI.
Movie Recommendation System                                                  September 2023
Pandas | NumPy | Natural Language Processing | Matplotlib | Flask | Streamlit | TMDb API
•	Boosted user engagement with content-based filtering algorithms, increasing movie click-through rates by 30%.
•	Enabled personalized movie recommendations and seamlessly fetched movie posters from TMDb API, resulting in a 25% rise in user interactions.
PUBLICATIONS
A Comparative Analysis of Optimized Routing Protocols for High-Performance MANET - SPRINGER
Co-authored with Ayushman Pranav, Mohd. Mohsin, Published in Manchester Metropolitan University, Manchester, UK (ICCCNET-2023)	SKILLS

Programming Languages:
Python, C++, JAVA programming
Frameworks/Tools:
HTML, CSS, Flask, MySQL, Streamlit, Keras, TensorFlow, PyTorch
AI Expertise:
Machine Learning, Computer Vision, Natural Language Processing, Deep Learning
CERTIFICATIONS
Software Engineering -Software Design and Project Management (Coursera)
AWS Academy Graduate- AWS Academy Machine Learning Foundations (AWS Academy)
The Bits and Bytes of Computer Networking (Google)
Generative Adversarial Networks (GANs) – 3 Courses Specializations (DeepLearning.AI)
Fundamentals of Digital Image and Video Processing (Coursera)
SOFT SKILLS
Teamwork, Problem-Solving, Time-Management, Creativity, Active Listener
AWARDS
Honored to receive the Dean’s List Award for Academic Excellence
Hunt AI: Secured 1st rank in group hackathon
Cymatic Scan: Project Showcase and secured the 3rd position in SCSET organized by Bennett University
Amazon ML Challenge: Secured the 74th position in the hackathon, competing against teams from across the nation.
'''

import requests
# Base URL of your Flask application
base_url = 'http://127.0.0.1:5000'
# Sample JD and resume data
jd_text = jd
resume_text = resume

# # Call the /process_text endpoint for JD and resume

# def call_process_text_endpoint(url, text):
#     data = {'text': text}
#     response = requests.post(url, json=data)
#     return response.json()
# # Call the /process_text endpoint for JD and resume
# jd_processed = call_process_text_endpoint(f'{base_url}/process_text', jd_text)
# resume_processed = call_process_text_endpoint(f'{base_url}/process_text', resume_text)


jd_processed = {'processed_text': jd_text}
resume_processed = {'processed_text': resume_text}

# Function to call the /calculate_cos_similarity endpoint
def call_calculate_cos_similarity_endpoint(url, jd_text, resume_text):
    data = {'processed_jd_text': jd_text, 'processed_text': resume_text}
    response = requests.post(url, json=data)
    return response.json()
# Function to call the /calculate_jaccard_similarity endpoint
def call_calculate_jaccard_similarity_endpoint(url, jd_text, resume_text):
    data = {'processed_jd_text': jd_text, 'processed_text': resume_text}
    response = requests.post(url, json=data)
    return response.json()
# Function to call the /calculate_levenshtein_distance endpoint
def call_calculate_levenshtein_distance_endpoint(url, jd_text, resume_text):
    data = {'processed_jd_text': jd_text, 'processed_text': resume_text}
    response = requests.post(url, json=data)
    return response.json()
# Function to call the /calculate_jaro_winkler_distance endpoint
def call_calculate_jaro_winkler_distance_endpoint(url, jd_text, resume_text):
    data = {'processed_jd_text': jd_text, 'processed_text': resume_text}
    response = requests.post(url, json=data)
    return response.json()
# Function to call the /calculate_manhattan_distance endpoint
def call_calculate_manhattan_distance_endpoint(url, jd_text, resume_text):
    data = {'processed_jd_text': jd_text, 'processed_text': resume_text}
    response = requests.post(url, json=data)
    return response.json()
# Function to call the /calculate_euclidean_distance endpoint
def call_calculate_euclidean_distance_endpoint(url, jd_text, resume_text):
    data = {'processed_jd_text': jd_text, 'processed_text': resume_text}
    response = requests.post(url, json=data)
    return response.json()
# Call each endpoint function
response_cos_similarity = call_calculate_cos_similarity_endpoint(f'{base_url}/calculate_cos_similarity', jd_processed['processed_text'],resume_processed['processed_text'])
response_jaccard_similarity =call_calculate_jaccard_similarity_endpoint(f'{base_url}/calculate_jaccard_similarity', jd_processed['processed_text'],resume_processed['processed_text'])
response_levenshtein_distance =call_calculate_levenshtein_distance_endpoint(f'{base_url}/calculate_levenshtein_distance', jd_processed['processed_text'],resume_processed['processed_text'])
response_jaro_winkler_distance =call_calculate_jaro_winkler_distance_endpoint(f'{base_url}/calculate_jaro_winkler_distance', jd_processed['processed_text'],resume_processed['processed_text'])
response_manhattan_distance =call_calculate_manhattan_distance_endpoint(f'{base_url}/calculate_manhattan_distance', jd_processed['processed_text'],resume_processed['processed_text'])
response_euclidean_distance =call_calculate_euclidean_distance_endpoint(f'{base_url}/calculate_euclidean_distance', jd_processed['processed_text'],resume_processed['processed_text'])
# Print responses
print("Response from /calculate_cos_similarity endpoint:",response_cos_similarity)
print("Response from /calculate_jaccard_similarity endpoint:",response_jaccard_similarity)
print("Response from /calculate_levenshtein_distance endpoint:",response_levenshtein_distance)
print("Response from /calculate_jaro_winkler_distance endpoint:",response_jaro_winkler_distance)
print("Response from /calculate_manhattan_distance endpoint:",response_manhattan_distance)
print("Response from /calculate_euclidean_distance endpoint:",response_euclidean_distance)


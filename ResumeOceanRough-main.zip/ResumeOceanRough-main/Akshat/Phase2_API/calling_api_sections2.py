import openai
import requests

openai.api_key = "API_KEY"  # Replace your_openai_api_key with your actual API key
model_name = "gpt-3.5-turbo-16k-0613"

cosine_similarity_api = "https://l6xdvung18.execute-api.us-east-1.amazonaws.com/dev/calculate_cosine_similarity_score"
jaccard_similarity_api = "https://l6xdvung18.execute-api.us-east-1.amazonaws.com/dev/calculate_jaccard_similarity_score"
jaro_winkler_distance_api = "https://hxheizds29.execute-api.us-east-1.amazonaws.com/dev/calculate_jaro_winkler_distance_score"
levenshtein_distance_api = "https://hxheizds29.execute-api.us-east-1.amazonaws.com/dev/calculate_levenshtein_distance_score"
manhattan_distance_api = "https://hxheizds29.execute-api.us-east-1.amazonaws.com/dev/calculate_manhattan_distance_score"
euclidean_distance_api = "https://hxheizds29.execute-api.us-east-1.amazonaws.com/dev/calculate_euclidean_distance_score"
process_text_api = "https://hxheizds29.execute-api.us-east-1.amazonaws.com/dev/process_text"

# Sample JD and resume data

jd = '''
About the job
Greetings from TCS!


TCS is hiring for Data Scientist



Desired Experience Range: 4 to 8 Years

Job Location: Chennai, Hyderabad, Bangalore



Required Skill Set: R, Python, and database query languages like SQL, Hive, Pig is desirable. Familiarity with Scala, Java, or C++, Machine learning , Data Wrangling



Must-Have: Python, Machine learning, data Wrangline
Good-to-Have: Hadoop, Spark


Expectations from the Role:

1. Programming Skills – knowledge of statistical programming languages like R, Python, and database query languages like SQL, Hive, Pig is desirable. Familiarity with Scala, Java, or C++ is an added advantage.
2. Statistics – Good applied statistical skills, including knowledge of statistical tests, distributions, regression, maximum likelihood estimators, etc. Proficiency in statistics is essential for data-driven companies.
3. Machine Learning – good knowledge of machine learning methods like k-Nearest Neighbors, Naive Bayes, SVM, Decision Forests.
4. Hands-on experience with data science tools
5. Knowledge in Spark is added advantage
6. Knowledge in Hadoop is added advantage
7. Proven Experience as Data Analyst or Data Scientist
8. Experience in large scale enterprise application implementation
9. Creative Individual with a track record of working on and implementing innovative tech based solutions
10. Exceptional intelligence and problem solving skills
'''

resume = '''
AKSHAT JAIN
	
98, Kaveri Vihar Phase 2, Agra, India
+91 7983033401
jain.akshat7983@gmail.com
github.com/AkshatJain20092002
linkedin.com/in/akshat-jain-489775219/ 


EXPERIENCE
StuValley Technology, Remote — AI/ML with Backend Dev
January 2024 – Present
•	Creating a NER-based model to extract relevant features from resumes and predict the results based on job descriptions.
•	Implementing Hugging Face API models to fasten the performance.
LanguifyAI, Remote — Project Intern
July 2023 – August 2023
•	Developed a Vision Transformer (ViT) model for image classification on the CIFAR-10 dataset, delivering an impressive accuracy rate exceeding 90%.
•	Earned a perfect 10/10 performance rating and received recognition for outstanding accomplishments.
EDUCATION
Bennett University, Gr. Noida — B-Tech CSE
September 2021 - May 2025
CGPA: 9.71 / 10
Coursework: Data Structures, Design and Analysis of Algorithms, Automata, Operating Systems, Soft Computing, Information Management Systems, Software Engineering, Engineering Calculus, Linear Algebra & Ordinary Differential Equations.
PROJECTS
Skin Disease Classification                                                      December 2023
Python | TensorFlow | Keras | Convolutional Neural Networks (CNNs) | VGG16 Transfer Learning

•	Developed a Convolution Neural Network Model that achieved 80% accuracy in classifying skin diseases, including chickenpox, measles, monkeypox, and normal cases, using a dataset of 1000+ images.
•	Boosted model performance by implementing VGG16, resulting in a 15% accuracy improvement.
Replace Songwriters                                                                        September 2023
Pandas | NumPy | Matplotlib | Music21 Library | Keras | TensorFlow | Flask | HTML | CSS | JavaScript
•	Generated songs with AI using an LSTM model, merging 21 CSV songs into a dataset of 6,000+ samples. Achieved 75%+ accuracy.
•	Applied NLP preprocessing techniques for improved lyrics and tunes in Generative AI.
Movie Recommendation System                                                  September 2023
Pandas | NumPy | Natural Language Processing | Matplotlib | Flask | Streamlit | TMDb API
•	Boosted user engagement with content-based filtering algorithms, increasing movie click-through rates by 30%.
•	Enabled personalized movie recommendations and seamlessly fetched movie posters from TMDb API, resulting in a 25% rise in user interactions.
PUBLICATIONS
A Comparative Analysis of Optimized Routing Protocols for High-Performance MANET - SPRINGER
Co-authored with Ayushman Pranav, Mohd. Mohsin, Published in Manchester Metropolitan University, Manchester, UK (ICCCNET-2023)	SKILLS

Programming Languages:
Python, C++, JAVA programming
Frameworks/Tools:
HTML, CSS, Flask, MySQL, Streamlit, Keras, TensorFlow, PyTorch
AI Expertise:
Machine Learning, Computer Vision, Natural Language Processing, Deep Learning
CERTIFICATIONS
Software Engineering -Software Design and Project Management (Coursera)
AWS Academy Graduate- AWS Academy Machine Learning Foundations (AWS Academy)
The Bits and Bytes of Computer Networking (Google)
Generative Adversarial Networks (GANs) – 3 Courses Specializations (DeepLearning.AI)
Fundamentals of Digital Image and Video Processing (Coursera)
SOFT SKILLS
Teamwork, Problem-Solving, Time-Management, Creativity, Active Listener
AWARDS
Honored to receive the Dean’s List Award for Academic Excellence
Hunt AI: Secured 1st rank in group hackathon
Cymatic Scan: Project Showcase and secured the 3rd position in SCSET organized by Bennett University
Amazon ML Challenge: Secured the 74th position in the hackathon, competing against teams from across the nation.
'''

# Define the prompt using the job description text
prompt = f"Please extract sections from the following job description:\n\n{jd}\n\nPlease provide keywords related to the following categories:\n\nDesignation: Location: Skills: Experience: Responsibilities:"

response = openai.ChatCompletion.create(
    model=model_name,
    messages=[{"role": "system", "content": prompt}],
    max_tokens=1024,
    temperature=0.6,
)

# Extracted text from the response
response_text = response["choices"][0]["message"]["content"]

# Split the response into lines
lines = response_text.strip().split("\n")

# Initialize a dictionary to store keywords for each category
keywords = {
    'Designation': [],
    'Location': [],
    'Skills': [],
    'Experience': [],
    'Responsibilities': []
}

# Process each line and assign keywords to respective categories
current_category = None
for line in lines:
    line = line.strip()
    if line.startswith("Designation:"):
        current_category = 'Designation'
        keywords[current_category].append(line[len("Designation:"):].strip())
    elif line.startswith("Location:"):
        current_category = 'Location'
        keywords[current_category].append(line[len("Location:"):].strip())
    elif line.startswith("Skills:"):
        current_category = 'Skills'
        keywords[current_category].append(line[len("Skills:"):].strip())
    elif line.startswith("Experience:"):
        current_category = 'Experience'
        keywords[current_category].append(line[len("Experience:"):].strip())
    elif line.startswith("Responsibilities:"):
        current_category = 'Responsibilities'
        keywords[current_category].append(line[len("Responsibilities:"):].strip())
    elif current_category:
        keywords[current_category].append(line)

# Sample JD and resume data
jd_text = jd
resume_text = resume

# Function to call similarity and distance APIs
def call_similarity_or_distance_api(url, processed_jd_text, processed_resume_text):
    payload = {
        'processed_jd_text': processed_jd_text,
        'processed_resume_text': processed_resume_text
    }
    response = requests.post(url, json=payload)
    if response.status_code == 200:
        return response.json()
    else:
        return None

# Call process_text API

for section, section_keywords in keywords.items():
    section_jd_text = ' '.join(section_keywords)
    
    # Call similarity and distance APIs for each metric
    cosine_similarity_response = call_similarity_or_distance_api(cosine_similarity_api, section_jd_text, resume_text)
    jaccard_similarity_response = call_similarity_or_distance_api(jaccard_similarity_api, section_jd_text, resume_text)
    jaro_winkler_distance_response = call_similarity_or_distance_api(jaro_winkler_distance_api, section_jd_text, resume_text)
    levenshtein_distance_response = call_similarity_or_distance_api(levenshtein_distance_api, section_jd_text, resume_text)
    manhattan_distance_response = call_similarity_or_distance_api(manhattan_distance_api, section_jd_text, resume_text)
    euclidean_distance_response = call_similarity_or_distance_api(euclidean_distance_api, section_jd_text, resume_text)
    
    # Print responses for each section
    print(f"Section: {section}")
    print("Cosine Similarity Response:", cosine_similarity_response)
    print("Jaccard Similarity Response:", jaccard_similarity_response)
    print("Jaro-Winkler Distance Response:", jaro_winkler_distance_response)
    print("Levenshtein Distance Response:", levenshtein_distance_response)
    print("Manhattan Distance Response:", manhattan_distance_response)
    print("Euclidean Distance Response:", euclidean_distance_response)
    print()

#full jd
cosine_similarity_response = call_similarity_or_distance_api(cosine_similarity_api, jd_text, resume_text)
jaccard_similarity_response = call_similarity_or_distance_api(jaccard_similarity_api, jd_text, resume_text)
jaro_winkler_distance_response = call_similarity_or_distance_api(jaro_winkler_distance_api, jd_text, resume_text)
levenshtein_distance_response = call_similarity_or_distance_api(levenshtein_distance_api, jd_text, resume_text)
manhattan_distance_response = call_similarity_or_distance_api(manhattan_distance_api, jd_text, resume_text)
euclidean_distance_response = call_similarity_or_distance_api(euclidean_distance_api, jd_text, resume_text)

# Print responses for each section
print("Full JD")
print("Cosine Similarity Response:", cosine_similarity_response)
print("Jaccard Similarity Response:", jaccard_similarity_response)
print("Jaro-Winkler Distance Response:", jaro_winkler_distance_response)
print("Levenshtein Distance Response:", levenshtein_distance_response)
print("Manhattan Distance Response:", manhattan_distance_response)
print("Euclidean Distance Response:", euclidean_distance_response)
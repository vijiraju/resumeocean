from flask import Flask, render_template, request, jsonify, redirect, url_for
import os
from transformers import AutoTokenizer, AutoModel
import torch
import PyPDF2
from langchain.text_splitter import TokenTextSplitter
import faiss
import numpy as np
import requests
import json
import openai
import time
import logging
from prompts import prompt_input
from chatgptapikey import apikey

app = Flask(__name__)

UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'docx', 'pdf', 'json'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Configure logging
logging.basicConfig(filename='extract_data.log', level=logging.INFO)

# Create uploads directory if it doesn't exist
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# Function to check if file extension is allowed
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Initialize tokenizer and model from Hugging Face
tokenizer = AutoTokenizer.from_pretrained('sentence-transformers/all-MiniLM-L12-v2')
model = AutoModel.from_pretrained('sentence-transformers/all-MiniLM-L12-v2')

# API URL for generating embeddings
API_URL = "https://api-inference.huggingface.co/models/sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
headers = {"Authorization": "Bearer API_KEY"}     # Input API_KEY

# Threshold length for when to use the API
THRESHOLD_LENGTH = 1000  # Adjust as needed

# Mean Pooling - Take attention mask into account for correct averaging
def mean_pooling(model_output, attention_mask):
    token_embeddings = model_output[0]  # First element of model_output contains all token embeddings
    input_mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
    return torch.sum(token_embeddings * input_mask_expanded, 1) / torch.clamp(input_mask_expanded.sum(1), min=1e-9)

# Function to generate embeddings using either model or API based on text length
def generate_embedding(text):
    if len(text) > THRESHOLD_LENGTH:
        # Use API for generating embeddings
        response = requests.post(API_URL, headers=headers, json={"inputs": {"source_sentence": text, "sentences": [text]}})
        output = response.json()
        sentence_embedding = np.array(output["outputs"][0]["sentence_embedding"])
    else:
        # Tokenize input text
        encoded_input = tokenizer(text, padding=True, truncation=True, return_tensors='pt')
        # Compute token embeddings with model
        with torch.no_grad():
            model_output = model(**encoded_input)
        # Perform mean pooling
        sentence_embedding = mean_pooling(model_output, encoded_input['attention_mask'])
        # Convert to numpy for FAISS compatibility and ensure it's 2D
        sentence_embedding = sentence_embedding.cpu().numpy().reshape(1, -1)
    return sentence_embedding

# Adjusted function to generate embeddings for chunks of text
def generate_embeddings_for_chunks(text_chunks):
    embeddings = np.vstack([generate_embedding(chunk) for chunk in text_chunks])
    return embeddings

# Adjusted function to create and save FAISS index
def save_embeddings(embeddings, file_name="vecstore.faiss"):
    dimension = embeddings.shape[1]
    index = faiss.IndexFlatL2(dimension)
    index.add(embeddings)
    faiss.write_index(index, file_name)
    
# Load FAISS index
def load_faiss_index(file_name='vecstore.faiss'):
    return faiss.read_index(file_name)

# Search in FAISS index
def search_faiss_index(index, query_embedding, top_n=4):
    # Ensure query_embedding is a 2D array with shape (1, embedding_size)
    query_embedding_2d = query_embedding.reshape(1, -1)
    D, I = index.search(query_embedding_2d, top_n)
    return I[0]

def read_pdf(file):
    """Reads a PDF file and returns its text content."""
    reader = PyPDF2.PdfReader(file.stream)
    text = ''
    for page_num in range(len(reader.pages)):
        text += reader.pages[page_num].extract_text()
    return text


def split_into_chunks(text):
    """Splits the text into chunks of specific token length and returns a list of those chunks"""
    text_splitter = TokenTextSplitter(chunk_size=100, chunk_overlap=0)
    texts = text_splitter.split_text(text)
    return texts

def get_text_for_indices(indices, text_chunks):
    """Returns the text chunks for the given indices."""
    return [text_chunks[i] for i in indices]

prompt = {
    "fname": "What is the first name present in the resume?  [Only provide single string]",
    "lastName": "What is the last name present in the resume? [Only provide single string]",
    "dob": "What is the date of birth present in the resume? [Only provide single string]",
    "age": "What is the age (Current year - Date of Birth year) present in the resume? [Only provide single integer]",
    "email": "What is the email present in the resume? [Only provide single string]",
    "address": "What is the address present in the resume? [Only provide string]",
    "mobile": "What is the mobile number present in the resume? [Only provide single long integer]",
    "LinkedIn": "What is the LinkedIn profile present in the resume? [Only provide single link]",
    "orcidId": "What is the ORCID ID for the research papers present in the resume? [Only provide single id]",
    "totalIndustryExperience": "What is the total industry years of experience present in the resume. [Sum of all the years of experience and provide integer value+ 'years'] ",
    "summaryDetails": "What is the summary present in the resume? [Only provide 2 lines string]",
    "degree": "What are the degrees(10th Degree, 12th Degree, Undergrad Degree, Postgrad Degree) present in the resume? Answer in points and keep it precise. [Only provide Degree names]" ,
    "course": "What are the courses taken in the degrees present in the resume? Answer in points and keep it precise. [Only provide string separated by ',']",
    "marks": "What are the CGPA (Undergrad Degree, Postgrad Degree) present in the resume? Answer in points and keep it precise. [Only provide integer]",
    "yearOfPass": "What are the years of passing (for 10th Degree, 12th Degree, Undergrad Degree, Postgrad Degree) present in the resume? Answer in points and keep it precise. [Only provide integer]",
    "boardsName": "What are the board's names (10th Degree, 12th Degree) present in the resume? Answer in points and keep it precise. [Only provide string]",
    "percentage": "What are the percentages (10th Degree, 12th Degree) present in the resume? Answer in points  [provide integer value + '% in 10th and % in 12th'] ",
    "nameOfEmployer": "What are the names of the employers present in the resume for the particular job positions?  Answer in points and keep it precise. [Only provide string]",
    "department": "What are the departments he/she work with for the particular job positions that are present in the resume? Answer in points [Only provide string]",
    "postDesignation": "What are the post designations for the particular job positions present in the resume? Answer in points and keep it precise. [Only provide string]" ,
    "periodOfEmploymentFrom": "What are the starting tenure of work employment for the particular job positions in the resume? Answer in points and keep it precise. [Only provide integer]",
    "periodOfEmploymentTo": "What are the ending tenure of work employment for the particular job positions in the resume? Answer in points and keep it precise [Only provide single integer]",
    "grossSalary": "What is the gross salary for the particular job positions in the resume? [Answer in 'Rs/$' + integer value]",
    "responsibilities": "What are the job responsibilities for the particular job positions in the resume? Answer in points and keep it precise [Only provide string]",
    "skills": "What are the skills+frameworks+soft skills present in the resume? Answer in points [Only provide string separated by ',']",
    "selfRating": "How does the person is doing self rating, and extract from where it is present in the resume? [Only provide 2 line string]",
    "whyRate": "Why does the person is doing self rating, and extract from where it is present in the resume? [Only provide 2 line string]",
    "nameOfAwardsAchievements": "What are the name of awards/achievements+certificates+academic achievements  present in the resume?",
    "institutionsOrganization": "What are the institution that provided the awards/ certificates to the person present in the resume?",
    "institutionsOrganizationName": "What are the institution/organization names that provided the awards/ certificates to the person present in the resume?",
    "detailsofAwards/Cerifications": "What are the details of awards/certifications present in the resume?",
    "dateOfAwards": "What are the date of awards obtained present in the resume?",
    "awardsTitle": "What are the awards title obtained present in the resume?",
    "urlAwards": "What are the URL of awards present in the resume?",
    "typesOfAchievment": "What are the types of awards/achievement"
}



@app.route('/')
def index():
    return render_template('upload.html')

@app.route('/upload', methods=['POST'])
def upload_resume():
    file = request.files['resume_file']
    if file.filename.endswith('.pdf'):
        text = read_pdf(file)
        text_chunks = split_into_chunks(text)
        embeddings = generate_embeddings_for_chunks(text_chunks)
        save_embeddings(embeddings, "vecstore.faiss")
        vecstore = load_faiss_index("vecstore.faiss")
        
        filename = file.filename
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)
        
        output_dict = {}

        for key, prompt_text in prompt.items():
            query_text = prompt_text
            query_embedding = generate_embedding(query_text)
            top_indices = search_faiss_index(vecstore, query_embedding)
            top_text_chunks = get_text_for_indices(top_indices, text_chunks)
            top_text_chunks.insert(0, prompt_text)
            keyoutput = openaigpt(apikey, prompt_text + ' '.join(top_text_chunks))
        
            output_dict[key] = keyoutput
            
            
        if output_dict:
            with open(os.path.join(app.config['UPLOAD_FOLDER'], 'extracted_features.json'), 'w') as f:
                json.dump(output_dict, f, indent=4)
            logging.info("Extraction completed. Extracted features saved in 'uploads/extracted_features.json'.")
            # print("Extraction completed. Extracted features saved in 'uploads/extracted_features.json'.")
            return redirect(url_for('display', filename='extracted_features.json'))
        
    
    else:
        logging.error("Please upload a PDF file.")
        return "Please upload a PDF file."
    
@app.route('/display/<filename>')
def display(filename):
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    if not os.path.exists(file_path):
        logging.error("File not found")
        return "File not found"

    with open(file_path, 'r') as f:
        data = json.load(f)

    # Check if 'output' key exists in the JSON data
    if 'output' in data:
        # If 'output' key exists, assume it's a list of key-value pairs
        data_dict = {}
        for item in data['output']:
            key, value = item.split(": ", 1) if ": " in item else (None, None)
            if key and value:
                data_dict[key.strip()] = value.strip()
        return render_template('display.html', data=data_dict)
    else:
        # If 'output' key does not exist, assume it's a dictionary
        return render_template('display.html', data=data)

import json
import openai

def openaigpt(api_key, prompt_input):
    # Set the API key
    openai.api_key = 'API_KEY'   # Enter your API_KEY

    # Specify the model and role
    model_name = "gpt-3.5-turbo-16k-0613"
    role = f"You are provided with a dictionary, extract information based on the question and provide answers from it. If unable to extract info, (REMEMBER) DIRECTLY WRITE 'No information available' as output. Act as an expert data analyst, with full knowledge of data extraction from the RESUME"
    messages = [
        {"role": "system", "content": role},
        {"role": "user", "content": prompt_input},
    ]
    # Create the ChatGPT completion
    response = openai.ChatCompletion.create(
        model=model_name,
        messages=messages,
        max_tokens=2048,
        temperature=0.6,
        stop=None,
        n=1
    )

    # Return the first response text
    return response["choices"][0]["message"]["content"]

# Run the Flask app
if __name__ == '__main__':
    app.run(debug=True)

def apikey():
    return "API_KEY"   # Enter your API_KEY
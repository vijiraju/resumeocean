from flask import Flask, render_template, request, jsonify, redirect, url_for
import os
from transformers import AutoTokenizer, AutoModel
import torch
import PyPDF2
from langchain.text_splitter import TokenTextSplitter
import faiss
import numpy as np
import requests
import json
import openai
import logging


app = Flask(__name__)

class ResumeExtractor:
    def __init__(self):
        self.app = Flask(__name__)
        self.app.config['UPLOAD_FOLDER'] = 'uploads'
        self.allowed_extensions = {'docx', 'pdf', 'json'}
        self.init_logging()

        # Initialize tokenizer and model from Hugging Face
        self.tokenizer = AutoTokenizer.from_pretrained('sentence-transformers/all-MiniLM-L12-v2')
        self.model = AutoModel.from_pretrained('sentence-transformers/all-MiniLM-L12-v2')

        # API URL for generating embeddings
        self.API_URL = "https://api-inference.huggingface.co/models/sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
        self.headers = {"Authorization": "Bearer API_KEY"}     # Input API_KEY
        
        # Threshold length for when to use the API
        self.THRESHOLD_LENGTH = 1000  # Adjust as needed


    def init_logging(self):
        logging.basicConfig(filename='extract_data.log', level=logging.INFO)
        
    def prompt_input(self,key):
        prompt = {
            "fname": "What is the first name present in the resume? [Only provide single string]",
            "lastName": "What is the last name present in the resume? [Only provide single string]",
            "dob": "What is the date of birth present in the resume? [Only provide single string]",
            "age": "What is the age (Current year - Date of Birth year) present in the resume? [Only provide single integer]",
            "email": "What is the email present in the resume? [Only provide single string]",
            "address": "What is the address present in the resume? [Only provide string]",
            "mobile": "What is the mobile number present in the resume? [Only provide single long integer]",
            "LinkedIn": "What is the LinkedIn profile present in the resume? [Only provide single link]",
            "orcidId": "What is the ORCID ID for the research papers present in the resume? [Only provide single id]",
            "totalIndustryExperience": "What is the total industry years of experience present in the resume. [Sum of all the years of experience and provide integer value + 'years']",
            "summaryDetails": "What is the summary present in the resume? [Only provide 2 lines string]",
            "degree": "What are the degrees(10th Degree, 12th Degree, Undergrad Degree, Postgrad Degree) present in the resume? Answer in points and keep it precise. [Only provide Degree names]",
            "course": "What are the courses taken in the degrees present in the resume? Answer in points and keep it precise. [Only provide string separated by ',']",
            "marks": "What are the CGPA (Undergrad Degree, Postgrad Degree) present in the resume? Answer in points and keep it precise. [Only provide integer]",
            "yearOfPass": "What are the years of passing (for 10th Degree, 12th Degree, Undergrad Degree, Postgrad Degree) present in the resume? Answer in points and keep it precise. [Only provide integer]",
            "boardsName": "What are the board's names (10th Degree, 12th Degree) present in the resume? Answer in points and keep it precise. [Only provide string]",
            "percentage": "What are the percentages (10th Degree, 12th Degree) present in the resume? Answer in points  [provide integer value + '% in 10th and % in 12th']",
            "nameOfEmployer": "What are the names of the employers present in the resume for the particular job positions? Answer in points and keep it precise. [Only provide string]",
            "department": "What are the departments he/she work with for the particular job positions that are present in the resume? Answer in points [Only provide string]",
            "postDesignation": "What are the post designations for the particular job positions present in the resume? Answer in points and keep it precise. [Only provide string]",
            "periodOfEmploymentFrom": "What are the starting tenure of work employment for the particular job positions in the resume? Answer in points and keep it precise. [Only provide integer]",
            "periodOfEmploymentTo": "What are the ending tenure of work employment for the particular job positions in the resume? Answer in points and keep it precise [Only provide single integer]",
            "grossSalary": "What is the gross salary for the particular job positions in the resume? [Answer in 'Rs/$' + integer value]",
            "responsibilities": "What are the job responsibilities for the particular job positions in the resume? Answer in points and keep it precise [Only provide string]",
            "skills": "What are the skills+frameworks+soft skills present in the resume? Answer in points [Only provide string separated by ',']",
            "selfRating": "How does the person is doing self rating, and extract from where it is present in the resume? [Only provide 2 line string]",
            "whyRate": "Why does the person is doing self rating, and extract from where it is present in the resume? [Only provide 2 line string]",
            "nameOfAwardsAchievements": "What are the name of awards/achievements+certificates+academic achievements present in the resume?",
            "institutionsOrganization": "What are the institution that provided the awards/ certificates to the person present in the resume?",
            "institutionsOrganizationName": "What are the institution/organization names that provided the awards/ certificates to the person present in the resume?",
            "detailsofAwards/Cerifications": "What are the details of awards/certifications present in the resume?",
            "dateOfAwards": "What are the date of awards obtained present in the resume?",
            "awardsTitle": "What are the awards title obtained present in the resume?",
            "urlAwards": "What are the URL of awards present in the resume?",
            "typesOfAchievment": "What are the types of awards/achievement"
        }
        return prompt.get(key)

    def allowed_file(self, filename):
        return '.' in filename and filename.rsplit('.', 1)[1].lower() in self.allowed_extensions

    def mean_pooling(self, model_output, attention_mask):
        token_embeddings = model_output[0]  # First element of model_output contains all token embeddings
        input_mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
        return torch.sum(token_embeddings * input_mask_expanded, 1) / torch.clamp(input_mask_expanded.sum(1), min=1e-9)

    def generate_embedding(self, text):
        if len(text) > self.THRESHOLD_LENGTH:
            response = requests.post(self.API_URL, headers=self.headers, json={"inputs": {"source_sentence": text, "sentences": [text]}})
            output = response.json()
            sentence_embedding = np.array(output["outputs"][0]["sentence_embedding"])
        else:
            encoded_input = self.tokenizer(text, padding=True, truncation=True, return_tensors='pt')
            with torch.no_grad():
                model_output = self.model(**encoded_input)
            sentence_embedding = self.mean_pooling(model_output, encoded_input['attention_mask'])
            sentence_embedding = sentence_embedding.cpu().numpy().reshape(1, -1)
        return sentence_embedding

    def generate_embeddings_for_chunks(self, text_chunks):
        embeddings = np.vstack([self.generate_embedding(chunk) for chunk in text_chunks])
        return embeddings

    def save_embeddings(self, embeddings, file_name="vecstore.faiss"):
        dimension = embeddings.shape[1]
        index = faiss.IndexFlatL2(dimension)
        index.add(embeddings)
        faiss.write_index(index, file_name)

    def load_faiss_index(self, file_name='vecstore.faiss'):
        return faiss.read_index(file_name)

    def search_faiss_index(self, index, query_embedding, top_n=4):
        query_embedding_2d = query_embedding.reshape(1, -1)
        D, I = index.search(query_embedding_2d, top_n)
        return I[0]

    def read_pdf(self, file):
        reader = PyPDF2.PdfReader(file.stream)
        text = ''
        for page_num in range(len(reader.pages)):
            text += reader.pages[page_num].extract_text()
        return text

    def split_into_chunks(self, text):
        text_splitter = TokenTextSplitter(chunk_size=100, chunk_overlap=0)
        texts = text_splitter.split_text(text)
        return texts

    def get_text_for_indices(self, indices, text_chunks):
        return [text_chunks[i] for i in indices]

    def openaigpt(self, api_key, prompt_input):
        openai.api_key = api_key
        model_name = "gpt-3.5-turbo-16k-0613"
        role = f"You are provided with a dictionary, extract information based on the question and provide answers from it. If unable to extract info,    (REMEMBER) DIRECTLY WRITE 'No information available' as output. Act as an expert data analyst, with full knowledge of data extraction from the RESUME"
        messages = [
            {"role": "system", "content": role},
            {"role": "user", "content": prompt_input},
        ]
        response = openai.ChatCompletion.create(
            model=model_name,
            messages=messages,
            max_tokens=2048,
            temperature=0.6,
            stop=None,
            n=1
        )
        return response["choices"][0]["message"]["content"]

    def index(self):
        return render_template('upload.html')
    

    def process_extract_text_from_pdf(self,api_key, text):
        text_chunks = self.split_into_chunks(text)
        embeddings = self.generate_embeddings_for_chunks(text_chunks)
        self.save_embeddings(embeddings, "vecstore.faiss")
        vecstore = self.load_faiss_index("vecstore.faiss")

        output_dict = {}
        
        prompt_dict = {key: self.prompt_input(key) for key in [
        "fname", "lastName", "dob", "age", "email", "address", "mobile", "LinkedIn", "orcidId",
        "totalIndustryExperience", "summaryDetails", "degree", "course", "marks", "yearOfPass",
        "boardsName", "percentage", "nameOfEmployer", "department", "postDesignation",
        "periodOfEmploymentFrom", "periodOfEmploymentTo", "grossSalary", "responsibilities",
        "skills", "selfRating", "whyRate", "nameOfAwardsAchievements", "institutionsOrganization",
        "institutionsOrganizationName", "detailsofAwards/Cerifications", "dateOfAwards",
        "awardsTitle", "urlAwards", "typesOfAchievment"
        ]}

        for key, prompt_text in prompt_dict.items():
            query_text = prompt_text
            query_embedding = self.generate_embedding(query_text)
            top_indices = self.search_faiss_index(vecstore, query_embedding)
            top_text_chunks = self.get_text_for_indices(top_indices, text_chunks)
            top_text_chunks.insert(0, prompt_text)
            keyoutput = self.openaigpt(api_key, prompt_text + ' '.join(top_text_chunks))

            output_dict[key] = keyoutput

        if output_dict:
            with open(os.path.join(self.app.config['UPLOAD_FOLDER'], 'extracted_features.json'), 'w') as f:
                json.dump(output_dict, f, indent=4)
            logging.info("Extraction completed. Extracted features saved in 'uploads/extracted_features.json'.")
            return json.dumps(output_dict)

@app.route('/')
def index():
    return "Flask app is running"

@app.route('/process_resume', methods=['POST'])
def process_resume():
    # Expecting JSON data with 'resume_text' and 'api_key' fields
    if not request.json or 'resume_text' not in request.json or 'api_key' not in request.json:
        return jsonify({"error": "Missing required data (resume text or API key)"}), 400
    
    resume_text = request.json['resume_text']
    api_key = request.json['api_key']
    
    resume_extractor = ResumeExtractor()  
    data = resume_extractor.process_extract_text_from_pdf(api_key, resume_text)

    
    if data:
        return jsonify(data)
    
    return jsonify({"error": "Error processing resume text"}), 500

if __name__ == "__main__":
    # app = ResumeExtractor().app
    app.run(debug=True)

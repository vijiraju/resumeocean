from flask import Flask, render_template, request, jsonify, redirect, url_for
import os
from transformers import AutoTokenizer, AutoModel
import torch
import PyPDF2
from langchain.text_splitter import TokenTextSplitter
import faiss
import numpy as np
import requests
import json
import openai
import time
import logging
from prompts import prompt_input
from chatgptapikey import apikey

class ResumeExtractor:
    def __init__(self):
        self.app = Flask(__name__)
        self.app.config['UPLOAD_FOLDER'] = 'uploads'
        self.allowed_extensions = {'docx', 'pdf', 'json'}
        self.init_logging()

        # Initialize tokenizer and model from Hugging Face
        self.tokenizer = AutoTokenizer.from_pretrained('sentence-transformers/all-MiniLM-L12-v2')
        self.model = AutoModel.from_pretrained('sentence-transformers/all-MiniLM-L12-v2')

        # API URL for generating embeddings
        self.API_URL = "https://api-inference.huggingface.co/models/sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
        self.headers = {"Authorization": "Bearer API_KEY"}     # Input API_KEY
        # Threshold length for when to use the API
        self.THRESHOLD_LENGTH = 1000  # Adjust as needed

        # Run Flask app
        self.run_app()

    def init_logging(self):
        logging.basicConfig(filename='extract_data.log', level=logging.INFO)

    def allowed_file(self, filename):
        return '.' in filename and filename.rsplit('.', 1)[1].lower() in self.allowed_extensions

    def mean_pooling(self, model_output, attention_mask):
        token_embeddings = model_output[0]  # First element of model_output contains all token embeddings
        input_mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
        return torch.sum(token_embeddings * input_mask_expanded, 1) / torch.clamp(input_mask_expanded.sum(1), min=1e-9)

    def generate_embedding(self, text):
        if len(text) > self.THRESHOLD_LENGTH:
            response = requests.post(self.API_URL, headers=self.headers, json={"inputs": {"source_sentence": text, "sentences": [text]}})
            output = response.json()
            sentence_embedding = np.array(output["outputs"][0]["sentence_embedding"])
        else:
            encoded_input = self.tokenizer(text, padding=True, truncation=True, return_tensors='pt')
            with torch.no_grad():
                model_output = self.model(**encoded_input)
            sentence_embedding = self.mean_pooling(model_output, encoded_input['attention_mask'])
            sentence_embedding = sentence_embedding.cpu().numpy().reshape(1, -1)
        return sentence_embedding

    def generate_embeddings_for_chunks(self, text_chunks):
        embeddings = np.vstack([self.generate_embedding(chunk) for chunk in text_chunks])
        return embeddings

    def save_embeddings(self, embeddings, file_name="vecstore.faiss"):
        dimension = embeddings.shape[1]
        index = faiss.IndexFlatL2(dimension)
        index.add(embeddings)
        faiss.write_index(index, file_name)

    def load_faiss_index(self, file_name='vecstore.faiss'):
        return faiss.read_index(file_name)

    def search_faiss_index(self, index, query_embedding, top_n=4):
        query_embedding_2d = query_embedding.reshape(1, -1)
        D, I = index.search(query_embedding_2d, top_n)
        return I[0]

    def read_pdf(self, file):
        reader = PyPDF2.PdfReader(file.stream)
        text = ''
        for page_num in range(len(reader.pages)):
            text += reader.pages[page_num].extract_text()
        return text

    def split_into_chunks(self, text):
        text_splitter = TokenTextSplitter(chunk_size=100, chunk_overlap=0)
        texts = text_splitter.split_text(text)
        return texts

    def get_text_for_indices(self, indices, text_chunks):
        return [text_chunks[i] for i in indices]

    def openaigpt(self, api_key, prompt_input):
        openai.api_key = api_key()
        model_name = "gpt-3.5-turbo-16k-0613"
        role = f"You are provided with a dictionary, extract information based on the question and provide answers from it. If unable to extract info, (REMEMBER) DIRECTLY WRITE 'No information available' as output. Act as an expert data analyst, with full knowledge of data extraction from the RESUME"
        messages = [
            {"role": "system", "content": role},
            {"role": "user", "content": prompt_input},
        ]
        response = openai.ChatCompletion.create(
            model=model_name,
            messages=messages,
            max_tokens=2048,
            temperature=0.6,
            stop=None,
            n=1
        )
        return response["choices"][0]["message"]["content"]

    def index(self):
        return render_template('upload.html')

    def upload_resume(self):
        file = request.files['resume_file']
        if file.filename.endswith('.pdf'):
            text = self.read_pdf(file)
            text_chunks = self.split_into_chunks(text)
            embeddings = self.generate_embeddings_for_chunks(text_chunks)
            self.save_embeddings(embeddings, "vecstore.faiss")
            vecstore = self.load_faiss_index("vecstore.faiss")
            filename = file.filename
            file_path = os.path.join(self.app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)

            output_dict = {}
            
            prompt_dict = {key: prompt_input(key) for key in [
            "fname", "lastName", "dob", "age", "email", "address", "mobile", "LinkedIn", "orcidId",
            "totalIndustryExperience", "summaryDetails", "degree", "course", "marks", "yearOfPass",
            "boardsName", "percentage", "nameOfEmployer", "department", "postDesignation",
            "periodOfEmploymentFrom", "periodOfEmploymentTo", "grossSalary", "responsibilities",
            "skills", "selfRating", "whyRate", "nameOfAwardsAchievements", "institutionsOrganization",
            "institutionsOrganizationName", "detailsofAwards/Cerifications", "dateOfAwards",
            "awardsTitle", "urlAwards", "typesOfAchievment"
            ]}

            for key, prompt_text in prompt_dict.items():
                query_text = prompt_text
                query_embedding = self.generate_embedding(query_text)
                top_indices = self.search_faiss_index(vecstore, query_embedding)
                top_text_chunks = self.get_text_for_indices(top_indices, text_chunks)
                top_text_chunks.insert(0, prompt_text)
                keyoutput = self.openaigpt(apikey, prompt_text + ' '.join(top_text_chunks))

                output_dict[key] = keyoutput

            if output_dict:
                with open(os.path.join(self.app.config['UPLOAD_FOLDER'], 'extracted_features.json'), 'w') as f:
                    
                    json.dump(output_dict, f, indent=4)
                logging.info("Extraction completed. Extracted features saved in 'uploads/extracted_features.json'.")
                return redirect(url_for('display', filename='extracted_features.json'))

        else:
            logging.error("Please upload a PDF file.")
            return "Please upload a PDF file."

    def display(self, filename):
        file_path = os.path.join(self.app.config['UPLOAD_FOLDER'], filename)
        if not os.path.exists(file_path):
            logging.error("File not found")
            return "File not found"

        with open(file_path, 'r') as f:
            data = json.load(f)

        if 'output' in data:
            data_dict = {}
            for item in data['output']:
                key, value = item.split(": ", 1) if ": " in item else (None, None)
                if key and value:
                    data_dict[key.strip()] = value.strip()
            return render_template('display.html', data=data_dict)
        else:
            return render_template('display.html', data=data)

    def run_app(self):
        @self.app.route('/')
        def index():
            return self.index()

        @self.app.route('/upload', methods=['POST'])
        def upload():
            return self.upload_resume()

        @self.app.route('/display/<filename>')
        def display(filename):
            return self.display(filename)

        self.app.run(debug=True)

# Create an instance of the ResumeExtractor class
resume_extractor = ResumeExtractor()



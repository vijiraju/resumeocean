import os
import json
import openai
import logging
from flask import Flask, render_template, redirect, request, jsonify


app = Flask(__name__)


class ResumeExtractor:
    def __init__(self):
        self.app = app
        self.init_logging()

    def init_logging(self):
        logging.basicConfig(filename='extract_data.log', level=logging.INFO)
    
    def prompt_input(self,key):
        prompt = {
            "fname": "What is the first name present in the resume? [Only provide single string]",
            "lastName": "What is the last name present in the resume? [Only provide single string]",
            "dob": "What is the date of birth present in the resume? [Only provide single string]",
            "age": "What is the age (Current year - Date of Birth year) present in the resume? [Only provide single integer]",
            "email": "What is the email present in the resume? [Only provide single string]",
            "address": "What is the address present in the resume? [Only provide string]",
            "mobile": "What is the mobile number present in the resume? [Only provide single long integer]",
            "LinkedIn": "What is the LinkedIn profile present in the resume? [Only provide single link]",
            "orcidId": "What is the ORCID ID for the research papers present in the resume? [Only provide single id]",
            "totalIndustryExperience": "What is the total industry years of experience present in the resume. [Sum of all the years of experience and provide integer value + 'years']",
            "summaryDetails": "What is the summary present in the resume? [Only provide 2 lines string]",
            "degree": "What are the degrees(10th Degree, 12th Degree, Undergrad Degree, Postgrad Degree) present in the resume? Answer in points and keep it precise. [Only provide Degree names]",
            "course": "What are the courses taken in the degrees present in the resume? Answer in points and keep it precise. [Only provide string separated by ',']",
            "marks": "What are the CGPA (Undergrad Degree, Postgrad Degree) present in the resume? Answer in points and keep it precise. [Only provide integer]",
            "yearOfPass": "What are the years of passing (for 10th Degree, 12th Degree, Undergrad Degree, Postgrad Degree) present in the resume? Answer in points and keep it precise. [Only provide integer]",
            "boardsName": "What are the board's names (10th Degree, 12th Degree) present in the resume? Answer in points and keep it precise. [Only provide string]",
            "percentage": "What are the percentages (10th Degree, 12th Degree) present in the resume? Answer in points  [provide integer value + '% in 10th and % in 12th']",
            "nameOfEmployer": "What are the names of the employers present in the resume for the particular job positions? Answer in points and keep it precise. [Only provide string]",
            "department": "What are the departments he/she work with for the particular job positions that are present in the resume? Answer in points [Only provide string]",
            "postDesignation": "What are the post designations for the particular job positions present in the resume? Answer in points and keep it precise. [Only provide string]",
            "periodOfEmploymentFrom": "What are the starting tenure of work employment for the particular job positions in the resume? Answer in points and keep it precise. [Only provide integer]",
            "periodOfEmploymentTo": "What are the ending tenure of work employment for the particular job positions in the resume? Answer in points and keep it precise [Only provide single integer]",
            "grossSalary": "What is the gross salary for the particular job positions in the resume? [Answer in 'Rs/$' + integer value]",
            "responsibilities": "What are the job responsibilities for the particular job positions in the resume? Answer in points and keep it precise [Only provide string]",
            "skills": "What are the skills+frameworks+soft skills present in the resume? Answer in points [Only provide string separated by ',']",
            "selfRating": "How does the person is doing self rating, and extract from where it is present in the resume? [Only provide 2 line string]",
            "whyRate": "Why does the person is doing self rating, and extract from where it is present in the resume? [Only provide 2 line string]",
            "nameOfAwardsAchievements": "What are the name of awards/achievements+certificates+academic achievements present in the resume?",
            "institutionsOrganization": "What are the institution that provided the awards/ certificates to the person present in the resume?",
            "institutionsOrganizationName": "What are the institution/organization names that provided the awards/ certificates to the person present in the resume?",
            "detailsofAwards/Cerifications": "What are the details of awards/certifications present in the resume?",
            "dateOfAwards": "What are the date of awards obtained present in the resume?",
            "awardsTitle": "What are the awards title obtained present in the resume?",
            "urlAwards": "What are the URL of awards present in the resume?",
            "typesOfAchievment": "What are the types of awards/achievement"
        }
        return prompt.get(key)
        
    def openaigpt(self, api_key, prompt_input):
        openai.api_key = api_key
        model_name = "gpt-3.5-turbo-16k-0613"
        role = f"""You are a Chatbot Assistant to a Hiring Human resource executive having a conversation with the Hiring Human resource executive provided with a Resume, extract information based on the question and provide answers from it. If unable to extract info, 
                    (REMEMBER) DIRECTLY WRITE 'No information available' as output. Act as an expert data analyst, with full knowledge of data extraction from the RESUME"""
        messages = [
            {"role": "system", "content": role},
            {"role": "user", "content": prompt_input},
        ]
        response = openai.ChatCompletion.create(
            model=model_name,
            messages=messages,
            max_tokens=4096,
            temperature=0.5,
            stop=None,
            n=1
        )
        return response["choices"][0]["message"]["content"]
    
    def index(self):
        return render_template('upload.html')

    def process_extract_text_from_pdf(self,api_key, text):                        

        output_dict = {}
        
        prompt_dict = {key: self.prompt_input(key) for key in [
        "fname", "lastName", "dob", "age", "email", "address", "mobile", "LinkedIn", "orcidId",
        "totalIndustryExperience", "summaryDetails", "degree", "course", "marks", "yearOfPass",
        "boardsName", "percentage", "nameOfEmployer", "department", "postDesignation",
        "periodOfEmploymentFrom", "periodOfEmploymentTo", "grossSalary", "responsibilities",
        "skills", "selfRating", "whyRate", "nameOfAwardsAchievements", "institutionsOrganization",
        "institutionsOrganizationName", "detailsofAwards/Cerifications", "dateOfAwards",
        "awardsTitle", "urlAwards", "typesOfAchievment"
        ]}
        
        if isinstance(text, list):
            text = ' '.join(text)
        
        for key, prompt_text in prompt_dict.items():
            callingtext = self.process_string(prompt_text + ' ' + text)
            keyoutput = self.openaigpt(api_key, callingtext)
            output_dict[key] = keyoutput

        if output_dict:
            # with open(os.path.join(self.app.config['UPLOAD_FOLDER'], 'extracted_features.json'), 'w') as f:
            #     json.dump(output_dict, f, indent=4)
            logging.info("Extraction completed. Extracted features saved.")
            return json.dumps(output_dict)
        
    def process_string(self,input_str):
        if len(input_str) > 4096:
            return input_str[:4096]
        else:
            return input_str
        
@app.route('/')
def index():
    return "Flask app is running"


@app.route('/process_resume', methods=['POST'])
def process_resume():
    # Expecting JSON data with 'resume_text' and 'api_key' fields
    if not request.json or 'pdf_resume_text' not in request.json or 'api_key' not in request.json:
        return jsonify({"error": "Missing required data (resume text or API key)"}), 400
    
    resume_text = request.json['pdf_resume_text']
    api_key = request.json['api_key']
    
    resume_extractor = ResumeExtractor()  
    data = resume_extractor.process_extract_text_from_pdf(api_key, resume_text)

    
    if data:
        return jsonify(data)
    
    return jsonify({"error": "Error processing resume text"}), 500


if __name__ == "__main__":
    app.run(debug=True)
def apikey():
    return "API_KEY" #enter api key
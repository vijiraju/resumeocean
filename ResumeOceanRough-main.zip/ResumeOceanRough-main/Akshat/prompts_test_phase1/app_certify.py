# Importing libraries
import os
import glob
import warnings
import json
from dotenv import load_dotenv, find_dotenv
from langchain_community.document_loaders import PDFMinerLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.retrievers import ContextualCompressionRetriever
from langchain.retrievers.document_compressors import CohereRerank
from langchain_community.llms import Cohere
from langchain_openai import OpenAIEmbeddings
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain_community.vectorstores import FAISS
import tiktoken
from pathlib import Path

# Constants
#Path= r"C:\Users\Nishanthi.Sekaran.CORPBRISTLECONE\OneDrive - Mahindra & Mahindra Ltd.-55241918-Bristlecone India Pvt Ltd\Resume_DataExtraction\CV_Analyser_Streamlit\Certificate"  # Define your temporary directory
TMP_DIR = Path(__file__).resolve().parent.joinpath("data", "tmp")

# Suppressing warnings
warnings.filterwarnings("ignore", category=FutureWarning)

def get_api_keys_from_local_env():
    """Get OpenAI, Gemini and Cohere API keys from local .env file"""
    try:
        found_dotenv = find_dotenv("keys.env", usecwd=True)
        load_dotenv(found_dotenv)
        try:
            openai_api_key = os.getenv("api_key_openai")
        except:
            openai_api_key = ""
        try:
            google_api_key = os.getenv("api_key_google")
        except:
            google_api_key = ""
        try:
            cohere_api_key = os.getenv("api_key_cohere")
        except:
            cohere_api_key = ""
    except Exception as e:
        print(e)

    return openai_api_key, google_api_key, cohere_api_key

def langchain_document_loader(file_path):
    """Load and split a PDF file in Langchain."""
    if file_path.endswith(".pdf"):
        loader = PDFMinerLoader(file_path=file_path)
    else:
        raise ValueError("You can only upload .pdf files!")

    documents = loader.load_and_split()

    for i in range(len(documents)):
        documents[i].metadata = {
            "source": documents[i].metadata["source"],
            "doc_number": i,
        }

    return documents


def delte_temp_files():
    """Delete temporary files from TMP_DIR."""
    files = glob.glob(os.path.join(TMP_DIR, "*"))
    for f in files:
        try:
            os.remove(f)
        except Exception as e:
            print(f"Error deleting {f}: {e}")


def save_uploaded_file(uploaded_file):
    """Save the uploaded file to TMP_DIR."""
    temp_file_path = os.path.join(TMP_DIR, uploaded_file.name)
    with open(temp_file_path, "wb") as temp_file:
        temp_file.write(uploaded_file.read())
    return temp_file_path


def tiktoken_tokens(documents, model="gpt-3.5-turbo-0125"):
    """Use tiktoken to return a list of token length per document."""
    encoding = tiktoken.encoding_for_model(model)
    tokens_length = [len(encoding.encode(doc)) for doc in documents]
    return tokens_length


def select_embeddings_model(LLM_service="OpenAI"):
    """Select the Embeddings model."""
    if LLM_service == "OpenAI":
        embeddings = OpenAIEmbeddings(api_key=openai_api_key)
    elif LLM_service == "Google":
        embeddings = GoogleGenerativeAIEmbeddings(
            model="models/embedding-001", google_api_key=google_api_key
        )
    else:
        raise ValueError("Invalid LLM service selected.")
    return embeddings


def create_vectorstore(embeddings, documents):
    """Create a Faiss vector database."""
    vector_store = FAISS.from_documents(documents=documents, embedding=embeddings)
    return vector_store


def Vectorstore_backed_retriever(
    vectorstore, search_type="similarity", k=4, score_threshold=None
):
    """Create a vectorstore-backed retriever."""
    search_kwargs = {}
    if k is not None:
        search_kwargs["k"] = k
    if score_threshold is not None:
        search_kwargs["score_threshold"] = score_threshold

    retriever = vectorstore.as_retriever(
        search_type=search_type, search_kwargs=search_kwargs
    )
    return retriever


def CohereRerank_retriever(
    base_retriever, cohere_api_key, cohere_model="rerank-multilingual-v2.0", top_n=4
):
    """Build a ContextualCompressionRetriever using Cohere Rerank endpoint."""
    compressor = CohereRerank(
        cohere_api_key=cohere_api_key, model=cohere_model, top_n=top_n
    )

    retriever_Cohere = ContextualCompressionRetriever(
        base_compressor=compressor, base_retriever=base_retriever
    )
    return retriever_Cohere


def retrieval_main(uploaded_file_path, LLM_provider, cohere_api_key):
    """Create a Langchain retrieval."""
    delte_temp_files()

    
    documents = langchain_document_loader(uploaded_file_path)

    embeddings = select_embeddings_model(LLM_provider)

    vector_store = create_vectorstore(embeddings, documents)

    base_retriever = Vectorstore_backed_retriever(
        vector_store, "similarity", k=min(4, len(documents))
    )

    retriever = CohereRerank_retriever(
        base_retriever=base_retriever,
        cohere_api_key=cohere_api_key,
        cohere_model="rerank-multilingual-v2.0",
        top_n=min(2, len(documents)),
    )

    return documents, retriever


# Example usage:
uploaded_file_path = r"E:\Internship\StuValley\Dataset\Nishanthi Resume.pdf"
LLM_provider1 = "OpenAI" 
LLM_provider2 = "Google" 

openai_api_key, google_api_key, cohere_api_key = get_api_keys_from_local_env()
documents, retriever = retrieval_main(uploaded_file_path, LLM_provider1, cohere_api_key)
#documents, retriever = retrieval_main(uploaded_file_path, LLM_provider2, cohere_api_key)

# print(documents)
# print(retriever)

json_results = []

# Loop through each Document object
for doc in documents:
    doc_dict = {
        "page_content": doc.page_content,
    }
    json_results.append(doc_dict)

# Concatenate page_content strings into a single string
concatenated_content = ""
for result in json_results:
    concatenated_content += result["page_content"]

# Create a dictionary with concatenated content
final_result = {"page_content": concatenated_content}

# Print or write the JSON data to a file
print(final_result)

with open("extracted_data.txt", "w", encoding="utf-8") as file:
    for value in final_result.values():
        file.write(f"{value}\n")
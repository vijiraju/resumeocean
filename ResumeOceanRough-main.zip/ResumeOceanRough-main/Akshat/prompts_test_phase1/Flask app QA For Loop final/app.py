import os
import json
import openai
import logging
from flask import Flask, render_template, redirect, request, jsonify


app = Flask(__name__)


class ResumeExtractor:
    def _init_(self):
        self.app = app
        self.init_logging()

    def init_logging(self):
        logging.basicConfig(filename='extract_data.log', level=logging.INFO)
    
    def prompt_input(self,key):
        prompt = {
            "fname": "What is the first name present in the resume? [respond Only in a single word that is first word]",
            "lastName": "What is the last name from the full name of the person whose resume this is ? [respond Only in a single word that is last name] [eg: if full name Sohrab Ali then respond only with ALI ,if full name Akshat Jain then respond only with JAin , if full name D.K Bose then respond only with Bose]",
            "dob": "What is the date of birth present in the resume? [Only provide single string]",
            "age": "What is the age (Current year - Date of Birth year) present in the resume? [Only provide single integer]",
            "email": "What is the email present in the resume? [Only provide single string]",
            "address": "What is the address present in the resume? [Only provide string]",
            "mobile": "What is the mobile number present in the resume? [Only provide single long integer]",
            "LinkedIn": "What is the LinkedIn profile present in the resume? [Only provide single link]",
            "orcidId": "What is the ORCID ID for the research papers present in the resume? [Only provide single id]",
            "totalIndustryExperience": "Calculate the total industry years of experience of the person present in the resume. [Sum of all the years of work experience by using using start and ending dates and provide integer value + 'years']",
            "summaryDetails": "Create a profile summary of this resume in in first person using the given data ? [Only provide 2 lines string]",
            "degree": "Please extract the following information from the resume:\nProvide the degrees obtained ([Undergrad Degree], [Postgrad Degree/Masters Degree],[12th Degree/H.S.C],[10th Degree/S.S.C]). List all the degree names.\nList the years of passing for each degree category ([Undergrad Degree], [Postgrad Degree/Masters Degree],[12th Degree/H.S.C],[10th Degree/S.S.C]). Provide the years as integers.\nProvide the educational institution or board names mentioned in the resume, including universities, colleges, or schools. List all the names.\n\nExample format for each category:\nDegree Names:\n1. Answer1\n2. Answer2\n3. Answer3\nYears of Passing:\n1. Answer1\n2. Answer2\n3. Answer3\nEducational Institutions or Boards:\n1. Answer1\n2. Answer2\n3. Answer3\n.",
            "course": "What are the courses taken in the degrees present in the resume? Answer in points and keep it precise. [Only provide string separated by ',']",
            "marks": "What are the CGPA (Undergrad Degree, Postgrad Degree) present in the resume? Answer in points and keep it precise. [Only provide integer]",
            "yearOfPass": "What are the years of passing ([Undergrad Degree], [Postgrad Degree/Masters Degree],[12th Degree/H.S.C],[10th Degree/S.S.C]) present in the resume? Answer in points and keep it precise. [Only provide integer]. Print all the results in different lines.",
            "boardsName": "What are the board's names (10th Degree, 12th Degree) present in the resume? Answer in points and keep it precise. [Only provide string]",
            "percentage": "What are the percentages (10th Degree, 12th Degree) present in the resume? Answer in points  [provide integer value + '% in 10th and % in 12th']",
            "college": "Please provide me the only educational OR Academic OR University OR Board mentioned in the resume, or list down the qualifications collegeOr School name. Answer in points and keep it precise. Print all the results in different lines.",
            "educational_qual": """Please extract the following information from the resume:
                    Provide the degrees obtained ([Undergrad Degree], [Postgrad Degree/Masters Degree],[12th Degree/H.S.C],[10th Degree/S.S.C]). List all the degree names.
                    List the years of passing for each degree category ([Undergrad Degree], [Postgrad Degree/Masters Degree],[12th Degree/H.S.C],[10th Degree/S.S.C]). Provide the years as integers.
                    Provide the educational institution or board names mentioned in the resume, including universities, colleges, or schools. List all the names.
                    Example format for each category:
                     degreenames:
                    1. Answer1
                    2. Answer2
                    3. Answer3
                    yearsOfPassing:
                    1. Answer1
                    2. Answer2
                    3. Answer3
                    educationalInstituteOrBoards:
                    1. Answer1
                    2. Answer2
                    3. Answer3
            .""",

            "Work Experience": "What is/are the work experience present in resume?  Answer in points and keep it precise. [Only provide single 2 lines string]",
            "nameOfEmployer": "What are the names of the employers present in the resume for the particular job positions? Answer in points and keep it precise. [Only provide string]",
            "department": "What are the departments he/she work with for the particular job positions that are present in the resume? Answer in points [Only provide string]",
            "postDesignation": "What are the post designations for the particular job positions of the person in the resume? Answer in points and keep it precise. [Only provide string]",
            "periodOfEmploymentFrom": "What are the starting tenure of work employment for the particular job positions in the resume? Answer in points and keep it precise. [Only provide integer] [eg: if the format will be DD1/MM1/YYYY1 - DD2/MM2/YYYY2, then keep DD1/MM1/YYYY1 only similarly, also the format can be DD1/MM1/YYYY1  or MM/YYYY or YYYY as present in resume]",
            "periodOfEmploymentTo": "What are the ending tenure of work employment for the particular job positions in the resume? Answer in points and keep it precise [Only provide single integer] [eg: if the format will be DD1/MM1/YYYY1 - DD2/MM2/YYYY2, then keep DD2/MM2/YYYY2 only similarly, also the format will be DD/MM/YYYY or MM/YYYY or YYYY as present in resume, or if it is ongoining then print 'Present/']",
            "grossSalary": "What is the gross salary for the particular job positions in the resume? [Answer in 'Rs/$' + integer value]",         
            "responsibilities": """What are the job responsibilities OR EXPERIENCE for the particular job positions in the resume? Answer in points and keep it precise [Only provide string] 
                     [Example: If there are multiple answers in responsibilities OR EXPERIENCE then , display them as follows:
                     1. Answer1
                        1.1 Answer1
                        1.2 Answer2
                     2. Answer2
                        2.1 Answer1
                        2.2 Answer2
                     3. Answer3
                    ]          
            .""",

            "skills": "Generate 10 technical skills+frameworks and soft skills with respect to why should you hire this person on the basis of there skillset of the person in the resume ? Answer in points [Only provide string separated by ','] [put all skills like AI,.. in a string without any additional text or explanation]",
            "selfRating": "Rate his 10 technical skills+frameworks and soft skills rating out of 10 with respect to why should you hire this person on the basis of there skillset of the person in the resume ? Answer in points [Only provide 2 line string]",
            "whyRate": "Generate a why should you hire this person on the basis of there skillset of the person in the resume ? Answer in points [Only provide 2 line string] ",
            "nameOfAwardsAchievements": "What are the awards/achievements+certificates+academic achievements of the person in the resume? [Only provide string separated by ',']",
            "institutionsOrganization": "What are the institutions that provided the awards/ certificates of the person in the resume? [Only provide string separated by ',']",
            "institutionsOrganizationName": "What are the institution/organization  that provided the awards/ certificates of the person in the resume ? [Only provide string separated by ',']",
            "detailsofAwards/Cerifications": "What are the details of awards/certifications of the person in the resume?",
            "dateOfAwards": "What are the date of awards obtained of the person in the resume?",
            "awardsTitle": "What are the awards title obtained by the person in the resume?",
            "urlAwards": "What are the URL of awards of the person in the resume ?",
            "typesOfAchievment": "What are the types of awards/achievement of the person in the resume ?"   
        }
        return prompt.get(key)
        
    def openaigpt(self, api_key, prompt_input):
        openai.api_key = api_key
        model_name = "gpt-3.5-turbo-16k-0613"
        role = f"""You are the AI Chatbot Assistant to a Hiring Human resource executive having a conversation with the Hiring Human resource executive provided with a Resume, extract information based on the question and 
                    provide answers from it.\nJust directly print one word answer, if you obtain something related to it, but thorougly check and provide optimal results please don't imitate by yourself only if the information present in the resume than print\nProvide 'No information available' when that particular value is not present in resume\nPrint all the results in different lines"""
        messages = [
            {"role": "system", "content": role},
            {"role": "user", "content": prompt_input},
        ]
        response = openai.ChatCompletion.create(
            model=model_name,
            messages=messages,
            max_tokens=4096,
            temperature=0.4,
            stop=None,
            n=1
        )
        return response["choices"][0]["message"]["content"]
    
    def index(self):
        return render_template('upload.html')

    def process_extract_text_from_pdf(self,api_key, text):                        

        output_dict = {}
        
        prompt_dict = {key: self.prompt_input(key) for key in [
        "fname", "lastName", "dob", "age", "email", "address", "mobile", "LinkedIn", "orcidId",
        "totalIndustryExperience", "summaryDetails", "degree", "course", "marks", "yearOfPass",
        "boardsName", "percentage", "college", "educational_qual","Work Experience","nameOfEmployer", "department", "postDesignation",
        "periodOfEmploymentFrom", "periodOfEmploymentTo", "grossSalary", "responsibilities",
        "skills", "selfRating", "whyRate", "nameOfAwardsAchievements", "institutionsOrganization",
        "institutionsOrganizationName", "detailsofAwards/Cerifications", "dateOfAwards",
        "awardsTitle", "urlAwards", "typesOfAchievment"
        ]}
        
        if isinstance(text, list):
            text = ' '.join(text)
        
        for key, prompt_text in prompt_dict.items():
            callingtext = self.process_string(prompt_text + ' ' + text)
            keyoutput = self.openaigpt(api_key, callingtext)
            output_dict[key] = keyoutput

        if output_dict:
            # with open(os.path.join(self.app.config['UPLOAD_FOLDER'], 'extracted_features.json'), 'w') as f:
            #     json.dump(output_dict, f, indent=4)
            logging.info("Extraction completed. Extracted features saved.")
            return json.dumps(output_dict)
        
    def process_string(self,input_str):
        if len(input_str) > 4096:
            return input_str[:4096]
        else:
            return input_str
        
@app.route('/')
def index():
    return "Flask app is running"


@app.route('/process_resume', methods=['POST'])
def process_resume():
    # Expecting JSON data with 'resume_text' and 'api_key' fields
    if not request.json or 'pdf_resume_text' not in request.json or 'api_key' not in request.json:
        return jsonify({"error": "Missing required data (resume text or API key)"}), 400
    
    resume_text = request.json['pdf_resume_text']
    api_key = request.json['api_key']
    
    resume_extractor = ResumeExtractor()  
    data = resume_extractor.process_extract_text_from_pdf(api_key, resume_text)

    
    if data:
        return jsonify(data)
    
    return jsonify({"error": "Error processing resume text"}), 500


if __name__ == "__main__":
    app.run(debug=True)
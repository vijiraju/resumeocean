import requests
from chatgptapikey import apikey
import PyPDF2
from docx import Document
from pathlib import Path

# URL for the Flask API endpoint
url = 'http://127.0.0.1:5000/process_resume'

# Replace this with the actual resume text you want to process

chatgptapikey = apikey()

def extract_text_from_pdf(pdf_path):
    """Extracts text from a PDF file."""
    text = ""
    with open(pdf_path, 'rb') as file:
        pdf_reader = PyPDF2.PdfReader(file)
        for page in pdf_reader.pages:
            text += page.extract_text() + "\n"  # Concatenate text from each page
    return text

def extract_data_from_docx(file_path):
    document = Document(file_path)
    data = []
    for paragraph in document.paragraphs:
        data.append(paragraph.text)
    return data


# # Use Path to handle the file path
# pdf_path = Path(r"E:\Internship\StuValley\Dataset\DIKESH RAY.pdf")
# pdftext = extract_text_from_pdf(pdf_path)
# docstext = extract_data_from_docx(file_path)
with open(r"E:\Internship\StuValley\test_phase1\prompts\extracted_data.txt", "r", encoding="utf-8") as file:
    extracted_data = file.read()


# The data to be sent in the POST request
data = {'pdf_resume_text': extracted_data, 'api_key': chatgptapikey}

# Sending the POST request with JSON data
response = requests.post(url, json=data)

# Check if the request was successfull
if response.status_code == 200:
    # The API call was successful, you can process the response data
    print("Success!")
    print(response.json())  # This prints the structured data extracted from the resume text
else:
    # The API call failed, handle errors here
    print("Failed to process resume.")
    print(response.text)


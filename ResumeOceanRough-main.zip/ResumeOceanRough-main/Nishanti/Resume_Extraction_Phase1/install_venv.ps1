python -m venv virtualenv
.\virtualenv\scripts\activate
python -m pip install --upgrade pip

pip install python-dotenv
pip install langchain_community
pip install langchain
pip install langchain_openai
pip install langchain_google_genai
pip install pdfminer.six
pip install faiss-cpu
pip install cohere
pip install streamlit

pip freeze > requirements.txt


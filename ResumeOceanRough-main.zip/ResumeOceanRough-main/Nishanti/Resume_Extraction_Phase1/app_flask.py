import os
import glob
import warnings
import datetime
import json
from openaikey_all import *
from langchain_community.document_loaders import PDFMinerLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.retrievers import ContextualCompressionRetriever
#from langchain.retrievers.document_compressors import CohereRerank
from langchain_cohere import CohereRerank
from langchain_community.llms import Cohere
from langchain_openai import OpenAIEmbeddings
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain_community.vectorstores import FAISS
import tiktoken
from flask import Flask, request, jsonify
from werkzeug.utils import secure_filename
from langchain.prompts import PromptTemplate
from app_constants import templates
from langchain_openai import ChatOpenAI
import logging
# Suppressing warnings
warnings.filterwarnings("ignore", category=FutureWarning)
# Constants
TMP_DIR = os.path.join(os.path.dirname(__file__), "data", "tmp")

app = Flask(__name__)

class ResumeExtractor:
    def __init__(self, openai_api_key, google_api_key, cohere_api_key):
        
        self.openai_api_key = openai_api_key
        self.google_api_key = google_api_key
        self.cohere_api_key = cohere_api_key
        self.retriever = None
        self.app = app
        self.init_logging()

    def init_logging(self):
        logging.basicConfig(filename='extract_data.log', level=logging.INFO)

    def delte_temp_files(self):
        """Delete temporary files from TMP_DIR."""
        files = glob.glob(os.path.join(TMP_DIR, "*"))
        for f in files:
            try:
                os.remove(f)
            except Exception as e:
                print(f"Error deleting {f}: {e}")
    def langchain_document_loader(self, file_path):
        """Load and split a PDF file in Langchain."""
        if file_path.endswith(".pdf"):
            loader = PDFMinerLoader(file_path=file_path)
        else:
            raise ValueError("You can only upload .pdf files!")

        documents = loader.load_and_split()

        for i in range(len(documents)):
            documents[i].metadata = {
                "source": documents[i].metadata["source"],
                "doc_number": i,
            }

        return documents
    
    def get_current_time(self):
        current_time = (datetime.datetime.now()).strftime("%H:%M:%S")
        return current_time

    def save_uploaded_file(self, uploaded_file):
        """Save the uploaded file to TMP_DIR."""
        temp_file_path = os.path.join(TMP_DIR, uploaded_file.name)
        with open(temp_file_path, "wb") as temp_file:
            temp_file.write(uploaded_file.read())
        return temp_file_path

    def tiktoken_tokens(self, documents, model="gpt-3.5-turbo-0125"):
        """Use tiktoken to return a list of token length per document."""
        encoding = tiktoken.encoding_for_model(model)
        tokens_length = [len(encoding.encode(doc)) for doc in documents]
        return tokens_length


    def select_embeddings_model(self, LLM_service="OpenAI"):
        """Select the Embeddings model."""
        if LLM_service == "OpenAI":
            if self.openai_api_key is None:
                raise ValueError("OpenAI API key is required.")
            embeddings = OpenAIEmbeddings(api_key=self.openai_api_key)
        elif LLM_service == "Google":
            embeddings = GoogleGenerativeAIEmbeddings(
                model="models/embedding-001", google_api_key=self.google_api_key
            )
        else:
            raise ValueError("Invalid LLM service selected.")
        return embeddings

    def create_vectorstore(self, embeddings, documents):
        """Create a Faiss vector database."""
        vector_store = FAISS.from_documents(documents=documents, embedding=embeddings)
        return vector_store


    def Vectorstore_backed_retriever(self,
        vectorstore, search_type="similarity", k=4, score_threshold=None
    ):
        """Create a vectorstore-backed retriever."""
        search_kwargs = {}
        if k is not None:
            search_kwargs["k"] = k
        if score_threshold is not None:
            search_kwargs["score_threshold"] = score_threshold

        retrieverS = vectorstore.as_retriever(
            search_type=search_type, search_kwargs=search_kwargs
        )
        return retrieverS


    def CohereRerank_retriever(self,
        base_retriever, cohere_api_key, cohere_model="rerank-multilingual-v2.0", top_n=4
    ):
        """Build a ContextualCompressionRetriever using Cohere Rerank endpoint."""
        compressor = CohereRerank(
            cohere_api_key=cohere_api_key, model=cohere_model, top_n=top_n
        )

        retriever_Cohere = ContextualCompressionRetriever(
            base_compressor=compressor, base_retriever=base_retriever
        )
        return retriever_Cohere

    def create_prompt_template(self, resume_sections, language="english"):
        """create the promptTemplate.
        Parameters:
        resume_sections (list): List of CV sections from which information will be extracted.
        language (str): the language of the assistant, default="english".
        """

        # Create the Template
        template = f"""For the following resume, output in {language} the following information:\n\n"""

        for key in resume_sections:
            template += key + ": " + templates[key] + "\n\n"

        template += "For any requested information, if it is not found, output 'unknown' or ['unknown'] accordingly.\n\n"
        template += (
            """Format the final output as a json dictionary with the following keys: ("""
        )

        for key in resume_sections:
            template += "" + key + ", "
        template = template[:-2] + ")"  # remove the last ", "

        template += """\n\nResume: {text}"""

        # Create the PromptTemplate
        prompt_template = PromptTemplate.from_template(template)

        return prompt_template

    def extract_from_text(self, text, start_tag, end_tag=None):
        """Use start and end tags to extract a substring from text.
        This helper function is used to parse the response content on the LLM in case 'json.loads' fails.
        """
        start_index = text.find(start_tag)
        if end_tag is None:
            extacted_txt = text[start_index + len(start_tag) :]
        else:
            end_index = text.find(end_tag)
            extacted_txt = text[start_index + len(start_tag) : end_index]

        return extacted_txt

    def convert_text_to_list_of_dicts(self, text, dict_keys):
        """Convert text to a python list of dicts.
        Parameters:
        - text: string containing a list of dicts
        - dict_keys (list): the keys of the dictionary which will be returned.
        Output:
        - list_of_dicts (list): the list of dicts to return.
        """
        list_of_dicts = []

        if text != "":
            text_splitted = text.split("},\n")
            dict_keys.append(None)

            for i in range(len(text_splitted)):
                dict_i = {}

                for j in range(len(dict_keys) - 1):
                    key_value = self.extract_from_text(
                        text_splitted[i], f'"{dict_keys[j]}": ', f'"{dict_keys[j+1]}": '
                    )
                    key_value = key_value[: key_value.rfind(",\n")].strip()[1:-1]
                    dict_i[dict_keys[j]] = key_value

                list_of_dicts.append(dict_i)  # add the dict to the list.

        return list_of_dicts
    
    def invoke_LLM(self,
        llm,
        documents,
        resume_sections: list,
        info_message="",
        language="english",
    ):
        """Invoke LLM and get a response.
        Parameters:
        - llm: the LLM to call
        - documents: our Langchain Documents. Will be use to format the prompt_template.
        - resume_sections (list): List of resume sections to be parsed.
        - info_message (str): display an informational message.
        - language (str): Assistant language. Will be use to format the prompt_template.

        Output:
        - response_content (str): the content of the LLM response.
        - response_tokens_count (int): count of response tokens.
        """

        # 1. display the info message
        print(f"**{self.get_current_time()}** \t{info_message}")

        # 2. Create the promptTemplate.
        prompt_template = self.create_prompt_template(
            resume_sections,
            language=language,
        )

        # 3. Format promptTemplate with the full documents
        if language is not None:
            prompt = prompt_template.format_prompt(text=documents, language=language).text
        else:
            prompt = prompt_template.format_prompt(text=documents).text

        # 4. Invoke LLM
        response = llm.invoke(prompt)

        response_content = response.content[
            response.content.find("{") : response.content.rfind("}") + 1
        ]
        response_tokens_count = sum(self.tiktoken_tokens([response_content]))
        

        return response_content, response_tokens_count

    def ResponseContent_Parser(self,
        response_content, list_fields, list_rfind, list_exclude_first_car
    ):
        """This is a function for parsing any response_content.
        Parameters:
        - response_content (str): the content of the LLM response we are going to parse.
        - list_fields (list): List of dictionary fields returned by this function.
            A field can be a dictionary. The key of the dict will not be parsed.
            Example: [{'Contact__information':['candidate__location','candidate__email','candidate__phone','candidate__social_media']},
                    'summaryDetails']
                    We will not parse the content for 'Contact__information'.
        - list_rfind (list): To parse the content of a field, first we will extract the text between this field and the next field.
            Then, extract text using `rfind` Python command, which returns the highest index in the text where the substring is found.
        - list_exclude_first_car (list): Exclusion or not of the first and last characters.

        Output:
        - INFORMATION_dict: dictionary, where fields are the keys and parsed texts are the values.

        """

        list_fields_detailed = (
            []
        )  # list of tupples. tupple = (field,extract info (boolean), parent field)

        for field in list_fields:
            if type(field) is dict:
                list_fields_detailed.append(
                    (list(field.keys())[0], False, None)
                )  # We will not extract any value for the text between this tag and the next.
                for val in list(field.values())[0]:
                    list_fields_detailed.append((val, True, list(field.keys())[0]))
            else:
                list_fields_detailed.append((field, True, None))

        list_fields_detailed.append((None, False, None))

        # Parse the response_content
        INFORMATION_dict = {}

        for i in range(len(list_fields_detailed) - 1):
            if list_fields_detailed[i][1] is False:  # Extract info = False
                INFORMATION_dict[list_fields_detailed[i][0]] = {}  # Initialize the dict
            if list_fields_detailed[i][1]:
                extracted_value = self.extract_from_text(
                    response_content,
                    f'"{list_fields_detailed[i][0]}": ',
                    f'"{list_fields_detailed[i+1][0]}":',
                )
                extracted_value = extracted_value[
                    : extracted_value.rfind(list_rfind[i])
                ].strip()
                if list_exclude_first_car[i]:
                    extracted_value = extracted_value[1:-1].strip()
                if list_fields_detailed[i][2] is None:
                    INFORMATION_dict[list_fields_detailed[i][0]] = extracted_value
                else:
                    INFORMATION_dict[list_fields_detailed[i][2]][
                        list_fields_detailed[i][0]
                    ] = extracted_value

        return INFORMATION_dict

    def Extract_contact_information(self, llm, documents):
    #     """Extract Contact Information: Name, Title, Location, Email, Phone number and Social media profiles."""

        try:
            response_content, response_tokens_count = self.invoke_LLM(
                llm,
                documents,
                resume_sections=["Contact__information"],
                info_message="Extract and evaluate contact information...",
                language="english"
            )

            try:
                # Load response_content to json dictionary
                CONTACT_INFORMATION = json.loads(response_content, strict=False)
            except Exception as e:
                print("[ERROR] json.loads returns error:", e)
                print("\n[INFO] Parse response content...\n")

                list_fields = [
                    {
                        "Contact__information": [
                            "candidate__name",
                            "candidate__title",
                            "candidate__location",
                            "candidate__email",
                            "candidate__phone",
                            "candidate__social_media",
                            "evaluation__ContactInfo",
                            "score__ContactInfo",
                        ]
                    }
                ]
                list_rfind = [",\n", ",\n", ",\n", ",\n", ",\n", ",\n", ",\n", ",\n", "}\n"]
                list_exclude_first_car = [
                    True,
                    True,
                    True,
                    True,
                    True,
                    True,
                    False,
                    True,
                    False,
                ]
                CONTACT_INFORMATION = self.ResponseContent_Parser(
                    response_content, list_fields, list_rfind, list_exclude_first_car
                )
                # convert score to int
                try:
                    CONTACT_INFORMATION["Contact__information"]["score__ContactInfo"] = int(
                        CONTACT_INFORMATION["Contact__information"]["score__ContactInfo"]
                    )
                except:
                    CONTACT_INFORMATION["Contact__information"]["score__ContactInfo"] = -1

        except Exception as exception:
            print(f"[Error] {exception}")
            CONTACT_INFORMATION = {
                "Contact__information": {
                    "candidate__name": "unknown",
                    "candidate__title": "unknown",
                    "candidate__location": "unknown",
                    "candidate__email": "unknown",
                    "candidate__phone": "unknown",
                    "candidate__social_media": "unknown",
                    "evaluation__ContactInfo": "unknown",
                    "score__ContactInfo": -1,
                }
            }

        return CONTACT_INFORMATION

    def Extract_Evaluate_Summary(self, llm, documents):
        """Extract, evaluate and strengthen the summary."""
        try:
            response_content, response_tokens_count = self.invoke_LLM(
                llm,
                documents,
                resume_sections=["CV__Summary"],
                info_message="Extract and evaluate the Summary....",
                language="english",
            )
            try:
                # Load response_content to json dictionary
                SUMMARY_SECTION = json.loads(response_content, strict=False)
            except Exception as e:
                print("[ERROR] json.loads returns error:", e)
                print("\n[INFO] Parse response content...\n")
                
                list_fields = [
                    {
                        "CV__Summary": [
                            "summaryDetails",
                            "totalIndustryExperience",
                        ]
                    }
                ]
                
                list_rfind = [",\n", ",\n", "}\n"]
                
                list_exclude_first_car = [
                    True,
                    True
                    ]

                SUMMARY_SECTION = self.ResponseContent_Parser(
                    response_content, list_fields, list_rfind, list_exclude_first_car
                )

        except Exception as exception:
            print(f"[Error] {exception}")
            SUMMARY_SECTION = {
                "CV__Summary": {
                    "summaryDetails": "unknown",
                    "totalIndustryExperience": "unknown",
                }
            }

        return SUMMARY_SECTION


    def Extract_Education_Language(self, llm, documents):
        """Extract and evaluate education and language sections."""

        try:
            response_content, response_tokens_count = self.invoke_LLM(
                llm,
                documents,
                resume_sections=[
                    "CV__Education",
                    "Education__evaluation",
                    "CV__Languages",
                    "Languages__evaluation",
                ],
                info_message="Extract and evaluate education and language sections...",
                language="english",
            )

            try:
                # Load response_content to json dictionary
                Education_Language_sections = json.loads(response_content, strict=False)
            except Exception as e:
                print("[ERROR] json.loads returns error:", e)
                print("\n[INFO] Parse response content...\n")

                list_fields = [
                    "CV__Education",
                    {"Education__evaluation": ["score__edu", "evaluation__edu"]},
                    "CV__Languages",
                    {"Languages__evaluation": ["score__language", "evaluation__language"]},
                ]

                list_rfind = [",\n", ",\n", ",\n", ",\n", ",\n", ",\n", ",\n", "\n","\n", ",\n", "\n"]
                list_exclude_first_car = [True, True, True, False, True, True, True, True, True, True, False, True]

                Education_Language_sections = self.ResponseContent_Parser(
                    response_content, list_fields, list_rfind, list_exclude_first_car
                )

                # Convert scores to int
                try:
                    Education_Language_sections["Education__evaluation"]["score__edu"] = (
                        int(
                            Education_Language_sections["Education__evaluation"][
                                "score__edu"
                            ]
                        )
                    )
                except:
                    Education_Language_sections["Education__evaluation"]["score__edu"] = -1

                try:
                    Education_Language_sections["Languages__evaluation"][
                        "score__language"
                    ] = int(
                        Education_Language_sections["Languages__evaluation"][
                            "score__language"
                        ]
                    )
                except:
                    Education_Language_sections["Languages__evaluation"][
                        "score__language"
                    ] = -1

                # Split languages and educational texts into a Python list of dict
                languages = Education_Language_sections["CV__Languages"]
                Education_Language_sections["CV__Languages"] = (
                    self.convert_text_to_list_of_dicts(
                        text=languages[
                            languages.find("[") + 1 : languages.rfind("]")
                        ].strip(),
                        dict_keys=["spoken__language", "language__fluency"],
                    )
                )
                education = Education_Language_sections["CV__Education"]
                Education_Language_sections["CV__Education"] = (
                    self.convert_text_to_list_of_dicts(
                        text=education[
                            education.find("[") + 1 : education.rfind("]")
                        ].strip(),
                        dict_keys=[
                            # "edu__college",
                            # "edu__degree",
                            # "edu__start_date",
                            # "edu__end_date",
                            "degree", 
                            "course", 
                            "marks", 
                            "yearOfPass", 
                            "boardsName", 
                            "percentage", 
                            "college",
                            "educational_qual",
                        ],
                    )
                )
        except Exception as exception:
            print(exception)
            Education_Language_sections = {
                "CV__Education": [],
                "Education__evaluation": {"score__edu": -1, "evaluation__edu": "unknown"},
                "CV__Languages": [],
                "Languages__evaluation": {
                    "score__language": -1,
                    "evaluation__language": "unknown",
                },
            }

        return Education_Language_sections

    def Extract_Skills_and_Certifications(self, llm, documents):
        """Extract skills and certifications and evaluate these sections."""

        try:
            response_content, response_tokens_count = self.invoke_LLM(
                llm,
                documents,
                resume_sections=[
                    "skills",
                    "Skills__evaluation",
                    "CV__Certifications",
                    "Certif__evaluation",
                ],
                info_message="Extract and evaluate the skills and certifications...",
                language="english",
            )

            try:
                # Load response_content to json dictionary
                SKILLS_and_CERTIF = json.loads(response_content, strict=False)
            except Exception as e:
                print("[ERROR] json.loads returns error:", e)
                print("\n[INFO] Parse response content...\n")

                skills = self.extract_from_text(
                    response_content, '"skills": ', '"Skills__evaluation":'
                )
                skills = skills.replace("\n  ", "\n").replace("],\n", "").replace("[\n", "")
                selfRating = selfRating.replace("\n  ", "\n").replace("],\n", "").replace("[\n", "")
                # score_skills = extract_from_text(
                #     response_content, '"selfRating": ', '"whyRate":'
                # )
                evaluation_skills = self.extract_from_text(
                    response_content, '"whyRate": ', '"CV__Certifications":'
                )

                certif_text = self.extract_from_text(
                    response_content, '"CV__Certifications": ', '"Certif__evaluation":'
                )
                certif_score = self.extract_from_text(
                    response_content, '"score__certif": ', '"detailsofAwards/Cerifications":'
                )
                certif_eval = self.extract_from_text(
                    response_content, '"detailsofAwards/Cerifications": ', None
                )

                # Create the dictionary
                SKILLS_and_CERTIF = {}
                SKILLS_and_CERTIF["skills"] = [
                    skill.strip()[1:-1] for skill in skills.split(",\n")
                ]
                # try:
                #     score_skills_int = int(score_skills[0 : score_skills.rfind(",\n")])
                # except:
                #     score_skills_int = -1
                
                SKILLS_and_CERTIF["Skills__evaluation"] = {
                    "selfRating": [rating.strip()[1:-1] for rating in selfRating.split(",\n")],
                    "whyRate": evaluation_skills[
                        : evaluation_skills.rfind("}\n")
                    ].strip()[1:-1],
                }

                # Convert certificate text to list of dictionaries
                list_certifs = self.convert_text_to_list_of_dicts(
                    text=certif_text[
                        certif_text.find("[") + 1 : certif_text.rfind("]")
                    ].strip(),  # .strip()[1:-1]
                    dict_keys=[
                        "awardsTitle",
                        "institutionsOrganization",
                        "dateOfAwards",
                        "nameOfAwardsAchievements",
                        "urlAwards",
                        "typesOfAchievment",
                                        
                    ],
                )
                SKILLS_and_CERTIF["CV__Certifications"] = list_certifs
                try:
                    certif_score_int = int(certif_score[0 : certif_score.rfind(",\n")])
                except:
                    certif_score_int = -1
                SKILLS_and_CERTIF["Certif__evaluation"] = {
                    "score__certif": certif_score_int,
                    "detailsofAwards/Cerifications": certif_eval[: certif_eval.rfind("}\n")].strip()[
                        1:-1
                    ],
                }

        except Exception as exception:
            SKILLS_and_CERTIF = {
                "skills": [],
                "Skills__evaluation": {
                    "selfRating": -1,
                    "whyRate": "unknown",
                },
                "CV__Certifications": [],
                "Certif__evaluation": {
                    "score__certif": -1,
                    "detailsofAwards/Cerifications": "unknown",
                },
            }
            print(exception)

        return SKILLS_and_CERTIF


    def Extract_PROFESSIONAL_EXPERIENCE(self, llm, documents):
        """Extract list of work experience and projects."""

        try:
            response_content, response_tokens_count = self.invoke_LLM(
                llm,
                documents,
                resume_sections=["Work__experience", "CV__Projects"],
                info_message="Extract list of work experience and projects...",
                language="english",
            )

            try:
                # Load response_content to json dictionary
                PROFESSIONAL_EXPERIENCE = json.loads(response_content, strict=False)
            except Exception as e:
                print("[ERROR] json.loads returns error:", e)
                print("\n[INFO] Parse response content...\n")

                work_experiences = self.extract_from_text(
                    response_content, '"Work__experience": ', '"CV__Projects":'
                )
                projects = self.extract_from_text(response_content, '"CV__Projects": ', None)

                # Create the dictionary
                PROFESSIONAL_EXPERIENCE = {}
                PROFESSIONAL_EXPERIENCE["Work__experience"] = self.convert_text_to_list_of_dicts(
                    text=work_experiences[
                        work_experiences.find("[") + 1 : work_experiences.rfind("]")
                    ].strip()[1:-1],
                    dict_keys=[
                        "postDesignation"
                        "nameOfEmployer",
                        "periodOfEmploymentFrom",
                        "periodOfEmploymentTo",
                        "department",
                        "grossSalary",
                        "totalIndustryExperience",
                    ],
                )
                PROFESSIONAL_EXPERIENCE["CV__Projects"] = self.convert_text_to_list_of_dicts(
                    text=projects[projects.find("[") + 1 : projects.rfind("]")].strip()[
                        1:-1
                    ],
                    dict_keys=[
                        "project__title",
                        "project__start_date",
                        "project__end_date",
                    ],
                )
            # Exclude 'unknown' projects and work experiences
            try:
                for work_experience in PROFESSIONAL_EXPERIENCE["Work__experience"]:
                    if work_experience["postDesignation"] == "unknown":
                        PROFESSIONAL_EXPERIENCE["Work__experience"].remove(work_experience)
            except Exception as e:
                print(e)
            try:
                for project in PROFESSIONAL_EXPERIENCE["CV__Projects"]:
                    if project["project__title"] == "unknown":
                        PROFESSIONAL_EXPERIENCE["CV__Projects"].remove(project)
            except Exception as e:
                print(e)

        except Exception as exception:
            PROFESSIONAL_EXPERIENCE = {"Work__experience": [], "CV__Projects": []}
            print(exception)

        return PROFESSIONAL_EXPERIENCE

    def get_relevant_documents(self, query, documents):
        """Retreieve most relevant documents from Langchain documents using the CoherRerank retriever."""

        # 1.1. Retrieve documents using the CohereRerank retriever

        retrieved_docs = self.retriever.get_relevant_documents(query)

        # 1.2. Keep only relevant documents where relevance_score >= (max(relevance_scores) - 0.1)

        relevance_scores = [
            retrieved_docs[j].metadata["relevance_score"]
            for j in range(len(retrieved_docs))
        ]
        max_relevance_score = max(relevance_scores)
        threshold = max_relevance_score - 0.1

        relevant_doc_ids = []

        for j in range(len(retrieved_docs)):

            # keep relevant documents with (relevance_score >= threshold)

            if retrieved_docs[j].metadata["relevance_score"] >= threshold:
                # Append the retrieved document
                relevant_doc_ids.append(retrieved_docs[j].metadata["doc_number"])

        # Append the next document to the most relevant document, as relevant information may be split between two documents.
        relevant_doc_ids.append(min(relevant_doc_ids[0] + 1, len(documents) - 1))

        # Sort document ids
        relevant_doc_ids = sorted(set(relevant_doc_ids))

        # Get the most relevant documents
        relevant_documents = [documents[k] for k in relevant_doc_ids]

        return relevant_documents

    def Extract_Job_Responsibilities(self, llm, documents, PROFESSIONAL_EXPERIENCE):
        """Extract job responsibilities for each job in PROFESSIONAL_EXPERIENCE."""

        print(f"**{self.get_current_time()}** \tExtract work experience responsibilities...")

        for i in range(len(PROFESSIONAL_EXPERIENCE["Work__experience"])):
            try:
                Work_experience_i = PROFESSIONAL_EXPERIENCE["Work__experience"][i]

                # 1. Extract relevant documents
                query = f"""Extract from the resume delimited by triple backticks \
    all the duties and responsibilities of the following work experience: \
    (title = '{Work_experience_i['postDesignation']}'"""
                if str(Work_experience_i["nameOfEmployer"]) != "unknown":
                    query += f" and company = '{Work_experience_i['nameOfEmployer']}'"
                if str(Work_experience_i["periodOfEmploymentFrom"]) != "unknown":
                    query += f" and start date = '{Work_experience_i['periodOfEmploymentFrom']}'"
                if str(Work_experience_i["periodOfEmploymentTo"]) != "unknown":
                    query += f" and end date = '{Work_experience_i['periodOfEmploymentTo']}'"
                query += ")\n"

                try:
                    relevant_documents = self.get_relevant_documents(query, documents)
                except Exception as err:
                    print(f"get_relevant_documents error: {err}")
                    relevant_documents = documents

                # 2. Invoke LLM

                prompt = (
                    query
                    + f"""Output the duties in a json dictionary with the following keys (__duty_id__,__duty__). \
    Use this format: "1":"duty","2":"another duty".
    Resume:\n\n ```{relevant_documents}```"""
                )
                response = llm.invoke(prompt)

                # 3. Convert the response content to json dict and update work_experience
                response_content = response.content[
                    response.content.find("{") : response.content.rfind("}") + 1
                ]

                try:
                    Work_experience_i["responsibilities"] = json.loads(
                        response_content, strict=False
                    )  # Convert the response content to a json dict
                except Exception as e:
                    print("\njson.loads returns error:", e, "\n\n")
                    print("\n[INFO] Parse response content...\n")

                    Work_experience_i["responsibilities"] = {}
                    list_duties = (
                        response_content[
                            response_content.find("{") + 1 : response_content.rfind("}")
                        ]
                        .strip()
                        .split(",\n")
                    )

                    for j in range(len(list_duties)):
                        try:
                            Work_experience_i["responsibilities"][f"{j+1}"] = (
                                list_duties[j].split('":')[1].strip()[1:-1]
                            )
                        except:
                            Work_experience_i["responsibilities"][f"{j+1}"] = "unknown"

            except Exception as exception:
                Work_experience_i["responsibilities"] = {}
                print(exception)

        return PROFESSIONAL_EXPERIENCE


    def Extract_Project_Details(self, llm, documents, PROFESSIONAL_EXPERIENCE):
        """Extract project details for each project in PROFESSIONAL_EXPERIENCE."""

        print(f"**{self.get_current_time()}** \tExtract project details...")

        for i in range(len(PROFESSIONAL_EXPERIENCE["CV__Projects"])):
            try:
                project_i = PROFESSIONAL_EXPERIENCE["CV__Projects"][i]

                # 1. Extract relevant documents
                query = f"""Extract from the resume (delimited by triple backticks) what is listed about the following project: \
    (project title = '{project_i['project__title']}'"""
                if str(project_i["project__start_date"]) != "unknown":
                    query += f" and start date = '{project_i['project__start_date']}'"
                if str(project_i["project__end_date"]) != "unknown":
                    query += f" and end date = '{project_i['project__end_date']}'"
                query += ")"

                try:
                    relevant_documents = self.get_relevant_documents(query, documents)
                except Exception as err:
                    print(f"get_relevant_documents error: {err}")
                    relevant_documents = documents

                # 2. Invoke LLM

                prompt = (
                    query
                    + f"""Format the extracted text into a string (with bullet points).
    Resume:\n\n ```{relevant_documents}```"""
                )

                response = llm.invoke(prompt)

                response_content = response.content
                project_i["project__description"] = response_content

            except Exception as exception:
                project_i["project__description"] = "unknown"
                print(exception)

        return PROFESSIONAL_EXPERIENCE
    
    def retrieval_main(self, uploaded_file_path, LLM_provider1, cohere_api_key, openai_api_key, google_api_key):
        """Create a Langchain retrieval."""
        self.delte_temp_files()

        documents = self.langchain_document_loader(uploaded_file_path)

        embeddings = self.select_embeddings_model(LLM_provider1)

        vector_store = self.create_vectorstore(embeddings, documents)

        base_retriever = self.Vectorstore_backed_retriever(
            vector_store, "similarity", k=min(4, len(documents))
        )

        retriever = self.CohereRerank_retriever(
            base_retriever=base_retriever,
            cohere_api_key=cohere_api_key,
            cohere_model="rerank-multilingual-v2.0",
            top_n=min(2, len(documents)),
        )
        self.retriever = retriever
        return documents, retriever
    
    def process_resume_data(self, SCANNED_RESUME):
        
        data = SCANNED_RESUME

        contact_info = data.get('Contact__information', {})
        CV__Summary = data.get('CV__Summary', {})

        languages = []
        fluencies = []
        for language_info in data.get("CV__Languages", []):
            languages.append(language_info.get("spoken__language", ""))
            fluencies.append(language_info.get("language__fluency", ""))

        combined_data = {
            "spoken__language": languages,
            "language__fluency": fluencies
        }

        degree = []
        course = []
        marks = []
        yearOfPass = []
        boardsName = []
        percentage = []
        college = []
        educational_qual = []

        for edu_info in data.get("CV__Education", []):
            degree.append(edu_info.get("degree", ""))
            course.append(edu_info.get("course", ""))
            marks.append(edu_info.get("marks", ""))
            yearOfPass.append(edu_info.get("yearOfPass", ""))
            boardsName.append(edu_info.get("boardsName", ""))
            percentage.append(edu_info.get("percentage", ""))
            college.append(edu_info.get("college", ""))
            educational_qual.append(edu_info.get("educational_qual", ""))

        education_data = {
            "degree": degree,
            "course": course,
            "marks": marks,
            "yearOfPass": yearOfPass,
            "boardsName": boardsName,
            "percentage": percentage,
            "college": college,
            "educational_qual": educational_qual
        }

        skills = data.get("skills", {}).get("soft skills", []) + data.get("skills", {}).get("technical skills", [])
        skills_data = {"skills": skills}

        Skills__evaluation = data.get('Skills__evaluation', {})

        postDesignation = []
        nameOfEmployer = []
        periodOfEmploymentFrom = []
        periodOfEmploymentTo = []
        department = []
        grossSalary = []
        responsibilities = []

        for work_info in data.get("Work__experience", []):
            postDesignation.append(work_info.get("postDesignation", ""))
            nameOfEmployer.append(work_info.get("nameOfEmployer", ""))
            periodOfEmploymentFrom.append(work_info.get("periodOfEmploymentFrom", ""))
            periodOfEmploymentTo.append(work_info.get("periodOfEmploymentTo", ""))
            department.append(work_info.get("department", ""))
            grossSalary.append(work_info.get("grossSalary", ""))
            responsibilities.append(work_info.get("responsibilities", ""))

        work_experience = {
            "postDesignation": postDesignation,
            "nameOfEmployer": nameOfEmployer,
            "periodOfEmploymentFrom": periodOfEmploymentFrom,
            "periodOfEmploymentTo": periodOfEmploymentTo,
            "department": department,
            "grossSalary": grossSalary,
            "responsibilities": responsibilities
        }

        project__title = []
        project__start_date = []
        project__end_date = []
        project__description = []

        for projects_info in data.get("CV__Projects", []):
            project__title.append(projects_info.get("project__title", ""))
            project__start_date.append(projects_info.get("project__start_date", ""))
            project__end_date.append(projects_info.get("project__end_date", ""))
            project__description.append(projects_info.get("project__description", ""))

        projects_experience = {
            "project__title": project__title,
            "project__start_date": project__start_date,
            "project__end_date": project__end_date,
            "project__description": project__description
        }

        awards_titles = []
        institutions = []
        dates = []
        nameOfAwards = []
        urlAwards = []
        Achievmenttypes = []

        for certification in data.get("CV__Certifications", []):
            awards_titles.append(certification.get("awardsTitle", ""))
            institutions.append(certification.get("institutionsOrganization", ""))
            dates.append(certification.get("dateOfAwards", ""))
            nameOfAwards.append(certification.get("nameOfAwardsAchievements", ""))
            urlAwards.append(certification.get("urlAwards", ""))
            Achievmenttypes.append(certification.get("typesOfAchievment", ""))

        detailsofAwards = data.get('Certif__evaluation', {}).get('detailsofAwards/Cerifications', '')

        certifications = {
            "awardsTitle": awards_titles,
            "institutionsOrganization": institutions,
            "dateOfAwards": dates,
            "nameOfAwardsAchievements": nameOfAwards,
            "urlAwards": urlAwards,
            "typesOfAchievment": Achievmenttypes,
            "detailsofAwards/Cerifications": detailsofAwards
        }

        prompt = contact_info.copy()
        prompt.update(CV__Summary)
        prompt.update(education_data)
        prompt.update(skills_data)
        prompt.update(Skills__evaluation)
        prompt.update(work_experience)
        prompt.update(projects_experience)
        prompt.update(certifications)

        return prompt

    def resume_analyzer_main(self, llm, documents):
        """Put it all together: Extract, evaluate and improve all resume sections.
        Save the final results in a dictionary.
        """
        # 1. Extract Contact information: Name, Title, Location, Email,...
        CONTACT_INFORMATION = self.Extract_contact_information(llm, documents)
        
        # 2. Extract, evaluate and improve the Summary
        Summary_SECTION = self.Extract_Evaluate_Summary(llm, documents)

        # 3. Extract and evaluate education and language sections.
        Education_Language_sections = self.Extract_Education_Language(llm, documents)

        # 4. Extract and evaluate the SKILLS.
        SKILLS_and_CERTIF = self.Extract_Skills_and_Certifications(llm, documents)

        # 5. Extract Work Experience and Projects.
        PROFESSIONAL_EXPERIENCE = self.Extract_PROFESSIONAL_EXPERIENCE(llm, documents)

        # 6. EXTRACT WORK EXPERIENCE RESPONSIBILITIES.
        PROFESSIONAL_EXPERIENCE = self.Extract_Job_Responsibilities(
            llm, documents, PROFESSIONAL_EXPERIENCE
        )

        # 7. EXTRACT PROJECT DETAILS.
        PROFESSIONAL_EXPERIENCE = self.Extract_Project_Details(
            llm, documents, PROFESSIONAL_EXPERIENCE
        )

        # 11. Put it all together: create the SCANNED_RESUME dictionary
        SCANNED_RESUME = {}
        for dictionary in [
            CONTACT_INFORMATION,
            Summary_SECTION,
            Education_Language_sections,
            SKILLS_and_CERTIF,
            PROFESSIONAL_EXPERIENCE
        ]:
            SCANNED_RESUME.update(dictionary)

        # 12. Save the Scanned resume
        try:
            now = (datetime.datetime.now()).strftime("%Y%m%d_%H%M%S")
            file_name = "results_" + now
            with open(f"./data/{file_name}.json", "w") as fp:
                json.dump(SCANNED_RESUME, fp)
        except:
            pass

        return SCANNED_RESUME
    def instantiate_LLM_main(self, LLM_provider1, temperature, top_p):
        """Instantiate the selected LLM model."""
        try:
            if LLM_provider1 == "OpenAI":
                 print("working..")
                 llm = self.instantiate_LLM(
                    LLM_provider="OpenAI",
                    api_key=self.openai_api_key,
                    temperature=temperature,
                    top_p=top_p,
                    model_name="gpt-3.5-turbo-0125",
                )
            else:
                print("Unsupported LLM provider")
                llm = None
        except Exception as e:
            print(f"An error occurred: {e}")
            llm = None
            
        except Exception as e:
            print(f"An error occured: {e}")
            llm = None
        return llm

    def instantiate_LLM(self,
        LLM_provider, api_key, temperature=0.5, top_p=0.95, model_name=None
    ):
        """Instantiate LLM in Langchain.
        Parameters:
            LLM_provider (str): the LLM provider; in ["OpenAI","Google"]
            model_name (str): in ["gpt-3.5-turbo", "gpt-3.5-turbo-0125", "gpt-4-turbo-preview","gemini-pro"].
            api_key (str): google_api_key or openai_api_key
            temperature (float): Range: 0.0 - 1.0; default = 0.5
            top_p (float): : Range: 0.0 - 1.0; default = 1.
        """
        if LLM_provider == "OpenAI":
            
            llm = ChatOpenAI(
                api_key=api_key,
                model=model_name,
                temperature=temperature,
                model_kwargs={"top_p": top_p},
            )
        else:
            print("Unsupported LLM provider")
            llm = None
        
        return llm

    # def get_api_keys_from_local_env(self):
    #     """Get OpenAI, Gemini and Cohere API keys from local .env file"""
    #     try:
    #         found_dotenv = find_dotenv("keys.env", usecwd=True)
    #         load_dotenv(found_dotenv)
    #         try:
    #             openai_api_key = os.getenv("api_key_openai")
    #         except:
    #             openai_api_key = ""
    #         try:
    #             google_api_key = os.getenv("api_key_google")
    #         except:
    #             google_api_key = ""
    #         try:
    #             cohere_api_key = os.getenv("api_key_cohere")
    #         except:
    #             cohere_api_key = ""
    #         #print(openai_api_key, google_api_key, cohere_api_key)
    #     except Exception as e:
    #         print(e)

    #     return openai_api_key, google_api_key, cohere_api_key
    
@app.route('/process_resume', methods=['POST'])
def process_resume():
    try:
        # Extract data from request
        data = request.json
        uploaded_file_path = data.get('uploaded_file_path')
        LLM_provider1 = data.get('LLM_provider1')
        cohereaikey = data.get('cohere_api_key')
        openaikey = data.get('openai_api_key')
        googleaikey = data.get('google_api_key')

        resume_extractor = ResumeExtractor(openai_api_key=openaikey, google_api_key=googleaikey, cohere_api_key=cohereaikey)
        print("abcd")
        # Perform resume processing
        documents, retriever = resume_extractor.retrieval_main(uploaded_file_path, LLM_provider1, cohereaikey, openaikey, googleaikey)
        print("rtyuio")
        llm = resume_extractor.instantiate_LLM_main(LLM_provider1, temperature=0.0, top_p=0.95)
        print("*&&&&&&*")                        
        SCANNED_RESUME = resume_extractor.resume_analyzer_main(llm, documents)
        print("sdfgh")
        processed_data = resume_extractor.process_resume_data(SCANNED_RESUME)

        # Save processed data to JSON file
        with open('extracted_results1.json', 'w') as outfile:
            json.dump(processed_data, outfile, indent=4)

        return jsonify(processed_data), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True)


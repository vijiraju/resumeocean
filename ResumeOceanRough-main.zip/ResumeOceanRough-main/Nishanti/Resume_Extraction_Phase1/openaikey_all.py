def open_api_key():
    return "api_key_openai" #enter api key

def google_api_key():
    return "api_key_google" #enter api key

def cohere_api_key():
    return "WPahRJnX5gpPVbKyUtZbJLpHSDFHiQ5e2WvNlfHH" #enter api key
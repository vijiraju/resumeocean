import os
import requests
#from dotenv import load_dotenv, find_dotenv
from openaikey_all import *

# # Load environment variables from .env file
# load_dotenv(find_dotenv("keys.env", usecwd=True))


def call_process_resume_endpoint(uploaded_file_path, LLM_provider1, openaikey, googleaikey, cohereaikey):
    url = 'http://localhost:5000/process_resume'  # Assuming Flask app is running locally on port 5000
    data = {
        'uploaded_file_path': uploaded_file_path,
        'LLM_provider1': LLM_provider1,
        'cohere_api_key': cohereaikey,
        'openai_api_key' : openaikey,
        'google_api_key' : googleaikey
    }
    headers = {'Content-Type': 'application/json'}
    
    try:
        response = requests.post(url, json=data, headers=headers)
        if response.status_code == 200:
            print("Resume processing successful!")
            processed_data = response.json()
            return processed_data
        else:
            print("Error:", response.json()['error'])
            return None
    except Exception as e:
        print("Exception occurred:", str(e))
        return None

# Example usage
uploaded_file_path = r"C:\Users\Nishanthi.Sekaran.CORPBRISTLECONE\Downloads\Resume_Testing\Dataset\Dataset\DIKESH RAY.pdf"
LLM_provider1 = "OpenAI"
openapi=open_api_key()
googleapi=google_api_key()
cohereapi=cohere_api_key()

processed_data = call_process_resume_endpoint(uploaded_file_path, LLM_provider1, openapi, googleapi, cohereapi)
if processed_data:
    print("Processed data:", processed_data)
else:
    print("Failed to process resume.")

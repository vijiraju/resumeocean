def open_api_key_ayushman():
    return "sk-proj-Do7HxYeTX3GrUv6JFpz0T3BlbkFJcweJ1Rvn1wrRfny0kt5W" #enter api key


def cohere_api_key():
    return "WPahRJnX5gpPVbKyUtZbJLpHSDFHiQ5e2WvNlfHH" #enter api key
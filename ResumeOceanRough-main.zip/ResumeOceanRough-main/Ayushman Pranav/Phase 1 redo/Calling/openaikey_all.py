def open_api_key_ayushman():
    return "" #enter api key


def cohere_api_key():
    return "WPahRJnX5gpPVbKyUtZbJLpHSDFHiQ5e2WvNlfHH" #enter api key
python -m venv virtualenv
.\virtualenv\scripts\activate
python -m pip install --upgrade pip

pip install python-dotenv
pip install langchain_community
pip install langchain
pip install -U langchain-openai
pip install openai[embeddings]
pip install faiss-cpu
pip install cohere
pip install langchain_cohere
pip install flask

pip freeze > requirements.txt

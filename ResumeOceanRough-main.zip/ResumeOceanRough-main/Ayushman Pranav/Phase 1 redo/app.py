import os
import glob
import warnings
import datetime
import json
import tiktoken
import logging
from flask import Flask, request, jsonify
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.retrievers import ContextualCompressionRetriever
from langchain_cohere import CohereRerank
from langchain_community.llms import Cohere
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS
from langchain.prompts import PromptTemplate
from app_constants import templates
from langchain_openai import ChatOpenAI
import json

# Suppressing warnings
warnings.filterwarnings("ignore", category=FutureWarning)

logging.basicConfig(
filename='extract_data.log',
level=logging.INFO,
format='%(asctime)s - %(levelname)s - %(message)s',
datefmt='%Y-%m-%d %H:%M:%S'
)

app = Flask(__name__)

class ResumeExtractor:
    def __init__(self, openai_api_key, cohere_api_key):
        self.openai_api_key = openai_api_key
        self.cohere_api_key = cohere_api_key

    def tiktoken_tokens(self, documents, model="gpt-3.5-turbo-0125"):
        encoding = tiktoken.encoding_for_model(model)
        tokens_length = [len(encoding.encode(doc)) for doc in documents]
        return tokens_length

    def select_embeddings_model(self, llm_service="OpenAI"):
        if llm_service == "OpenAI":
            if self.openai_api_key is None:
                raise ValueError("OpenAI API key is required.")
            embeddings = OpenAIEmbeddings(api_key=self.openai_api_key)
        else:
            raise ValueError("Invalid LLM service selected.")
        return embeddings

    def create_vectorstore(self, embeddings, documents):
        vector_store = FAISS.from_documents(documents=documents, embedding=embeddings)
        return vector_store

    def vectorstore_backed_retriever(self, vectorstore, search_type="similarity", k=4, score_threshold=None):
        search_kwargs = {}
        if k is not None:
            search_kwargs["k"] = k
        if score_threshold is not None:
            search_kwargs["score_threshold"] = score_threshold

        retriever = vectorstore.as_retriever(search_type=search_type, search_kwargs=search_kwargs)
        return retriever

    def cohere_rerank_retriever(self, base_retriever, cohere_api_key, cohere_model="rerank-multilingual-v2.0", top_n=4):
        compressor = CohereRerank(cohere_api_key=cohere_api_key, model=cohere_model, top_n=top_n)
        retriever = ContextualCompressionRetriever(base_compressor=compressor, base_retriever=base_retriever)
        return retriever
    
    def process_text_documents(self, resume_text):
        """Simulate processing text into documents format as if it were a PDF loaded in Langchain."""
        # Splitting the resume text into "documents" by lines
        documents = resume_text.split('\n')

        # Mimicking document metadata addition
        formatted_documents = []
        for i, doc in enumerate(documents):
            # Assuming that the 'page_content' is the key expected by the downstream process,
            # we will include it directly in the document dictionary.
            formatted_documents.append({
                "page_content": doc,  # Direct content representation as 'page_content'
                "metadata": {
                    "source": "Simulated PDF text line",
                    "doc_number": i
                }
            })

        return formatted_documents
    
    def process_text_documents(self, resume_text):
        sections = resume_text.split('\n\n')  # Split sections by double newline

        documents = []
        for i, section in enumerate(sections):
            # Here you can process each section and add metadata
            document = {
                "content": section.strip(),  # Remove leading/trailing whitespace
                "metadata": {
                    "source": "resume",
                    "doc_number": i,
                }
            }
            documents.append(document)

        return documents



    def retrieval_main(self, resume_text, LLM_provider, cohere_api_key, openai_api_key):

        logging.info("Starting retrieval process with provided resume text")

        documents = self.process_text_documents(resume_text)
        logging.info("Processing text into documents format")

        embeddings = self.select_embeddings_model(LLM_provider)
        
        logging.info("Creating vector store")
        vector_store = self.create_vectorstore(embeddings, documents)

        base_retriever = self.vectorstore_backed_retriever(vector_store)
        logging.info("Creating base retriever using vector store")

        retriever = self.cohere_rerank_retriever(base_retriever, cohere_api_key)
        logging.info("Enhancing retriever with Cohere Rerank")
        
        logging.info("Retrieval process completed")
        return documents, retriever



    def response_content_parser(self, response_content, list_fields, list_rfind, list_exclude_first_car):
        """
        This is a function for parsing any response_content.
        """
        list_fields_detailed = []

        for field in list_fields:
            if isinstance(field, dict):
                list_fields_detailed.append((list(field.keys())[0], False, None))
                for val in list(field.values())[0]:
                    list_fields_detailed.append((val, True, list(field.keys())[0]))
            else:
                list_fields_detailed.append((field, True, None))

        list_fields_detailed.append((None, False, None))

        INFORMATION_dict = {}

        for i in range(len(list_fields_detailed) - 1):
            if not list_fields_detailed[i][1]:
                INFORMATION_dict[list_fields_detailed[i][0]] = {}
            if list_fields_detailed[i][1]:
                extracted_value = self.extract_from_text(
                    response_content,
                    f'"{list_fields_detailed[i][0]}": ',
                    f'"{list_fields_detailed[i+1][0]}":',
                )
                extracted_value = extracted_value[: extracted_value.rfind(list_rfind[i])].strip()
                if list_exclude_first_car[i]:
                    extracted_value = extracted_value[1:-1].strip()
                if list_fields_detailed[i][2] is None:
                    INFORMATION_dict[list_fields_detailed[i][0]] = extracted_value
                else:
                    INFORMATION_dict[list_fields_detailed[i][2]][list_fields_detailed[i][0]] = extracted_value

        return INFORMATION_dict

    def extract_contact_information(self, llm, documents):
        """
        Extract Contact Information: Name, Title, Location, Email, Phone number and Social media profiles.
        """
        try:
            response_content = self.invoke_llm(
                llm,
                documents,
                resume_sections=["Contact__information"],
                info_message="Extract and evaluate contact information...",
                language="english"
            )

            try:
                # Load response_content to json dictionary
                contact_information = json.loads(response_content, strict=False)
            except Exception as e:
                print("[ERROR] json.loads returns error:", e)
                print("\n[INFO] Parse response content...\n")

                list_fields = [
                    {
                        "Contact__information": [
                            "candidate__name",
                            "candidate__title",
                            "candidate__location",
                            "candidate__email",
                            "candidate__phone",
                            "candidate__social_media",
                            "evaluation__ContactInfo",
                            "score__ContactInfo",
                        ]
                    }
                ]
                list_rfind = [",\n", ",\n", ",\n", ",\n", ",\n", ",\n", ",\n", ",\n", "}\n"]
                list_exclude_first_car = [
                    True,
                    True,
                    True,
                    True,
                    True,
                    True,
                    False,
                    True,
                    False,
                ]
                contact_information = self.response_content_parser(
                    response_content, list_fields, list_rfind, list_exclude_first_car
                )
                # convert score to int
                try:
                    contact_information["Contact__information"]["score__ContactInfo"] = int(
                        contact_information["Contact__information"]["score__ContactInfo"]
                    )
                except:
                    contact_information["Contact__information"]["score__ContactInfo"] = -1

        except Exception as exception:
            print(f"[Error] {exception}")
            contact_information = {
                "Contact__information": {
                    "candidate__name": "unknown",
                    "candidate__title": "unknown",
                    "candidate__location": "unknown",
                    "candidate__email": "unknown",
                    "candidate__phone": "unknown",
                    "candidate__social_media": "unknown",
                    "evaluation__ContactInfo": "unknown",
                    "score__ContactInfo": -1,
                }
            }

        return contact_information
    
    def Extract_Evaluate_Summary(self, llm, documents):
        """Extract, evaluate and strengthen the summary."""
        try:
            response_content = self.invoke_LLM(
                llm,
                documents,
                resume_sections=["CV__Summary"],
                info_message="Extract and evaluate the Summary....",
                language="english",
            )
            try:
                SUMMARY_SECTION = json.loads(response_content, strict=False)
            except Exception as e:
                print("[ERROR] json.loads returns error:", e)
                print("\n[INFO] Parse response content...\n")

                list_fields = [{"CV__Summary": ["summaryDetails", "totalIndustryExperience"]}]
                list_rfind = [",\n", ",\n", "}\n"]
                list_exclude_first_car = [True, True]

                SUMMARY_SECTION = self.ResponseContent_Parser(
                    response_content, list_fields, list_rfind, list_exclude_first_car
                )

        except Exception as exception:
            print(f"[Error] {exception}")
            SUMMARY_SECTION = {"CV__Summary": {"summaryDetails": "unknown", "totalIndustryExperience": "unknown"}}

        return SUMMARY_SECTION

    def Extract_Education_Language(self, llm, documents):
        """Extract and evaluate education and language sections."""
        try:
            response_content = self.invoke_LLM(
                llm,
                documents,
                resume_sections=[
                    "CV__Education",
                    "Education__evaluation",
                    "CV__Languages",
                    "Languages__evaluation",
                ],
                info_message="Extract and evaluate education and language sections...",
                language="english",
            )

            try:
                Education_Language_sections = json.loads(response_content, strict=False)
            except Exception as e:
                print("[ERROR] json.loads returns error:", e)
                print("\n[INFO] Parse response content...\n")

                list_fields = [
                    "CV__Education",
                    {"Education__evaluation": ["score__edu", "evaluation__edu"]},
                    "CV__Languages",
                    {"Languages__evaluation": ["score__language", "evaluation__language"]},
                ]
                list_rfind = [",\n", ",\n", ",\n", ",\n", ",\n", ",\n", ",\n", "\n","\n", ",\n", "\n"]
                list_exclude_first_car = [True, True, True, False, True, True, True, True, True, True, False, True]

                Education_Language_sections = self.ResponseContent_Parser(
                    response_content, list_fields, list_rfind, list_exclude_first_car
                )

                try:
                    Education_Language_sections["Education__evaluation"]["score__edu"] = (
                        int(Education_Language_sections["Education__evaluation"]["score__edu"])
                    )
                except:
                    Education_Language_sections["Education__evaluation"]["score__edu"] = -1

                try:
                    Education_Language_sections["Languages__evaluation"]["score__language"] = (
                        int(Education_Language_sections["Languages__evaluation"]["score__language"])
                    )
                except:
                    Education_Language_sections["Languages__evaluation"]["score__language"] = -1

                languages = Education_Language_sections["CV__Languages"]
                Education_Language_sections["CV__Languages"] = self.convert_text_to_list_of_dicts(
                    text=languages[languages.find("[") + 1 : languages.rfind("]")].strip(),
                    dict_keys=["spoken__language", "language__fluency"],
                )
                education = Education_Language_sections["CV__Education"]
                Education_Language_sections["CV__Education"] = self.convert_text_to_list_of_dicts(
                    text=education[education.find("[") + 1 : education.rfind("]")].strip(),
                    dict_keys=["degree", "course", "marks", "yearOfPass", "boardsName", "percentage", "college", "educational_qual"],
                )
        except Exception as exception:
            print(exception)
            Education_Language_sections = {
                "CV__Education": [],
                "Education__evaluation": {"score__edu": -1, "evaluation__edu": "unknown"},
                "CV__Languages": [],
                "Languages__evaluation": {"score__language": -1, "evaluation__language": "unknown"},
            }

        return Education_Language_sections
    
    
    def Extract_Skills_and_Certifications(self, llm, documents):
        """Extract skills and certifications and evaluate these sections."""

        try:
            response_content = self.invoke_LLM(
                llm,
                documents,
                resume_sections=[
                    "skills",
                    "Skills__evaluation",
                    "CV__Certifications",
                    "Certif__evaluation",
                ],
                info_message="Extract and evaluate the skills and certifications...",
                language="english",
            )

            try:
                # Load response_content to json dictionary
                SKILLS_and_CERTIF = json.loads(response_content, strict=False)
            except Exception as e:
                print("[ERROR] json.loads returns error:", e)
                print("\n[INFO] Parse response content...\n")

                skills = self.extract_from_text(
                    response_content, '"skills": ', '"Skills__evaluation":'
                )
                skills = skills.replace("\n  ", "\n").replace("],\n", "").replace("[\n", "")
                selfRating = selfRating.replace("\n  ", "\n").replace("],\n", "").replace("[\n", "")
                # score_skills = extract_from_text(
                #     response_content, '"selfRating": ', '"whyRate":'
                # )
                evaluation_skills = self.extract_from_text(
                    response_content, '"whyRate": ', '"CV__Certifications":'
                )

                certif_text = self.extract_from_text(
                    response_content, '"CV__Certifications": ', '"Certif__evaluation":'
                )
                certif_score = self.extract_from_text(
                    response_content, '"score__certif": ', '"detailsofAwards/Cerifications":'
                )
                certif_eval = self.extract_from_text(
                    response_content, '"detailsofAwards/Cerifications": ', None
                )

                # Create the dictionary
                SKILLS_and_CERTIF = {}
                SKILLS_and_CERTIF["skills"] = [
                    skill.strip()[1:-1] for skill in skills.split(",\n")
                ]
                # try:
                #     score_skills_int = int(score_skills[0 : score_skills.rfind(",\n")])
                # except:
                #     score_skills_int = -1
                
                SKILLS_and_CERTIF["Skills__evaluation"] = {
                    "selfRating": [rating.strip()[1:-1] for rating in selfRating.split(",\n")],
                    "whyRate": evaluation_skills[
                        : evaluation_skills.rfind("}\n")
                    ].strip()[1:-1],
                }

                # Convert certificate text to list of dictionaries
                list_certifs = self.convert_text_to_list_of_dicts(
                    text=certif_text[
                        certif_text.find("[") + 1 : certif_text.rfind("]")
                    ].strip(),  # .strip()[1:-1]
                    dict_keys=[
                        "awardsTitle",
                        "institutionsOrganization",
                        "dateOfAwards",
                        "nameOfAwardsAchievements",
                        "urlAwards",
                        "typesOfAchievment",
                                        
                    ],
                )
                SKILLS_and_CERTIF["CV__Certifications"] = list_certifs
                try:
                    certif_score_int = int(certif_score[0 : certif_score.rfind(",\n")])
                except:
                    certif_score_int = -1
                SKILLS_and_CERTIF["Certif__evaluation"] = {
                    "score__certif": certif_score_int,
                    "detailsofAwards/Cerifications": certif_eval[: certif_eval.rfind("}\n")].strip()[
                        1:-1
                    ],
                }

        except Exception as exception:
            SKILLS_and_CERTIF = {
                "skills": [],
                "Skills__evaluation": {
                    "selfRating": -1,
                    "whyRate": "unknown",
                },
                "CV__Certifications": [],
                "Certif__evaluation": {
                    "score__certif": -1,
                    "detailsofAwards/Cerifications": "unknown",
                },
            }
            print(exception)

        return SKILLS_and_CERTIF


    def Extract_PROFESSIONAL_EXPERIENCE(self, llm, documents):
        """Extract list of work experience and projects."""

        try:
            response_content = self.invoke_LLM(
                llm,
                documents,
                resume_sections=["Work__experience", "CV__Projects"],
                info_message="Extract list of work experience and projects...",
                language="english",
            )

            try:
                # Load response_content to json dictionary
                PROFESSIONAL_EXPERIENCE = json.loads(response_content, strict=False)
            except Exception as e:
                print("[ERROR] json.loads returns error:", e)
                print("\n[INFO] Parse response content...\n")

                work_experiences = self.extract_from_text(
                    response_content, '"Work__experience": ', '"CV__Projects":'
                )
                projects = self.extract_from_text(response_content, '"CV__Projects": ', None)

                # Create the dictionary
                PROFESSIONAL_EXPERIENCE = {}
                PROFESSIONAL_EXPERIENCE["Work__experience"] = self.convert_text_to_list_of_dicts(
                    text=work_experiences[
                        work_experiences.find("[") + 1 : work_experiences.rfind("]")
                    ].strip()[1:-1],
                    dict_keys=[
                        "postDesignation"
                        "nameOfEmployer",
                        "periodOfEmploymentFrom",
                        "periodOfEmploymentTo",
                        "department",
                        "grossSalary",
                        "totalIndustryExperience",
                    ],
                )
                PROFESSIONAL_EXPERIENCE["CV__Projects"] = self.convert_text_to_list_of_dicts(
                    text=projects[projects.find("[") + 1 : projects.rfind("]")].strip()[
                        1:-1
                    ],
                    dict_keys=[
                        "project__title",
                        "project__start_date",
                        "project__end_date",
                    ],
                )
            # Exclude 'unknown' projects and work experiences
            try:
                for work_experience in PROFESSIONAL_EXPERIENCE["Work__experience"]:
                    if work_experience["postDesignation"] == "unknown":
                        PROFESSIONAL_EXPERIENCE["Work__experience"].remove(work_experience)
            except Exception as e:
                print(e)
            try:
                for project in PROFESSIONAL_EXPERIENCE["CV__Projects"]:
                    if project["project__title"] == "unknown":
                        PROFESSIONAL_EXPERIENCE["CV__Projects"].remove(project)
            except Exception as e:
                print(e)

        except Exception as exception:
            PROFESSIONAL_EXPERIENCE = {"Work__experience": [], "CV__Projects": []}
            print(exception)

        return PROFESSIONAL_EXPERIENCE



    def Extract_Job_Responsibilities(self, llm, documents, PROFESSIONAL_EXPERIENCE):
        """Extract job responsibilities for each job in PROFESSIONAL_EXPERIENCE."""

        print(f"**{self.get_current_time()}** \tExtract work experience responsibilities...")

        for i in range(len(PROFESSIONAL_EXPERIENCE["Work__experience"])):
            try:
                Work_experience_i = PROFESSIONAL_EXPERIENCE["Work__experience"][i]

                # 1. Extract relevant documents
                query = f"""Extract from the resume delimited by triple backticks \
    all the duties and responsibilities of the following work experience: \
    (title = '{Work_experience_i['postDesignation']}'"""
                if str(Work_experience_i["nameOfEmployer"]) != "unknown":
                    query += f" and company = '{Work_experience_i['nameOfEmployer']}'"
                if str(Work_experience_i["periodOfEmploymentFrom"]) != "unknown":
                    query += f" and start date = '{Work_experience_i['periodOfEmploymentFrom']}'"
                if str(Work_experience_i["periodOfEmploymentTo"]) != "unknown":
                    query += f" and end date = '{Work_experience_i['periodOfEmploymentTo']}'"
                query += ")\n"

                try:
                    relevant_documents = self.get_relevant_documents(query, documents)
                except Exception as err:
                    print(f"get_relevant_documents error: {err}")
                    relevant_documents = documents

                # 2. Invoke LLM

                prompt = (
                    query
                    + f"""Output the duties in a json dictionary with the following keys (__duty_id__,__duty__). \
    Use this format: "1":"duty","2":"another duty".
    Resume:\n\n ```{relevant_documents}```"""
                )
                response = llm.invoke(prompt)

                # 3. Convert the response content to json dict and update work_experience
                response_content = response.content[
                    response.content.find("{") : response.content.rfind("}") + 1
                ]

                try:
                    Work_experience_i["responsibilities"] = json.loads(
                        response_content, strict=False
                    )  # Convert the response content to a json dict
                except Exception as e:
                    print("\njson.loads returns error:", e, "\n\n")
                    print("\n[INFO] Parse response content...\n")

                    Work_experience_i["responsibilities"] = {}
                    list_duties = (
                        response_content[
                            response_content.find("{") + 1 : response_content.rfind("}")
                        ]
                        .strip()
                        .split(",\n")
                    )

                    for j in range(len(list_duties)):
                        try:
                            Work_experience_i["responsibilities"][f"{j+1}"] = (
                                list_duties[j].split('":')[1].strip()[1:-1]
                            )
                        except:
                            Work_experience_i["responsibilities"][f"{j+1}"] = "unknown"

            except Exception as exception:
                Work_experience_i["responsibilities"] = {}
                print(exception)

        return PROFESSIONAL_EXPERIENCE


    def Extract_Project_Details(self, llm, documents, PROFESSIONAL_EXPERIENCE):
        """Extract project details for each project in PROFESSIONAL_EXPERIENCE."""

        print(f"**{self.get_current_time()}** \tExtract project details...")

        for i in range(len(PROFESSIONAL_EXPERIENCE["CV__Projects"])):
            try:
                project_i = PROFESSIONAL_EXPERIENCE["CV__Projects"][i]

                # 1. Extract relevant documents
                query = f"""Extract from the resume (delimited by triple backticks) what is listed about the following project: \
    (project title = '{project_i['project__title']}'"""
                if str(project_i["project__start_date"]) != "unknown":
                    query += f" and start date = '{project_i['project__start_date']}'"
                if str(project_i["project__end_date"]) != "unknown":
                    query += f" and end date = '{project_i['project__end_date']}'"
                query += ")"

                try:
                    relevant_documents = self.get_relevant_documents(query, documents)
                except Exception as err:
                    print(f"get_relevant_documents error: {err}")
                    relevant_documents = documents

                # 2. Invoke LLM

                prompt = (
                    query
                    + f"""Format the extracted text into a string (with bullet points).
    Resume:\n\n ```{relevant_documents}```"""
                )

                response = llm.invoke(prompt)

                response_content = response.content
                project_i["project__description"] = response_content

            except Exception as exception:
                project_i["project__description"] = "unknown"
                print(exception)

        return PROFESSIONAL_EXPERIENCE
    
    
        
    def process_resume_data(self, SCANNED_RESUME):
        
        data = SCANNED_RESUME

        contact_info = data.get('Contact__information', {})
        CV__Summary = data.get('CV__Summary', {})

        languages = []
        fluencies = []
        for language_info in data.get("CV__Languages", []):
            languages.append(language_info.get("spoken__language", ""))
            fluencies.append(language_info.get("language__fluency", ""))

        combined_data = {
            "spoken__language": languages,
            "language__fluency": fluencies
        }

        degree = []
        course = []
        marks = []
        yearOfPass = []
        boardsName = []
        percentage = []
        college = []
        educational_qual = []

        for edu_info in data.get("CV__Education", []):
            degree.append(edu_info.get("degree", ""))
            course.append(edu_info.get("course", ""))
            marks.append(edu_info.get("marks", ""))
            yearOfPass.append(edu_info.get("yearOfPass", ""))
            boardsName.append(edu_info.get("boardsName", ""))
            percentage.append(edu_info.get("percentage", ""))
            college.append(edu_info.get("college", ""))
            educational_qual.append(edu_info.get("educational_qual", ""))

        education_data = {
            "degree": degree,
            "course": course,
            "marks": marks,
            "yearOfPass": yearOfPass,
            "boardsName": boardsName,
            "percentage": percentage,
            "college": college,
            "educational_qual": educational_qual
        }

        skills = data.get("skills", {}).get("soft skills", []) + data.get("skills", {}).get("technical skills", [])
        skills_data = {"skills": skills}

        Skills__evaluation = data.get('Skills__evaluation', {})

        postDesignation = []
        nameOfEmployer = []
        periodOfEmploymentFrom = []
        periodOfEmploymentTo = []
        department = []
        grossSalary = []
        responsibilities = []

        for work_info in data.get("Work__experience", []):
            postDesignation.append(work_info.get("postDesignation", ""))
            nameOfEmployer.append(work_info.get("nameOfEmployer", ""))
            periodOfEmploymentFrom.append(work_info.get("periodOfEmploymentFrom", ""))
            periodOfEmploymentTo.append(work_info.get("periodOfEmploymentTo", ""))
            department.append(work_info.get("department", ""))
            grossSalary.append(work_info.get("grossSalary", ""))
            responsibilities.append(work_info.get("responsibilities", ""))

        work_experience = {
            "postDesignation": postDesignation,
            "nameOfEmployer": nameOfEmployer,
            "periodOfEmploymentFrom": periodOfEmploymentFrom,
            "periodOfEmploymentTo": periodOfEmploymentTo,
            "department": department,
            "grossSalary": grossSalary,
            "responsibilities": responsibilities
        }

        project__title = []
        project__start_date = []
        project__end_date = []
        project__description = []

        for projects_info in data.get("CV__Projects", []):
            project__title.append(projects_info.get("project__title", ""))
            project__start_date.append(projects_info.get("project__start_date", ""))
            project__end_date.append(projects_info.get("project__end_date", ""))
            project__description.append(projects_info.get("project__description", ""))

        projects_experience = {
            "project__title": project__title,
            "project__start_date": project__start_date,
            "project__end_date": project__end_date,
            "project__description": project__description
        }

        awards_titles = []
        institutions = []
        dates = []
        nameOfAwards = []
        urlAwards = []
        Achievmenttypes = []

        for certification in data.get("CV__Certifications", []):
            awards_titles.append(certification.get("awardsTitle", ""))
            institutions.append(certification.get("institutionsOrganization", ""))
            dates.append(certification.get("dateOfAwards", ""))
            nameOfAwards.append(certification.get("nameOfAwardsAchievements", ""))
            urlAwards.append(certification.get("urlAwards", ""))
            Achievmenttypes.append(certification.get("typesOfAchievment", ""))

        detailsofAwards = data.get('Certif__evaluation', {}).get('detailsofAwards/Cerifications', '')

        certifications = {
            "awardsTitle": awards_titles,
            "institutionsOrganization": institutions,
            "dateOfAwards": dates,
            "nameOfAwardsAchievements": nameOfAwards,
            "urlAwards": urlAwards,
            "typesOfAchievment": Achievmenttypes,
            "detailsofAwards/Cerifications": detailsofAwards
        }

        prompt = contact_info.copy()
        prompt.update(CV__Summary)
        prompt.update(education_data)
        prompt.update(skills_data)
        prompt.update(Skills__evaluation)
        prompt.update(work_experience)
        prompt.update(projects_experience)
        prompt.update(certifications)

        return prompt

    def resume_analyzer_main(self, llm, documents):
        """Put it all together: Extract, evaluate and improve all resume sections.
        Save the final results in a dictionary.
        """
        # 1. Extract Contact information: Name, Title, Location, Email,...
        CONTACT_INFORMATION = self.Extract_contact_information(llm, documents)
        
        # 2. Extract, evaluate and improve the Summary
        Summary_SECTION = self.Extract_Evaluate_Summary(llm, documents)

        # 3. Extract and evaluate education and language sections.
        Education_Language_sections = self.Extract_Education_Language(llm, documents)

        # 4. Extract and evaluate the SKILLS.
        SKILLS_and_CERTIF = self.Extract_Skills_and_Certifications(llm, documents)

        # 5. Extract Work Experience and Projects.
        PROFESSIONAL_EXPERIENCE = self.Extract_PROFESSIONAL_EXPERIENCE(llm, documents)

        # 6. EXTRACT WORK EXPERIENCE RESPONSIBILITIES.
        PROFESSIONAL_EXPERIENCE = self.Extract_Job_Responsibilities(
            llm, documents, PROFESSIONAL_EXPERIENCE
        )

        # 7. EXTRACT PROJECT DETAILS.
        PROFESSIONAL_EXPERIENCE = self.Extract_Project_Details(
            llm, documents, PROFESSIONAL_EXPERIENCE
        )

        # 11. Put it all together: create the SCANNED_RESUME dictionary
        SCANNED_RESUME = {}
        for dictionary in [
            CONTACT_INFORMATION,
            Summary_SECTION,
            Education_Language_sections,
            SKILLS_and_CERTIF,
            PROFESSIONAL_EXPERIENCE
        ]:
            SCANNED_RESUME.update(dictionary)

        # 12. Save the Scanned resume
        try:
            now = (datetime.datetime.now()).strftime("%Y%m%d_%H%M%S")
            file_name = "results_" + now
            with open(f"./data/{file_name}.json", "w") as fp:
                json.dump(SCANNED_RESUME, fp)
        except:
            pass

        return SCANNED_RESUME
    def instantiate_LLM_main(self, LLM_provider1, temperature, top_p):
        """Instantiate the selected LLM model."""
        try:
            if LLM_provider1 == "OpenAI":
                 print("working..")
                 llm = self.instantiate_LLM(
                    LLM_provider="OpenAI",
                    api_key=self.openai_api_key,
                    temperature=temperature,
                    top_p=top_p,
                    model_name="gpt-3.5-turbo-0125",
                )
            else:
                print("Unsupported LLM provider")
                llm = None
        except Exception as e:
            print(f"An error occurred: {e}")
            llm = None
            
        except Exception as e:
            print(f"An error occured: {e}")
            llm = None
        return llm

    def instantiate_LLM(self,
        LLM_provider, api_key, temperature=0.5, top_p=0.95, model_name=None
    ):
        """Instantiate LLM in Langchain.
        Parameters:
            LLM_provider (str): the LLM provider; in ["OpenAI","Google"]
            model_name (str): in ["gpt-3.5-turbo", "gpt-3.5-turbo-0125", "gpt-4-turbo-preview","gemini-pro"].
            api_key (str): google_api_key or openai_api_key
            temperature (float): Range: 0.0 - 1.0; default = 0.5
            top_p (float): : Range: 0.0 - 1.0; default = 1.
        """
        if LLM_provider == "OpenAI":
            
            llm = ChatOpenAI(
                api_key=api_key,
                model=model_name,
                temperature=temperature,
                model_kwargs={"top_p": top_p},
            )
        else:
            print("Unsupported LLM provider")
            llm = None
        
        return llm

    
@app.route('/process_resume', methods=['POST'])
def process_resume():
    try:
        # Extract data from request
        data = request.json
        resume_text = data.get('resume_text')
        LLM_provider1 = data.get('LLM_provider1')
        cohereaikey = data.get('cohere_api_key')
        openaikey = data.get('openai_api_key')

        resume_extractor = ResumeExtractor(openai_api_key=openaikey, cohere_api_key=cohereaikey)
        print("abcd")
        # Perform resume processing
        documents, retriever  = resume_extractor.retrieval_main(resume_text, LLM_provider1, cohereaikey, openaikey)
        
        print("rtyuio")
        
        llm = resume_extractor.instantiate_LLM_main(LLM_provider1, temperature=0.0, top_p=0.95)
        
        print("*&&&&&&*")                        
        
        SCANNED_RESUME = resume_extractor.resume_analyzer_main(llm, documents)
        
        print("sdfgh")
        
        processed_data = resume_extractor.process_resume_data(SCANNED_RESUME)

        # Save processed data to JSON file
        with open('extracted_results1.json', 'w') as outfile:
            json.dump(processed_data, outfile, indent=4)

        return jsonify(processed_data), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True)

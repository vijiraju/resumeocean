python -m venv ./venv
./venv/Scripts/activate
python -m pip install --upgrade pip
pip install jupyterlab
pip install dataclasses
pip install pandas
pip install pyarrow
pip install openpyxl

pip install Flask python-docx PyPDF2
# for open ai
pip install openai==0.28
pip install requests